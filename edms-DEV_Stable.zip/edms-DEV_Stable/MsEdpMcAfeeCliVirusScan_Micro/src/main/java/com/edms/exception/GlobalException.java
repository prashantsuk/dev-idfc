package com.edms.exception;

public class GlobalException extends Exception {

	private static final long serialVersionUID = 1L;
	
    public GlobalException(String errorMessage) {  
    super(errorMessage);  
    }  
	
}
