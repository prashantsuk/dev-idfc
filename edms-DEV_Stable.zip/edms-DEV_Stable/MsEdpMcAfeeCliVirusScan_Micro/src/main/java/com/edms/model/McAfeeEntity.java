package com.edms.model;

import com.aerospike.mapper.annotations.AerospikeBin;
import com.aerospike.mapper.annotations.AerospikeKey;
import com.aerospike.mapper.annotations.AerospikeRecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@AerospikeRecord(namespace = "test", set = "edp_virus_scan")
public class McAfeeEntity{
	
	@AerospikeKey
	@AerospikeBin(name ="PK")
	private Long pk;
	@AerospikeBin(name ="QUARANTINEPATH")
	private String quarantinePath;
	@AerospikeBin(name ="QTNSTATUS")
	private String quarantineStatus;
	@AerospikeBin(name ="INFECTED")
	private String infected;
	@AerospikeBin(name ="EXCEPTION")
	private String exception;
	@AerospikeBin(name ="UPLOADED")
	private String uploaded;
	@AerospikeBin(name ="LOANNO")
	private String loanNo;
	@AerospikeBin(name ="ROLENAME")
	private String roleName;
	@AerospikeBin(name ="DOCTYPEID")
	private String documentTypeId;
	@AerospikeBin(name ="CUSTOMERTYPE")
	private String customerType;
	@AerospikeBin(name ="APISTATUS")
	private String apiStatus;
	@AerospikeBin(name ="ISSUCCESS")
	private String isSuccess;
	@AerospikeBin(name ="DOCUMENTTYPE")
	private String documentType;
	@AerospikeBin(name ="DOCUMENTNAME")
	private String documentName;
	@AerospikeBin(name ="CUSTOMERID")
	private String custId;	
	@AerospikeBin(name ="UCIC")
	private String ucic;
	@AerospikeBin(name ="ACCOUNTNUMBER")
	private String accountNumber;	
	@AerospikeBin(name ="MOBILENUMBER")
	private Long  mobileNumber;
	@AerospikeBin(name ="SOURCE")
	private String source;
	@AerospikeBin(name ="AGREEMENTID")
	private String aggrementId;
	@AerospikeBin(name ="CATEGORY")
	private String category;
	@AerospikeBin(name ="PRODUCTNAME")
	private String productName;
	@AerospikeBin(name ="CUSTOMERNAME")
	private String custName;
	@AerospikeBin(name ="EMAILID")
	private String emailId;
	@AerospikeBin(name ="CREATEDDATE")
	private String createdDate;
	@AerospikeBin(name ="CREATEDBY")
	private String createdBy;
	@AerospikeBin(name ="UPDATEDBY")
	private String updatedBy;
	@AerospikeBin(name ="UPDATEDDATE")
	private String updatedDate;
	

	
}
