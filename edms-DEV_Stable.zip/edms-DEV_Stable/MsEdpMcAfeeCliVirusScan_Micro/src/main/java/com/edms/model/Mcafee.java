package com.edms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Mcafee {	
	
	private boolean infected;
	private String result;
	private String engine;
	private String database;
	private String updated;
	private String error;
	private String errorCode;
	private String fileName;
	
}
