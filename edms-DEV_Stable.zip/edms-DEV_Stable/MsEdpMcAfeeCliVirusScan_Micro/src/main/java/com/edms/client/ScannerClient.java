package com.edms.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

import com.edms.domain.AuditLog;
import com.edms.exception.FileSizeExceedsException;
import com.edms.model.DocumentMetaData;
import com.edms.model.McAfeeEntity;
import com.edms.model.McAfeeResponse;
import com.edms.model.Mcafee;
import com.edms.repository.VirusScanRepository;

import static com.edms.util.Constants.*;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.MediaType;
import io.micronaut.http.client.HttpClient;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.http.client.multipart.MultipartBody;
import io.micronaut.http.multipart.CompletedFileUpload;
import io.micronaut.http.uri.UriBuilder;
import io.micronaut.scheduling.annotation.Async;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

import static io.micronaut.http.HttpHeaders.ACCEPT;
import static io.micronaut.http.HttpHeaders.USER_AGENT;

import io.micronaut.context.annotation.Value;

@Singleton
@Slf4j
public class ScannerClient {

	@Value("${file.quarantineLocation}")
	private String quarantineLocation;

	@Value("${file.uploadLocation}")
	private String uploadLocation;

	@Inject
	private VirusScanRepository repository;
	
	@Inject 
	private AuditLogClient auditLogClient;

	private HttpClient httpClient = null;
	private final URI uri;

	public ScannerClient(@Client HttpClient httpClient) {
		this.httpClient = httpClient;
		uri = UriBuilder.of(SCANURL).path(SCAN).build();
	}

	public McAfeeResponse scanFile(DocumentMetaData request,CompletedFileUpload malware) throws Exception {
		
		File uploadDir = new File(uploadLocation);
		File qurantineDir = new File(quarantineLocation);
		McAfeeEntity mcafee = new McAfeeEntity();
		McAfeeResponse response = new McAfeeResponse();
		if (!uploadDir.exists()) {
			uploadDir.mkdirs();
			uploadDir.setWritable(true);
		} else if (!qurantineDir.exists()) {
			qurantineDir.mkdirs();
			qurantineDir.setWritable(true);
		}

		File uploadedFile = null;

		try (InputStream malwareInp = malware.getInputStream()) {

			String tempDir = uploadDir.getAbsolutePath();
			log.info(tempDir);

			uploadedFile = new File(tempDir + "\\" + malware.getFilename());

			if (!uploadedFile.exists()) {
				Files.copy(malwareInp, uploadedFile.toPath());
			}
			if (uploadedFile.length() > 10 * 1024 * 1024) {

				throw new FileSizeExceedsException(FILE_SIZE_EXCEEDS);

			}
			MultipartBody multipart = MultipartBody.builder().addPart("malware", uploadedFile).build();
			HttpRequest<?> req = HttpRequest.POST(uri, multipart).header(USER_AGENT, "Micronaut HTTP Client")
					.header(ACCEPT, "application/json").header("content-type", MediaType.MULTIPART_FORM_DATA)
					.setAttribute("malware", uploadedFile);

			response = httpClient.toBlocking().exchange(req, McAfeeResponse.class).body();
			Mcafee responseObj = response.getMcafee();
			responseObj.setFileName(uploadedFile.getName());
			response.setMcafee(responseObj);
			if (response.getMcafee().isInfected()) {

				if (!qurantineDir.exists()) {
					qurantineDir.mkdirs();
					qurantineDir.setWritable(true);
				}
				Path dest = new File(qurantineDir, uploadedFile.getName()).toPath();
				
				FileInputStream source = new FileInputStream(uploadedFile);
				FileOutputStream destination = new FileOutputStream(dest.toFile());
				byte[] buffer = new byte[1024];
				int length;
				while ((length = source.read(buffer)) > 0) {
				    destination.write(buffer, 0, length);
				}
				source.close();
				destination.close();
				//FileCopyUtils.copy(uploadedFile, dest.toFile());
				uploadedFile.delete();
				log.info("Infected File is moved to Quarantine zone Path: " + dest.toAbsolutePath());
				mcafee.setPk(repository.findAll().size()+1L);
				mcafee.setException(EXP_200);
				mcafee.setApiStatus("EXP_200 Reason-  File Scanned SuccessFully");
				mcafee.setInfected(TRUE);
				mcafee.setIsSuccess(YES);
				mcafee.setQuarantineStatus(TRUE);
				mcafee.setQuarantinePath(dest.toString());
				mcafee.setAccountNumber(request.getAccountNumber());
				mcafee.setDocumentName(request.getDocumentName());
				mcafee.setDocumentType(request.getDocumentType());
				mcafee.setSource(request.getSource());
				mcafee.setCategory(request.getCategory());
				mcafee.setCustId(request.getCustId());
				mcafee.setCustName(request.getCustName());
				mcafee.setProductName(request.getProductName());
				mcafee.setMobileNumber(9096484848L);
				mcafee.setCreatedBy(request.getCreatedBy());
				mcafee.setCreatedDate(request.getCreatedDate());
				mcafee.setDocumentTypeId(request.getDocTypeId());
				mcafee.setCustomerType(request.getCustomerType());
				mcafee.setRoleName(String.join(",", request.getRoleName()));
				mcafee.setLoanNo(request.getLoanNo());
				mcafee.setUpdatedBy(request.getUpdatedBy());
				mcafee.setUpdatedDate(request.getUpdatedDate());				
				repository.save(mcafee);
				
				AuditLog auditLog = AuditLog.builder().action(AV_SCAN).category(AV_SCAN).createdBy(request.getCreatedBy())
						.createdDate(request.getCreatedDate()).currentValue("").customerId(request.getCustId())
						.lastUpdateDate(request.getCreatedDate()).modifiedBy(request.getCreatedBy()).oldValue("").roleName("")
						.productName(request.getProductName()).documentName(request.getDocumentName()).ucic(request.getUcic())
						.agreementId(request.getAggrementId()).accountNumber(request.getAccountNumber())
						.documentType(request.getDocumentType()).screenName(AV_SCAN)
						.sourceName(request.getSource()).status(FAILED).message(malware.getName()
								+ " is infected and quarantined at"+mcafee.getQuarantinePath())
						.build();
				auditLog(auditLog);				
				
			} else {
				mcafee.setPk(UUID.randomUUID().getLeastSignificantBits() & Long.MAX_VALUE);
				mcafee.setAccountNumber(request.getAccountNumber());
				mcafee.setDocumentName(request.getDocumentName());
				mcafee.setDocumentType(request.getDocumentType());
				mcafee.setProductName(request.getProductName());
				mcafee.setSource(request.getSource());
				mcafee.setCategory(request.getCategory());
				mcafee.setCustId(request.getCustId());
				mcafee.setCustName(request.getCustName());
				mcafee.setException(EXP_200);
				mcafee.setApiStatus("EXP_200 Reason-  File Scanned SuccessFully");
				mcafee.setInfected(FALSE);
				mcafee.setIsSuccess(YES);
				mcafee.setQuarantineStatus("false");
				mcafee.setQuarantinePath("");
				mcafee.setCreatedBy(request.getCreatedBy());
				mcafee.setCreatedDate(request.getCreatedDate());
				mcafee.setDocumentTypeId(request.getDocTypeId());
				mcafee.setCustomerType(request.getCustomerType());
				mcafee.setRoleName(String.join(",", request.getRoleName()));
				mcafee.setLoanNo(request.getLoanNo());
				mcafee.setUpdatedBy(request.getUpdatedBy());
				mcafee.setUpdatedDate(request.getUpdatedDate());
				repository.save(mcafee);
				AuditLog auditLog = AuditLog.builder().action(AV_SCAN).category(AV_SCAN).createdBy(request.getCreatedBy())
						.createdDate(request.getCreatedDate()).currentValue("").customerId(request.getCustId())
						.lastUpdateDate(request.getCreatedDate()).modifiedBy(request.getCreatedBy()).oldValue("").roleName("")
						.productName(request.getProductName()).documentName(request.getDocumentName()).ucic(request.getUcic())
						.agreementId(request.getAggrementId()).accountNumber(request.getAccountNumber())
						.documentType(request.getDocumentType()).screenName(AV_SCAN).sourceName(request.getSource())
						.status(SUCCESS).message(malware.getName()+ " is scanned and sent for upload")
						.build();
				auditLog(auditLog);		
			}

		} catch (Exception e) {
			mcafee.setPk(UUID.randomUUID().getLeastSignificantBits() & Long.MAX_VALUE);
			mcafee.setAccountNumber(request.getAccountNumber());
			mcafee.setDocumentName(request.getDocumentName());
			mcafee.setDocumentType(request.getDocumentType());
			mcafee.setProductName(request.getProductName());
			mcafee.setSource(request.getSource());
			mcafee.setCategory(request.getCategory());
			mcafee.setCustId(request.getCustId());
			mcafee.setCustName(request.getCustName());
			mcafee.setException(EXP_400);
			mcafee.setApiStatus(EXP_400 + " "+e.getMessage());
			mcafee.setInfected(FAILED);
			mcafee.setIsSuccess(NO);
			mcafee.setQuarantineStatus(FAILED);
			mcafee.setQuarantinePath("");
			mcafee.setCreatedBy(request.getCreatedBy());
			mcafee.setCreatedDate(request.getCreatedDate());
			mcafee.setDocumentTypeId(request.getDocTypeId());
			mcafee.setCustomerType(request.getCustomerType());			
			mcafee.setRoleName(String.join(",", request.getRoleName()));
			mcafee.setLoanNo(request.getLoanNo());
			mcafee.setUpdatedBy(request.getUpdatedBy());
			mcafee.setUpdatedDate(request.getUpdatedDate());
			repository.save(mcafee);
			
			AuditLog auditLog = AuditLog.builder().action(AV_SCAN).category(AV_SCAN).createdBy(request.getCreatedBy())
					.createdDate(request.getCreatedDate()).currentValue("").customerId(request.getCustId())
					.lastUpdateDate(request.getCreatedDate()).modifiedBy(request.getCreatedBy()).oldValue("").roleName("")
					.productName(request.getProductName()).documentName(request.getDocumentName()).ucic(request.getUcic())
					.agreementId(request.getAggrementId()).accountNumber(request.getAccountNumber())
					.documentType(request.getDocumentType()).screenName(AV_SCAN).failedStage(AV_SCAN)
					.sourceName(request.getSource()).status(FAILED).message(malware.getName()
							+ " is infected and quarantined at"+mcafee.getQuarantinePath())
					.build();
			auditLog(auditLog);		
			throw e;
		}
		return response;
	}
	
	@Async
	public void auditLog(AuditLog auditLog) {
		auditLogClient.addAuditLog(auditLog);
	}
}
