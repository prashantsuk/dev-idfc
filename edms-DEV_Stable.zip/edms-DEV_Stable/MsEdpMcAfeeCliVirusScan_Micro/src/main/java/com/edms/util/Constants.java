package com.edms.util;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class Constants {

	protected static final Set<String> FILE_TYPE = new HashSet<>();

	protected static final String[] ZIP_TYPES = { "application/vnd.rar", "application/x-rar-compressed",
			"application/octet-stream", "application/octet-stream", "application/x-zip-compressed", "multipart/x-zip" };

	private Constants() {
	}

	public static final String EXP_400 = "EXP_400";
	public static final String EXP_200 = "EXP_200";
	public static final String EXP_409 = "EXP_409";
	public static final String EXP_415 = "EXP_415";
	public static final String EXP_404 = "EXP_404";
	public static final String EXP_405 = "EXP_405";
	public static final String EXP_503 = "EXP_503";
	public static final String EXP_500 = "EXP_500";
	public static final String EXP_504 = "EXP_504";

	public static final String SYS_400 = "SYS_400";
	public static final String SYS_415 = "SYS_415";
	public static final String SYS_404 = "SYS_404";
	public static final String SYS_405 = "SYS_405";
	public static final String SYS_503 = "SYS_503";
	public static final String SYS_500 = "SYS_500";
	public static final String SYS_504 = "SYS_504";
	public static final String REASON_200 =EXP_200+" Reason - File Uploaded SuccessFully";

	protected static final String[] ASSET_PROPERTIES = { "CF_DocumentName", "DocumentTitle", "CF_DocumentTypeName",
			"CF_UploadedBy", "CF_OriginalPhotocopy", "CF_Mandatory", "CF_DealerOnboardingID", "CF_FinnOneLoanNumber",
			"CF_CRMId", "CF_ApplicationId" };

	protected static final Map<String, String> errorDef = new HashMap<>();

	static {
		errorDef.put(EXP_400, "Bad Request");
		errorDef.put(SYS_400, "Bad Request");
		errorDef.put(EXP_404, "Resource not found");
		errorDef.put(SYS_404, "Resource not found");
		errorDef.put(EXP_415, "Unsupported Media type");
		errorDef.put(SYS_415, "Unsupported Media type");
		errorDef.put(EXP_405, "Method not allowed");
		errorDef.put(SYS_405, "Method not allowed");
		errorDef.put(EXP_503, "Connectivity Error");
		errorDef.put(SYS_503, "Connectivity Error");
		errorDef.put(EXP_500, "Internal Server error");
		errorDef.put(SYS_500, "Internal Server error");
		errorDef.put(EXP_504, "HTTP Request timeout");
		errorDef.put(SYS_504, "HTTP Request timeout");
	}

	public static final String UPLOAD_SUCCESS = "Keep DocumentIndex,IsIndex and FolderIndex for future reference.";

	public static final String ADD_FOLDER_SUCCESS = "Folder added successfully. Keep FolderIndex for future reference.";

	public static final String OK = "OK";

	public static final String REPLY = "Reply";

	public static final String EXCEPTION_OCCURED = "Exception occured: {}";

	public static final String UPLOAD_DOC = "uploadDoc";

	public static final String DOC_MGMT = "doc-mgmt";

	public static final String ERROR = "Error";

	public static final String NO = "N";
	
	public static final String YES = "Y";


	public static final String SLASH = "/";

	public static final String DOLLAR = "$";
	public static final String EMAIL_ID ="customerName@idfc.com";

	public static final String UNDERSCORE_V = "_V";

	public static final String EDP = "EDP";
	
	public static final String KB = "KB";

	public static final String SIXTEEN_DIGIT_FORMAT = "%016d";

	public static final String IDFCEDP = "IDFCEDP/";
	
	public static final String REASON_400 = EXP_400+" Reason : - ";

	public static final String FILE_NOT_EXISTS = "File doesn't exist";
	public static final String INVALID_PASSWORD = "File password doesn't match";

	public static final String FILE_SIZE_EXCEEDS = "File Size exceeds the limit of 10MB";

	public static final String INVALID_MIMETYPE = "Invalid File: Mime Type not supported: ";
	public static final String CONFIG_RESOURCE = "aerospike";
	public static final String SECRET_KEY = "THIS_IS_MY_SECRET_KEY_FOR_FILE_ENCRYPTION_DECRYPTION";
	public static final String BASE64 = "base64";
	public static final String FAILED_SCAN= "Failed to Scan File";

	static {
		FILE_TYPE.add("corrupted");
		FILE_TYPE.add("application/pdf");
		FILE_TYPE.add("application/zip");
		FILE_TYPE.add("text/plain");
		FILE_TYPE.add("application/msword");
		FILE_TYPE.add("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		FILE_TYPE.add("image/tiff");
		FILE_TYPE.add("image/jpeg");
		FILE_TYPE.add("application/vnd.ms-excel");
		FILE_TYPE.add("application/vnd. openxmlformats-officedocument .spreadsheetml. sheet");
		FILE_TYPE.add("application/vnd.ms-excel.sheet.binary.macroEnabled.12");
		FILE_TYPE.add("message/rfc822");
		FILE_TYPE.add("text/html");
		FILE_TYPE.add("image/png");
		FILE_TYPE.add("application/vnd.ms-outlook");
		FILE_TYPE.add("application/ppt");
		FILE_TYPE.add("application/vnd.openxmlformats-officedocument.presentationml.presentation");
		FILE_TYPE.add("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
		FILE_TYPE.add("text/csv");
		FILE_TYPE.add("application/zip");
		FILE_TYPE.add("application/x-tika-ooxml");
		FILE_TYPE.addAll(Arrays.asList(ZIP_TYPES));
		FILE_TYPE.add("application/vnd.openxmlformats-officedocument.wordprocessingml.document");
		FILE_TYPE.add("application/vnd.openxmlformats-officedocument.wordprocessingml.template");
		FILE_TYPE.add("application/vnd.ms-word.document.macroEnabled.12");
		FILE_TYPE.add("application/vnd.ms-word.template.macroEnabled.12");
	}
	public static final String ASSETS_NAMESPACE = "test";
	public static final String ASSETS_SET = "edp_assets";

	public static final String ASSETS = "Assets";

	public static final String CUSTOMER = "Customer";

	public static final String IDFC_PRI = "IDFC_PRI";
	public static final String ENV_LOCAL = "local";
	public static final String ENV_DEV = "dev";
	public static final String SCANURL = "http://52.140.58.184:3993";
	public static final String SCAN = "/scan";
	public static final String AV_SCAN ="AV SCAN";
	
	public static final String ACTION_VIEW ="VIEW";
	public static final String ACTION_DWNLD ="DOWNLOAD";
	public static final String ACTION_UPLD ="UPLOAD";
	
	public static final String TRUE ="true";
	public static final String FALSE = "false";
	
	public static final String DOC_PENDING="PENDING";
	public static final String DOC_NOT_PENDING="NOT_PENDING";
	
	public static final String FAILED = "FAILED";
	public static final String UPLOADED = "UPLOADED";
	public static final String SUCCESS = "SUCCESS";

}
