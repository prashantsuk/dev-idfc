package com.edms.model;

import java.util.List;
import com.fasterxml.jackson.annotation.JsonRootName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Builder
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonRootName(value = "ScanResults")
public class McAfeeResponse {

	private Mcafee mcafee;
}
