package com.edms.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.reactivestreams.Publisher;
import org.reactivestreams.Subscriber;
import org.reactivestreams.Subscription;

import com.edms.client.ScannerClient;
import com.edms.exception.FileSizeExceedsException;
import com.edms.model.DocumentMetaData;
import com.edms.model.McAfeeResponse;
import com.edms.model.Mcafee;
import com.edms.util.Utilities;
import static com.edms.util.Constants.*;

import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.RequestAttribute;
import io.micronaut.http.multipart.CompletedFileUpload;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.rules.SecurityRule;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;
import reactor.core.publisher.Sinks;
import reactor.core.publisher.Sinks.One;

@Controller
@Slf4j
@Secured(SecurityRule.IS_AUTHENTICATED)
public class VirusScanController {

	@Inject
	ScannerClient scannerClient;
	
	Integer fileCount = 0;

	@Post(consumes = { MediaType.MULTIPART_FORM_DATA }, uri = "/scanFile")
	public MutableHttpResponse<McAfeeResponse> scanFile(@RequestAttribute String metadata,CompletedFileUpload malware,
			HttpHeaders headers) throws Exception {
		
		DocumentMetaData docData = Utilities.mapJsonToDto(metadata);
		
		log.info("Scan Started For file"+malware.getName());
		McAfeeResponse response = new McAfeeResponse();		
		response = scannerClient.scanFile(docData, malware);		
		return HttpResponse.ok(response);
	}

}
