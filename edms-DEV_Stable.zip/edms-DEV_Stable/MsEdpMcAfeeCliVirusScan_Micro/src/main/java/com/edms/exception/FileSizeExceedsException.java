package com.edms.exception;

public class FileSizeExceedsException extends Exception {

	private static final long serialVersionUID = 1L;
	
    public FileSizeExceedsException(String errorMessage) {  
    super(errorMessage);  
    }  
	
}
