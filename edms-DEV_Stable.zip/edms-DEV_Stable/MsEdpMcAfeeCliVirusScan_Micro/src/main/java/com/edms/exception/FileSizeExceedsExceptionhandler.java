package com.edms.exception;

import com.edms.model.McAfeeResponse;
import com.edms.model.Mcafee;

import static com.edms.util.Constants.*;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

@Produces
@Singleton
@Requires(classes = { FileSizeExceedsException.class, ExceptionHandler.class })
@Slf4j
public class FileSizeExceedsExceptionhandler implements ExceptionHandler<FileSizeExceedsException, HttpResponse> {

	@Override
	public HttpResponse handle(HttpRequest request, FileSizeExceedsException exception) {

		log.error(EXCEPTION_OCCURED, exception);
		Mcafee mcafee = Mcafee
				.builder().result(FAILED).error(exception.getMessage()).errorCode(EXP_400).build();
		McAfeeResponse responseMsg = McAfeeResponse.builder()
				.mcafee(mcafee).build();
		return HttpResponse.badRequest(responseMsg);
	}

}
