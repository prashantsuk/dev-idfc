package com.edms.service;

public interface VirusScanService {

}
