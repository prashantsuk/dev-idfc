package com.edms.util;

import com.edms.model.DocumentMetaData;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;

public class Utilities {

	public static DocumentMetaData mapJsonToDto(String metaData) throws JsonProcessingException {

		DocumentMetaData metaDataObj = new DocumentMetaData();
		try {
			ObjectMapper mapper = new ObjectMapper();
			JsonNode rootNode = mapper.readTree(metaData);
			metaDataObj = mapper.treeToValue(rootNode, DocumentMetaData.class);
		} catch (JsonProcessingException e) {
			throw e;
		}
		return metaDataObj;
	}
}
