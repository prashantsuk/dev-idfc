package com.edms.repository;

import java.util.List;

import com.aerospike.client.AerospikeClient;

import com.aerospike.client.policy.Policy;

import com.aerospike.mapper.tools.AeroMapper;
import com.edms.model.McAfeeEntity;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class VirusScanRepository {

	@Inject
	AeroMapper aeroMapper;

	Policy policy = new Policy();

	@Inject
	private AerospikeClient readClient;

	@Inject
	private AerospikeClient writeClient;

	public List<McAfeeEntity> findAll() {
		return aeroMapper.scan(McAfeeEntity.class);
	}

	public void save(McAfeeEntity mcAfeeEntity) {
		aeroMapper.save(mcAfeeEntity);
	}


}

