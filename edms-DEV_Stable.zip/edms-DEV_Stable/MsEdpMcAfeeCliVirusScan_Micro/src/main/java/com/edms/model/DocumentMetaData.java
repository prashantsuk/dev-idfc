package com.edms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DocumentMetaData {

		private String documentType;
		private String documentName;
		private String custId;	
		private String ucic;
		private String accountNumber;	
		private Long  mobileNumber;
		private String source;
		private String aggrementId;
		private String category;
		private String productName;
		private String custName;
		private String emailId;
		private String isSuccess;
		private String apiStatus;
		private String exception;
		private String loanNo;
		private String createdDate;
		private String createdBy;
		private String updatedDate;
		private String updatedBy;
		private String docTypeId;
        private String customerType;
        private String[] roleName;
		
	}

