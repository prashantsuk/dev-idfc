package com.edms.controller;


import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.URL;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.edms.model.DocumentResponse;
import com.edms.model.FileDetails;
import com.edms.service.DocVerifierService;
import com.edms.service.DocVerifierServiceImpl;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.client.HttpClient;
import io.micronaut.runtime.server.EmbeddedServer;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;

@MicronautTest
class DocumentVerifierControllerTest {
	
	@Inject
	EmbeddedServer server;
	
	@Inject
	DocVerifierService docVerifierService;
	
	@MockBean(DocVerifierServiceImpl.class)
	DocVerifierService mockDocVerifierService() {
		return mock(DocVerifierService.class);
	}
	
	DocumentVerifierController controller = new DocumentVerifierController();
	
	
	@BeforeEach
	public void setUp() {
		controller.setDocVerifierService(docVerifierService);
		
	}
	
	@Test
	void testDocVerify() throws Exception {
		FileDetails fileDetails = new FileDetails();
		DocumentResponse documentResponse = new DocumentResponse();
		fileDetails.setFileName("statement.pdf");
		fileDetails.setBase64("base64");
		fileDetails.setPassword("11223344");
		documentResponse.setValidDocument(true);
		documentResponse.setErrMessage("No Error");
		when(docVerifierService.docVerifier(fileDetails)).thenReturn(documentResponse);
		HttpClient client = HttpClient.create(new URL("http://" + server.getHost()+":"+ server.getPort()));
		HttpResponse<?> response = client.toBlocking().exchange(HttpRequest.POST("/docVerify",fileDetails), DocumentResponse.class);
		Assertions.assertEquals(200, response.code());
		//Assertions.assertEquals(documentResponse, response.getBody().get());
	}
	
	
}
