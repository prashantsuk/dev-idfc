package com.edms.constant;

public class Constants {

	public static final String INVALID_FILE_SIZE = "File size is greater than 10 MB";
	public static final String FILE_NOT_FOUND = "File not found";
	public static final String INVALID_PASSWORD = "Invalid document Password. Please provide valid document password";
	public static final String INVALID_MIME_TYPE = "Invalid MIME Type";
	public static final String INVALID_FILE = "Invalid File";
	public static final String PASSWORD_REQUIRED = "Enter valid password";
	public static final String SLASH =  "/";
}
