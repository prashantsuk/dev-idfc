package com.edms.constant;

import java.util.ArrayList;
import java.util.List;

public class FileType {
	
	private FileType() {
		super();
	}

	public static final String MIME_PDF = "application/pdf";
	public static final String MIME_ZIP = "application/zip";
	public static final String MIME_XLS = "application/vnd.ms-excel";
	public static final String MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
	public static final String MIME_DOC = "application/msword";
	public static final String MIME_DOCX = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";
	
	public static final String MIME_TEXT = "text/plain";
	public static final String MIME_TIF = "image/tiff";
	public static final String MIME_TIFF = "image/tiff";
	public static final String MIME_JPG = "image/jpeg";
	public static final String MIME_JPE =  "image/jpeg";
	public static final String MIME_JPEG = "image/jpeg";


	public static final String MIME_XLSB = "application/vnd.ms-excel.sheet.binary.macroEnabled.12";
	public static final String MIME_EML = "message/rfc822";
	public static final String MIME_HTML = "text/html";
	public static final String MIME_HTM	 = "text/html";
	public static final String MIME_PNG = "image/png";
	public static final String MIME_MSG = "application/vnd.ms-outlook";
	public static final String MIME_PPT = "application/ppt";
	public static final String MIME_PPTX = "application/vnd.openxmlformats-officedocument.presentationml.presentation";
	public static final String MIME_PPTMS = "application/vnd.ms-powerpoint";
	public static final String MIME_CSV = "text/csv";
	
	public static List<String> addPasswordLessMIME() {
		List<String> mimeTypes = new ArrayList<>();
		mimeTypes.add(MIME_TEXT);
		mimeTypes.add(MIME_TIF);
		mimeTypes.add(MIME_TIFF);
		mimeTypes.add(MIME_JPG);
		mimeTypes.add(MIME_JPE);
		mimeTypes.add(MIME_JPEG);
		mimeTypes.add(MIME_XLSB);
		mimeTypes.add(MIME_EML);
		mimeTypes.add(MIME_HTML);
		mimeTypes.add(MIME_HTM);
		mimeTypes.add(MIME_PNG);
		mimeTypes.add(MIME_MSG);
		mimeTypes.add(MIME_PPT);
		mimeTypes.add(MIME_PPTX);
		mimeTypes.add(MIME_PPTMS);
		mimeTypes.add(MIME_CSV);
		return mimeTypes;
	}

}
