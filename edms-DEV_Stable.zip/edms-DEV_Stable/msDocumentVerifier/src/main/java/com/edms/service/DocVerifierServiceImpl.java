package com.edms.service;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.FileNameMap;
import java.net.URLConnection;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.GeneralSecurityException;
import java.util.Base64;


import org.apache.commons.io.FileUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.encryption.InvalidPasswordException;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.OLE2NotOfficeXmlFileException;
import org.apache.poi.poifs.crypt.Decryptor;
import org.apache.poi.poifs.crypt.EncryptionInfo;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xwpf.usermodel.XWPFDocument;

import com.edms.constant.Constants;
import com.edms.constant.FileType;
import com.edms.model.DocumentResponse;
import com.edms.model.FileDetails;

import io.micronaut.context.annotation.Value;
import jakarta.inject.Singleton;
import net.lingala.zip4j.ZipFile;
import net.lingala.zip4j.exception.ZipException;

@Singleton
public class DocVerifierServiceImpl implements DocVerifierService{

	@Value("${file.path}")
	String path;
	
	@Value("${file.size}")
	Double size;
	
	@Override
	public DocumentResponse docVerifier(FileDetails fileDetails) throws Exception {
			DocumentResponse documentVerificationRes = new DocumentResponse();
			documentVerificationRes.setValidDocument(true);
			File file = new File(path+File.separator+fileDetails.getFileName());
			checkFileSizeAndFileExistance(documentVerificationRes, fileDetails, file);
			if(!documentVerificationRes.getValidDocument()) {
				return documentVerificationRes;
			}
			FileNameMap fileNameMap = URLConnection.getFileNameMap();
			String mimeType = fileNameMap.getContentTypeFor(file.getName());
			if (documentVerificationRes.getValidDocument() && FileType.MIME_PDF.equalsIgnoreCase(mimeType)) {
				validatePDFFile(documentVerificationRes, fileDetails, file);
				
			} else if (documentVerificationRes.getValidDocument() && FileType.MIME_ZIP.equalsIgnoreCase(mimeType)) {
				validateZIPFile(documentVerificationRes, fileDetails);

			}else if (documentVerificationRes.getValidDocument() && (FileType.MIME_XLS.equalsIgnoreCase(mimeType)|| FileType.MIME_XLSX.equalsIgnoreCase(mimeType))) {
				validateExcelFile(documentVerificationRes, fileDetails, file);
			} else if (documentVerificationRes.getValidDocument() && (FileType.MIME_DOCX.equalsIgnoreCase(mimeType) || FileType.MIME_DOC.equalsIgnoreCase(mimeType))) {
				validateDocFile(documentVerificationRes, fileDetails, file);
			}else if(documentVerificationRes.getValidDocument() && FileType.addPasswordLessMIME().contains(mimeType)) {
				documentVerificationRes.setValidDocument(true);
			}else {
				setErrorMsg(documentVerificationRes, Constants.INVALID_MIME_TYPE);
			}
			deleteFile(fileDetails, file);
			return documentVerificationRes;
	}
	
	private String convertBase64ToStringFile(FileDetails fileDetails, String location ) throws IOException {
        try(FileOutputStream fos =  new FileOutputStream(location+"/"+fileDetails.getFileName())){
            byte[] byt=Base64.getDecoder().decode(actualBase64(fileDetails.getBase64()));
            fos.write(byt);
            return location+File.separator+fileDetails.getFileName();
        }
    }
	
	private Double calcBase64SizeInMb(String base64String) {
            Integer padding = 0;
            if(base64String.endsWith("==")) {
                padding = 2;
            }
            else {
                if (base64String.endsWith("=")) padding = 1;
            }
            Double result = (Math.ceil(actualBase64(base64String).length() / 4d) * 3 ) - padding;
        
        return result / (1024*1024);
    }
	
	private String actualBase64(String base64Image) {
		if(base64Image.contains("base64,"))
        {
			return base64Image.substring(base64Image.indexOf(',')+1);
        }
		return base64Image;
	}
	
	private void getRelevantErrorMsg(DocumentResponse documentVerificationRes, FileDetails fileDetails) {
		documentVerificationRes.setValidDocument(false);
		if(fileDetails.getPassword() != null) {
			documentVerificationRes.setErrMessage(Constants.INVALID_PASSWORD);
		}else {
			documentVerificationRes.setErrMessage(Constants.PASSWORD_REQUIRED);
		}
	}
	
	private void setErrorMsg(DocumentResponse documentVerificationRes, String errorMsg) {
		documentVerificationRes.setValidDocument(false);
		documentVerificationRes.setErrMessage(errorMsg);
	}
	
	private void checkFileSizeAndFileExistance(DocumentResponse documentVerificationRes, FileDetails fileDetails, File file) {
		if(calcBase64SizeInMb(fileDetails.getBase64())>size) {
			setErrorMsg(documentVerificationRes, Constants.INVALID_FILE_SIZE);
		}
		File directory=new File(path);
		try {
			if(!directory.exists()) {
				directory.mkdirs();
			}
			file = new File(convertBase64ToStringFile(fileDetails, path));
		} catch (Exception e) {
			setErrorMsg(documentVerificationRes, Constants.INVALID_FILE);
		}
		if (!file.exists()) {
			setErrorMsg(documentVerificationRes, Constants.FILE_NOT_FOUND);
		}
	}
	
	private void validatePDFFile(DocumentResponse documentVerificationRes, FileDetails fileDetails, File file) throws IOException {
		try(InputStream fis = new ByteArrayInputStream(FileUtils.readFileToByteArray(file)); PDDocument doc = PDDocument.load(fis, fileDetails.getPassword())){
			documentVerificationRes.setValidDocument(true);
		} catch (InvalidPasswordException e) {
			getRelevantErrorMsg(documentVerificationRes, fileDetails);
		}
	}
	
	private void validateZIPFile(DocumentResponse documentVerificationRes, FileDetails fileDetails) throws IOException{
		ZipFile zipFile = null;
		  try {
				if (fileDetails.getPassword() != null) {
					zipFile = new ZipFile(path + fileDetails.getFileName(), fileDetails.getPassword().toCharArray());
				}else {
					zipFile = new ZipFile(path + fileDetails.getFileName());
				}
				zipFile.extractAll(path);
				documentVerificationRes.setValidDocument(true);
				zipFile.close();
				FileUtils.cleanDirectory(new File(path));
			} catch (ZipException e) {
				getRelevantErrorMsg(documentVerificationRes, fileDetails);
				zipFile.close();
			}
	}
	
	private void validateDocFile(DocumentResponse documentVerificationRes, FileDetails fileDetails, File file) throws IOException, GeneralSecurityException{
		try (FileInputStream fis = new FileInputStream(file.getAbsolutePath()); XWPFDocument document = new XWPFDocument(fis)) {
			if (document.isEnforcedProtection()) {
				boolean validFlag = document.validateProtectionPassword(fileDetails.getPassword());
				documentVerificationRes.setValidDocument(validFlag);
				if(!validFlag) {
					getRelevantErrorMsg(documentVerificationRes, fileDetails);
				}
			}else {
				documentVerificationRes.setValidDocument(true);
			}
		} catch (OLE2NotOfficeXmlFileException fe) {
			POIFSFileSystem fs = new POIFSFileSystem(new FileInputStream(file));
			EncryptionInfo info = new EncryptionInfo(fs);
			Decryptor doc = Decryptor.getInstance(info);
			if(fileDetails.getPassword() != null) {
				boolean validFlag = doc.verifyPassword(fileDetails.getPassword());
				documentVerificationRes.setValidDocument(validFlag);
				if(!validFlag) {
					getRelevantErrorMsg(documentVerificationRes, fileDetails);
				}
			}else {
				documentVerificationRes.setValidDocument(true);
			}
		} catch (Exception ex) {
			getRelevantErrorMsg(documentVerificationRes, fileDetails);
		}
	}
	
	private void validateExcelFile(DocumentResponse documentVerificationRes, FileDetails fileDetails, File file) throws IOException{
		
		try(FileInputStream fileInput = new FileInputStream(file); Workbook workbook = WorkbookFactory.create(fileInput, fileDetails.getPassword())){
			documentVerificationRes.setValidDocument(true);
		} catch (EncryptedDocumentException ex) {
			getRelevantErrorMsg(documentVerificationRes, fileDetails);
		}
	}
	
	private void deleteFile(FileDetails fileDetails, File file) throws IOException {
		if(file.exists()) {
			Path pathOfFile = Paths.get(path+fileDetails.getFileName());
			Files.delete(pathOfFile);
		}
	}

	//It is for JUnit test only
	public void setPath(String path) {
		this.path = path;
	}

	public void setSize(Double size) {
		this.size = size;
	}

}
