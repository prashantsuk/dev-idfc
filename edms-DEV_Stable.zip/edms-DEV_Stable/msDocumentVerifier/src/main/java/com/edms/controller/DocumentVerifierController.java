package com.edms.controller;

import com.edms.model.DocumentResponse;
import com.edms.model.FileDetails;
import com.edms.service.DocVerifierService;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import jakarta.inject.Inject;

@Controller
public class DocumentVerifierController {
	
	@Inject
	private DocVerifierService docVerifierService;
	
	@Post("/docVerify")
	public HttpResponse<DocumentResponse> docVerify(@Body FileDetails fileDetails) throws Exception {
		return HttpResponse.ok(docVerifierService.docVerifier(fileDetails));
	}

	//It is for Junit test only
	public void setDocVerifierService(DocVerifierService docVerifierService) {
		this.docVerifierService = docVerifierService;
	}
	
	
}
