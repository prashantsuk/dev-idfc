package com.edms.service;

import com.edms.model.DocumentResponse;
import com.edms.model.FileDetails;

public interface DocVerifierService {
	
	public DocumentResponse docVerifier(FileDetails fileDetails) throws Exception;

}
