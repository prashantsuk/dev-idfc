package com.edms;

import io.micronaut.runtime.Micronaut;

public class DocumentVerifierApplication {

    public static void main(String[] args) {
        Micronaut.run(DocumentVerifierApplication.class, args);
    }
}