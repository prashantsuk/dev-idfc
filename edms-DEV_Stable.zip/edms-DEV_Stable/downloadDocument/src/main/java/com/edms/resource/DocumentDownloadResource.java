package com.edms.resource;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.edms.service.DocumentDownloadService;

@RestController
@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("download/")
public class DocumentDownloadResource {

	@Autowired
	private DocumentDownloadService documentDownloadService;

	@GetMapping(value = "/{fileName}")
	public @ResponseBody byte[] productImages(@PathVariable final String fileName, final String filePath,
			HttpServletRequest request, HttpServletResponse response) throws Exception {

		return documentDownloadService.downloadDocument(fileName, filePath, request, response);

	}

}
