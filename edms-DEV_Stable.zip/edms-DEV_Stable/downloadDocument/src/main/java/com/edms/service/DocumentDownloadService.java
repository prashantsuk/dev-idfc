package com.edms.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.edms.exception.DocumentFoundException;

@Service
public class DocumentDownloadService {

	private static final Logger log = LoggerFactory.getLogger(DocumentDownloadService.class);

	public byte[] downloadDocument(String fileName, String filePath, HttpServletRequest request,
			HttpServletResponse response) {

		log.info("Entered into File download menthod");

		FileInputStream fileInputStream = null;
		byte[] bytesArray = null;
		try {

			boolean check = new File(filePath + fileName).exists();
			if (!check)
				throw new DocumentFoundException("File not Found");

			final File file = new File(filePath + fileName);
			if (file != null) {
				response.setHeader("Content-Disposition", "attachment; filename=\"" + fileName + "\"");
			}
			bytesArray = new byte[(int) file.length()];
			fileInputStream = new FileInputStream(file);
			fileInputStream.read(bytesArray);

		} catch (final IOException e) {
			e.printStackTrace();

			log.error("Error occured while downloading the file");
		} finally {
			if (fileInputStream != null) {
				try {
					fileInputStream.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}

		}

		return bytesArray;
	}

}
