package com.edms;

import org.junit.jupiter.api.Assertions;


import com.edms.client.ScannerClient;

import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;


@MicronautTest
class VirusScanControllerTest {

	@Inject
	ScannerClient scannerClient;
   
}