package com.edms;

import io.micronaut.runtime.Micronaut;

public class MsEdpMcAfeeCliVirusScanApplication {

    public static void main(String[] args) {
        Micronaut.run(MsEdpMcAfeeCliVirusScanApplication.class, args);
    }
}