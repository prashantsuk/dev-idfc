package com.edms.service.liabilities;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.edms.domain.DocLiabilitiesEntity;
import com.edms.domain.PDBDocumentEntity;
import com.edms.model.DocumentData;
import com.edms.model.MsgBdy;
import com.edms.model.MsgHdr;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CommonService {
	
	@Value("${fileLocation}")
	private String fileLocation;

	public MsgBdy setMessageBody(String msg,String sts,PDBDocumentEntity entity,String fldrIndx, String isIndex,String base64Doc,DocLiabilitiesEntity docLiabilitiesEntity) {
		
		return MsgBdy.builder().msg(msg).sts(sts)./*docIndx(entity==null?null:String.valueOf(entity.getDocIndex())).*/fldrIndx(fldrIndx).isIndx(isIndex).
				bs64Doc(base64Doc).documentData(buildDocTable(docLiabilitiesEntity,base64Doc)).docIndx(docLiabilitiesEntity.getEdmsId()).build();
	}
	
	
	public MsgHdr setMessageHeader(String rslt) {
		
		return MsgHdr.builder().rslt(rslt).build();
	}
	
	public String encodeFileToBase64(File file) throws IOException {
	    
	    log.info("Converting file to base64 string");
	    	
	    byte[] fileContent = Files.readAllBytes(file.toPath());
	    return Base64.getEncoder().encodeToString(fileContent);
	   
	}
	
	
	public DocumentData buildDocTable(DocLiabilitiesEntity entity,String base64String)
	{
		return DocumentData.builder().edmsId(entity.getEdmsId()).docTitle(entity.getDocTitle()).docClass("").docType(entity.getDocType()).docName(entity.getDocName()).
		custName(entity.getCustomerName()).ucic(entity.getUcic()).acctNum(entity.getAccountNo()).barCodeNum(entity.getBarcodeNo()).fileSize(entity.getFileSize()).
		fileType(entity.getFileType()).noOfPages(entity.getNoOfPages()).owner(entity.getOwner()).mobNo(String.valueOf(entity.getMobileNo())).remarks(entity.getRemarks()).
		docNum(String.valueOf(entity.getDocNumber())).comments(entity.getComments()).multipageDoc(entity.getMultipageDoc()).source(entity.getSource()).uploadDate(entity.getUploadDate().toString()).
		modifiedDate(entity.getModifiedDate()==null?"": entity.getModifiedDate().toString()).expiryDate(entity.getExpiryDate()==null?"": entity.getExpiryDate().toString()).
		custId(entity.getCustomerId()).acceptedDate(entity.getAcceptedDate().toString()).createdDate(entity.getCreatedDate().toString()).createdBy(entity.getCreatedBy()).
		acceptedBy(entity.getAcceptedBy()).docEncrypt(entity.getDocEncrypt()).base64img(base64String).build();
		
	}
	
	public String converDateToString(Date date)
	{
		SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
			
	    String dateString = formatter.format(date);  
	    
	    return dateString; 
		    
	}
	
	public Date convertStringToDate(String dateString) throws ParseException
	{
		 SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");  
			
	     Date date = formatter.parse(dateString);  
	     return date; 
	}
}
