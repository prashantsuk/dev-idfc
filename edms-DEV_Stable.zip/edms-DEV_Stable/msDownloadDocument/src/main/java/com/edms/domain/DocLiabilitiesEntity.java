package com.edms.domain;

import java.util.Date;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.aerospike.mapping.Field;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "DOCLIABILITIESTABLE")
public class DocLiabilitiesEntity {
	
	@Id
	@Field("EDMSID")
	private String edmsId;
	
	@Field("AcceptedBy")
	private String acceptedBy;
	
	@Field("AcceptedDate")
	private Date acceptedDate;
	
	@Field("AccountNo")
	private String accountNo;
	
	@Field("BarcodeNo")
	private String barcodeNo;
	
	@Field("BranchID")
	private String branchId;
	
	@Field("Comments")
	private String comments;
	
	@Field("CreatedBy")
	private String createdBy;
	
	@Field("CreatedDate")
	private Date createdDate;
	
	@Field("CustomerID")
	private String customerId;
	
	@Field("CustomerName")
	private String customerName;
	
	@Field("CustomerType")
	private String customerType;
	
	@Field("DataClass")
	private String dataClass;
	
	@Field("DateCreated")
	private Date dateCreated;
	
	@Field("DocEncrypt")
	private String docEncrypt;
	
	@Field("DocExpiryDate")
	private Date docExpiryDate;
	
	@Field("DocName")
	private String docName;
	
	@Field("DocNumber")
	private String docNumber;
	
	@Field("DocPassword")
	private String docPassword;
	
	@Field("DocRemark")
	private String docRemark;
	
	@Field("DocStatus")
	private String docStatus;
	
	@Field("DocTitle")
	private String docTitle;
	
	@Field("DocType")
	private String docType;
	
	@Field("DocTypeID")
	private int docTypeId;
	
	@Field("DocTypeName")
	private String docTypeName;
	
	@Field("DocUploadID")
	private String docUploadId;
	
	@Field("DocVersion")
	private String docVersion;
	
	@Field("EncryptPasswd")
	private String encryptPassword;
	
	@Field("ExpiryDate")
	private Date expiryDate;
	
	@Field("FileSize")
	private String fileSize;
	
	@Field("FileType")
	private String fileType;
	
	@Field("MobileNo")
	private long mobileNo;
	
	@Field("ModifiedDate")
	private Date modifiedDate;
	
	@Field("MultipageDoc")
	private String multipageDoc;
	
	@Field("NoofPages")
	private String noOfPages;
	
	@Field("Owner")
	private String owner;
	
	@Field("OwnerType")
	private String ownerType;
	
	@Field("ReimbAccNo")
	private String reimbAccNo;
	
	@Field("Remarks")
	private String remarks;
	
	@Field("Source")
	private String source;
	
	@Field("UCIC")
	private String ucic;
	
	@Field("UploadDate")
	private Date uploadDate;
	
	@Field("ZipFileSIze")
	private String zipFileSIze;
	

}
