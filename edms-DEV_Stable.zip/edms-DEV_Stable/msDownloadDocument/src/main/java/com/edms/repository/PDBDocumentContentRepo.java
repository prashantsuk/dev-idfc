package com.edms.repository;

import org.springframework.data.aerospike.repository.AerospikeRepository;
import org.springframework.stereotype.Repository;

import com.edms.domain.PDBDocumentContentEntity;


@Repository
public interface PDBDocumentContentRepo extends AerospikeRepository<PDBDocumentContentEntity, Integer>{
	
	PDBDocumentContentEntity findByPrntFldrIndx(int parentFolderIndex);

}
