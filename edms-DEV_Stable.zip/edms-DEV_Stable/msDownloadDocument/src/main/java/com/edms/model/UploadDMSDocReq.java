package com.edms.model;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UploadDMSDocReq {

	@NotNull(message = "MsgHdrObject is missing")
	private MsgHdr msgHdr;
	
	@NotNull(message = "MsgBdyObject is missing")
	private MsgBdy msgBdy;

}
