package com.edms.resource;

import java.io.IOException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.edms.exception.UserException;
import com.edms.model.DocumentData;
import com.edms.model.DownloadDMSDocReq;
import com.edms.service.liabilities.DownloadDocService;

@RestController
@RequestMapping("/downloadDoc")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class LiabilitiesDownloadDocumentController {
	
	@Autowired
	DownloadDocService downloadDocService;
	
	@PostMapping("/liabilities")
	public DownloadDMSDocReq liabilitiesDownloadDoc(@Valid @RequestBody DownloadDMSDocReq dmsDocReq) throws UserException, IOException
	{
		return downloadDocService.downloadDoc(dmsDocReq);
	}
	
	@GetMapping("/liabilities/getDocumentData")
	public DocumentData getDocumentData(@RequestParam String docIndx) throws UserException, IOException
	{
		return downloadDocService.getDocumentData(docIndx);
	}
	
}
