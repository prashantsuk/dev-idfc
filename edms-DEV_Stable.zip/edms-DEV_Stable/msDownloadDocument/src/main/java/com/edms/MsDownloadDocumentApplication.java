package com.edms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class MsDownloadDocumentApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsDownloadDocumentApplication.class, args);
	}

}
