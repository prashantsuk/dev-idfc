package com.edms.service.liabilities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.edms.domain.DocLiabilitiesEntity;
import com.edms.domain.PDBDocumentContentEntity;
import com.edms.domain.PDBDocumentEntity;
import com.edms.domain.PDBFolderEntity;
import com.edms.exception.UserException;
import com.edms.model.DocumentData;
import com.edms.model.DownloadDMSDocReq;
import com.edms.repository.DocLiabilitiesRepo;
import com.edms.repository.PDBDocumentContentRepo;
import com.edms.repository.PDBDocumentRepo;
import com.edms.repository.PDBFolderRepo;
import lombok.extern.slf4j.Slf4j;

import static com.edms.util.Constants.*;

import java.io.File;
import java.io.IOException;
import java.util.Optional;

@Service
@Slf4j
public class DownloadDocService {
	
	@Value("${fileLocation}")
	private String fileLocation;
	
	@Autowired
	CommonService commonService;
	
	@Autowired
	PDBFolderRepo pdbFolderRepo;
	
	@Autowired
	PDBDocumentRepo pdbDocumentRepo;
	
	@Autowired
	PDBDocumentContentRepo pdbDocumentContentRepo;
	
	@Autowired
	DocLiabilitiesRepo docLiabilitiesRepo;

	
	@Transactional
	public DownloadDMSDocReq downloadDoc(DownloadDMSDocReq downloadDMSDocResp) throws UserException, IOException {

			log.info("Download doc method started");
			PDBDocumentEntity entity=null;
			DocLiabilitiesEntity docLiabilities=null;
			
			if(downloadDMSDocResp.getMsgBdy().getDocIndx()!=null&&downloadDMSDocResp.getMsgBdy().getDocIndx().length()>0)
			{
				Optional<PDBDocumentEntity> pdbDocumentEntity=pdbDocumentRepo.findById(Integer.parseInt(downloadDMSDocResp.getMsgBdy().getDocIndx()));
					
				if(!pdbDocumentEntity.isPresent())
					throw new UserException("Documnet details not found","downloadDoc");
					
				entity=pdbDocumentEntity.get();
			}
			else
			{
				Optional<PDBFolderEntity> parentFldrOpt=pdbFolderRepo.findById(Integer.parseInt(downloadDMSDocResp.getMsgBdy().getPrntFldrIndx()));
				
				if(!parentFldrOpt.isPresent())
					throw new UserException("Parent folder not found","downloadDoc");	
				
				Optional<PDBFolderEntity> srcFldrOpt=pdbFolderRepo.findById(Integer.parseInt(downloadDMSDocResp.getMsgBdy().getSrcFldrIndx()));
				
				if(!srcFldrOpt.isPresent())
					throw new UserException("Source folder not found","downloadDoc");	
				
				if(srcFldrOpt.get().getParentFldrInd()!=parentFldrOpt.get().getFolderIndex())
					throw new UserException("Parent folder index and source folder index doesnt not match","downloadDoc");
				
				String folderName=srcFldrOpt.get().getName()+"_"+downloadDMSDocResp.getMsgBdy().getCustId()+"_"+downloadDMSDocResp.getMsgBdy().getDocType();
				
				PDBFolderEntity pdbFolderEntity=pdbFolderRepo.findByName(folderName);
				if(pdbFolderEntity==null)
					throw new UserException("Folder not found","downloadDoc");
				
				PDBDocumentContentEntity pdbDocumentContentEntity=pdbDocumentContentRepo.findByPrntFldrIndx(pdbFolderEntity.getFolderIndex());
				
				if(pdbDocumentContentEntity==null)
					throw new UserException("Document not found","downloadDoc");
				
				Optional<PDBDocumentEntity> entityOpt=pdbDocumentRepo.findById(pdbDocumentContentEntity.getDocumentIndex());	
				if(!entityOpt.isPresent())
					throw new UserException("Document not found","downloadDoc");
				
				entity=entityOpt.get();
				
				docLiabilities=docLiabilitiesRepo.findByDocUploadId(String.valueOf(entity.getDocIndex()));
				if(docLiabilities==null)
					throw new UserException("Document details not found", "getDocumentData");
			}
				
			if(entity==null)
				throw new UserException("Document not found","downloadDoc");
			
			File file=new File(entity.getPath());
			
			if(!file.exists())
				throw new UserException("File not found","downloadDoc");
				
			String bse64String=commonService.encodeFileToBase64(file);
				
			return DownloadDMSDocReq.builder().msgBdy(commonService.setMessageBody( SUCCESS, "0", entity, null, null, bse64String,docLiabilities)).
						msgHdr(commonService.setMessageHeader(OK)).build();
	
	}
	

	@Transactional
	public DocumentData getDocumentData(String docIndx) throws UserException, IOException
	{
		Optional<DocLiabilitiesEntity> docLiabilities=docLiabilitiesRepo.findById(docIndx);
		if(!docLiabilities.isPresent())
			throw new UserException("Document details not found", "getDocumentData");
		
		Optional<PDBDocumentEntity> pdbDocumentEntity=pdbDocumentRepo.findById(Integer.parseInt(docLiabilities.get().getDocUploadId()));
		
		if(!pdbDocumentEntity.isPresent())
			throw new UserException("Document details not found", "getDocumentData");
		
		File file=new File(pdbDocumentEntity.get().getPath());
		
		if(!file.exists())
			throw new UserException("File not found","getDocumentData");
			
		String base64String=commonService.encodeFileToBase64(file);
		
		return commonService.buildDocTable(docLiabilities.get(),base64String);
	}
	
}