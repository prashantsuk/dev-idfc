package com.edms.repository;

import org.springframework.data.aerospike.repository.AerospikeRepository;
import org.springframework.stereotype.Repository;

import com.edms.domain.DocLiabilitiesEntity;

@Repository
public interface DocLiabilitiesRepo extends AerospikeRepository<DocLiabilitiesEntity, String> {
	
	DocLiabilitiesEntity findByDocUploadId(String docUploadId);

}
