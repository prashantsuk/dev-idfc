package com.edms.domain;

import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "PDBDocument")
public class PDBDocumentEntity {

	@Id
	private int docIndex;
	
	private int versNumber;
	
	private String versComment;
	private String name;
	private String path;
	private String owner;
	private String createDate;
	private String reviseDate;
	private String accesseDate;
	private String dataDefIndex;
	private String versioning;
	private String accessType;
	private String docType;
	private String createdByApp;
	private String createdByUser;
	private int imageIndex;
	private int volumeId;
	private int noOfPages;
	private String documentSize;
	private int ftsDocIndex;
	private String odmaDocIndex;
	private String historyFlag;
	private String documentLock;
	private String lockByUser;
	private String commit;
	private String author;
	private int textImgIndex;
	private int textVolumeId;
	private String ftsFlag;
	private String docStatus;
	private String expiryDate;
	private String finalizedFlag;
	private String finalizedDate;
	private String finalizedBy;
	private String checkOutStatus;
	private String checkOutUser;
	private String usefulData;
	private String acl;
	private String physicalAlloc;
	private String aclMoreFlag;
	private String appName;
	private int mainGroupId;
	private String pullPrintFlag;
	private String thumbnailFlag;
	private String lockMessage;
	private String enableSecure;
	private String revisedBy;
	private String signFlag;
	private String ownerType;
	private String esTimeStamp;
	private String esIndexTime;
	private String esFlag;
	private String fileName;
	
}
