package com.edms.repository;

import org.springframework.data.aerospike.repository.AerospikeRepository;
import org.springframework.stereotype.Repository;

import com.edms.domain.PDBDocumentEntity;

@Repository
public interface PDBDocumentRepo extends AerospikeRepository<PDBDocumentEntity, Integer> {
	
	PDBDocumentEntity findByDocIndexAndName(int docIndex,String name);

}
