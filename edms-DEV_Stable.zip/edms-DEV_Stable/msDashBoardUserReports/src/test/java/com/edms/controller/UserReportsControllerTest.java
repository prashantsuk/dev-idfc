package com.edms.controller;

import com.edms.model.UserReportsResponse;
import com.edms.service.UserReportsService;

import io.micronaut.security.authentication.Authentication;
import io.micronaut.security.authentication.ClientAuthentication;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;

import static org.mockito.Mockito.*;

@MicronautTest
public class UserReportsControllerTest {

    @Inject
    UserReportsService userReportsService;

    @Inject
    UserReportsController userReportsController;

    UserReportsResponse userReportsResponse = null;

    @BeforeEach
    public void setUp() {
        userReportsResponse = new UserReportsResponse();
        userReportsResponse.setUploadedBySourceCount(20l);
    }

    @MockBean(UserReportsService.class)
    public UserReportsService userReportsService() {
        return mock(UserReportsService.class);
    }


    @Test
    public void getUserReportsTest() throws MalformedURLException {

        Map<String, Object> map = new HashMap<>();
        map.put("name", "name");
        Authentication authentication = new ClientAuthentication("name", map);

        when(userReportsService.getReports(anyString())).thenReturn(userReportsResponse);

        assertEquals(userReportsResponse.getUploadedBySourceCount(), userReportsController.getUserReports(authentication).body().getUploadedBySourceCount());

    }

}
