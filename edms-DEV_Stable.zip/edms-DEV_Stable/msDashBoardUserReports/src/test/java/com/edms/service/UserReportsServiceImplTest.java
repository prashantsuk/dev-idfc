package com.edms.service;

import com.edms.client.AuditLogClient;
import com.edms.model.AuditLogEntity;
import com.edms.model.McAfeeEntity;
import com.edms.model.UserReportsResponse;
import com.edms.repository.AuditLogRepository;
import com.edms.repository.VirusScanRepository;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@MicronautTest
public class UserReportsServiceImplTest {

    UserReportsResponse userReportsResponse = null;
    AuditLogEntity auditLogEntity = null;
    List<AuditLogEntity> auditLogEntityList = new ArrayList<>();

    McAfeeEntity mcAfeeEntity = null;

    List<McAfeeEntity> mcAfeeEntityList = new ArrayList<>();

    @Inject
    AuditLogRepository auditLogRepository;

    @Inject
    VirusScanRepository virusScanRepository;

    @Inject
    UserReportsServiceImpl userReportsServiceImpl;

    @Inject
    AuditLogClient auditLogClient;

    @MockBean(AuditLogRepository.class)
    public AuditLogRepository auditLogRepository() {
        return mock(AuditLogRepository.class);
    }

    @MockBean(VirusScanRepository.class)
    public VirusScanRepository virusScanRepository() {
        return mock(VirusScanRepository.class);
    }

    @MockBean(AuditLogClient.class)
    public AuditLogClient auditLogClient(){
        return mock(AuditLogClient.class);
    }


    @BeforeEach
    public void setUp() {
        userReportsResponse = new UserReportsResponse();
        userReportsResponse.setUploadedBySourceCount(1l);
        userReportsResponse.setUploadedByProductCount(1l);
        userReportsResponse.setUploadedByCustomerCount(1l);
        userReportsResponse.setQuarantinedByCustomerCount(1l);
        userReportsResponse.setQuarantinedBySourceCount(1l);
        userReportsResponse.setQuarantinedByProductCount(1l);
        userReportsResponse.setMandDocsNotPendingBySourceCount(1l);
        userReportsResponse.setMandDocsNotPendingByProductCount(2l);
        userReportsResponse.setMandDocsNotPendingByCustomerCount(23l);
        userReportsResponse.setDownloadedByCustomerCount(3l);
        userReportsResponse.setDownloadedByProductCount(3l);
        userReportsResponse.setDownloadedBySourceCount(3l);
        userReportsResponse.setViewedByCustomerCount(2l);
        userReportsResponse.setViewedBySourceCount(2l);
        userReportsResponse.setViewedByProductCount(2l);
        auditLogEntity = new AuditLogEntity();
        auditLogEntity.setAction("UPLOAD");
        auditLogEntity.setCustomerId("12");
        auditLogEntity.setSourceName("EDP");
        auditLogEntity.setProductName("loan");
        auditLogEntity.setAgreementId("AMT123");
        auditLogEntity.setStatus("SUCCESS");
        auditLogEntity.setUcic("");
        auditLogEntityList.add(auditLogEntity);
        mcAfeeEntity = new McAfeeEntity();
        mcAfeeEntity.setInfected("true");
        mcAfeeEntity.setQuarantineStatus("true");
        mcAfeeEntity.setCustId("12");
        mcAfeeEntity.setSource("Edp");
        mcAfeeEntity.setProductName("loan");
        mcAfeeEntityList.add(mcAfeeEntity);
    }

    @Test
    public  void getUserReportsTestWithBoth(){
        when(auditLogRepository.findByUserName(anyString())).thenReturn(auditLogEntityList);
        when(virusScanRepository.findByUserName(anyString())).thenReturn(mcAfeeEntityList);
        doNothing().when(auditLogClient).addAuditLog(any());
        assertEquals(userReportsResponse.getUploadedBySourceCount(), userReportsServiceImpl.getReports("123").getUploadedBySourceCount());
    }

    @Test
    public  void getUserReportsTestWithWithoutQuarantine(){
        when(auditLogRepository.findByUserName(anyString())).thenReturn(auditLogEntityList);
        when(virusScanRepository.findByUserName(anyString())).thenReturn(new ArrayList<>());
        doNothing().when(auditLogClient).addAuditLog(any());
        assertEquals(userReportsResponse.getUploadedBySourceCount(), userReportsServiceImpl.getReports("123").getUploadedBySourceCount());
    }

    @Test
    public  void getUserReportsTestWithWithoutAuditLog(){
        when(auditLogRepository.findByUserName(anyString())).thenReturn(new ArrayList<>());
        when(virusScanRepository.findByUserName(anyString())).thenReturn(mcAfeeEntityList);
        doNothing().when(auditLogClient).addAuditLog(any());
        assertEquals(userReportsResponse.getQuarantinedByCustomerCount(), userReportsServiceImpl.getReports("123").getQuarantinedByCustomerCount());
    }

    @Test
    public  void getUserReportsTestWithWithoutBoth(){
        when(auditLogRepository.findByUserName(anyString())).thenReturn(new ArrayList<>());
        when(virusScanRepository.findByUserName(anyString())).thenReturn(new ArrayList<>());
        doNothing().when(auditLogClient).addAuditLog(any());
        assertEquals(0l, userReportsServiceImpl.getReports("123").getQuarantinedByCustomerCount());
    }

    @Test
    public  void getUserReportsTestWithBothException(){
        boolean flag = true;
        when(auditLogRepository.findByUserName(anyString())).thenThrow(NullPointerException.class);
        when(virusScanRepository.findByUserName(anyString())).thenReturn(mcAfeeEntityList);
        doNothing().when(auditLogClient).addAuditLog(any());
        try{
         userReportsServiceImpl.getReports("123");
        }catch (Exception exception){
            flag = false;
        }
        assertFalse(flag);
    }

    @Test
    public  void getUserReportsTestWithAgreementId(){
        auditLogEntityList.get(0).setAgreementId("456");
        auditLogEntityList.get(0).setCustomerId(null);
        when(auditLogRepository.findByUserName(anyString())).thenReturn(auditLogEntityList);
        when(virusScanRepository.findByUserName(anyString())).thenReturn(mcAfeeEntityList);
        doNothing().when(auditLogClient).addAuditLog(any());
        assertEquals(userReportsResponse.getUploadedBySourceCount(), userReportsServiceImpl.getReports("123").getUploadedBySourceCount());
    }

    @Test
    public  void getUserReportsTestWithUcicId(){
        auditLogEntityList.get(0).setAgreementId(null);
        auditLogEntityList.get(0).setCustomerId(null);
        auditLogEntityList.get(0).setUcic("3456");
        when(auditLogRepository.findByUserName(anyString())).thenReturn(auditLogEntityList);
        when(virusScanRepository.findByUserName(anyString())).thenReturn(mcAfeeEntityList);
        doNothing().when(auditLogClient).addAuditLog(any());
        assertEquals(userReportsResponse.getUploadedBySourceCount(), userReportsServiceImpl.getReports("123").getUploadedBySourceCount());
    }

}
