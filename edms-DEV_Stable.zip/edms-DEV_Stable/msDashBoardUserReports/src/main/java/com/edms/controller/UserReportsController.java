package com.edms.controller;

import com.edms.model.UserReportsResponse;
import com.edms.service.UserReportsService;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.authentication.Authentication;
import io.micronaut.security.rules.SecurityRule;
import jakarta.inject.Inject;


@Controller("/userReports")
@Secured(SecurityRule.IS_AUTHENTICATED)
public class UserReportsController {

	@Inject
	private UserReportsService userReportsService;

	@Get
	public HttpResponse<UserReportsResponse> getUserReports(Authentication auth) {
		UserReportsResponse response = userReportsService.getReports(auth.getName());
			return HttpResponse.ok(response);
	}
}
