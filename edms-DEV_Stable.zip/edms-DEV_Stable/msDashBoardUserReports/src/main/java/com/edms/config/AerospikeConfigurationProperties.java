package com.edms.config;


import com.edms.util.Constants;

import io.micronaut.context.annotation.ConfigurationProperties;
import lombok.Data;

@Data
@ConfigurationProperties(value = Constants.CONFIG_RESOURCE)
public class AerospikeConfigurationProperties {
    private String host;
    private int port;
    private String namespace;
	private String userName;
	private String password;
}