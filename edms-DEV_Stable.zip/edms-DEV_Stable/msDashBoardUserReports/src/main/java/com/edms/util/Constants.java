package com.edms.util;

public class Constants {

	public static final String CONFIG_RESOURCE = "aerospike";
	public static final String ENV_LOCAL = "local";
	public static final String ENV_DEV = "dev";
	
	public static final String ACTION_VIEW ="VIEW";
	public static final String ACTION_DWNLD ="DOWNLOAD";
	public static final String ACTION_UPLD ="UPLOAD";
	public static final String AV_SCAN = "AV SCAN";

	
	public static final String TRUE ="true";
	
	public static final String DOC_PENDING="PENDING";
	public static final String DOC_NOT_PENDING="NOT_PENDING";
	
	public static final String STATUS  = "SUCCESS";
	public static final String FAILED = "FAILED";
	public static final String UPLOADED = "UPLOADED";
	public static final String SUCCESS = "SUCCESS";
	public static final String VIEW_DASH ="VIEW DASHBOARD";
	public static final String DASHBOARD ="DASHBOARD";
	
	
	
	

}
