package com.edms.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Utilities {

	
	public static String getCurrentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MMM/yyyy hh:mm a");
		LocalDateTime now = LocalDateTime.now();
		return (dtf.format(now));
	}
}
