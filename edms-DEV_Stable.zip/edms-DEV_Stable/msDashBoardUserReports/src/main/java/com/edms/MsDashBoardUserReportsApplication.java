package com.edms;

import io.micronaut.runtime.Micronaut;

public class MsDashBoardUserReportsApplication {

    public static void main(String[] args) {
        Micronaut.run(MsDashBoardUserReportsApplication.class, args);
    }

}