package com.edms.service;

import com.edms.model.UserReportsResponse;

import jakarta.inject.Singleton;

@Singleton
public interface UserReportsService {

	public UserReportsResponse getReports(String username);
}
