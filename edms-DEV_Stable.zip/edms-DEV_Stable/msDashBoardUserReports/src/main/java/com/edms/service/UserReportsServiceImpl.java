package com.edms.service;

import java.util.*;

import static com.edms.util.Constants.*;

import com.edms.client.AuditLogClient;
import com.edms.model.AuditLog;
import com.edms.model.AuditLogEntity;
import com.edms.model.UserReportsResponse;
import com.edms.repository.AuditLogRepository;
import com.edms.repository.VirusScanRepository;
import com.edms.util.Utilities;

import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import io.micronaut.scheduling.annotation.Async;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class UserReportsServiceImpl implements UserReportsService {

    @Inject
    private AuditLogRepository auditLogRepository;

    @Inject
    private VirusScanRepository virusScanRepository;
    
    @Inject
    private AuditLogClient auditLogClient;

    @Override
    public UserReportsResponse getReports(String userName) {

    	
        UserReportsResponse response = new UserReportsResponse();
       
        try {
            List<AuditLogEntity> userTotalLog = auditLogRepository.findByUserName(userName);
        if (CollectionUtils.isNotEmpty(userTotalLog)) {
            response.setUploadedByCustomerCount(getCustomerWiseActionCount(ACTION_UPLD, userTotalLog));
            response.setDownloadedByCustomerCount(getCustomerWiseActionCount(ACTION_DWNLD, userTotalLog));
            response.setViewedByCustomerCount(getCustomerWiseActionCount(ACTION_VIEW, userTotalLog));

            response.setUploadedBySourceCount(getSourceWiseActionCount(ACTION_UPLD, userTotalLog));
            response.setDownloadedBySourceCount(getSourceWiseActionCount(ACTION_DWNLD, userTotalLog));
            response.setViewedBySourceCount(getSourceWiseActionCount(ACTION_VIEW, userTotalLog));

            response.setUploadedByProductCount(getProductWiseActionCount(ACTION_UPLD, userTotalLog));
            response.setDownloadedByProductCount(getProductWiseActionCount(ACTION_DWNLD, userTotalLog));
            response.setViewedByProductCount(getProductWiseActionCount(ACTION_VIEW, userTotalLog));
      
            response.setQuarantinedByCustomerCount(getCustomerWiseScanCount(userTotalLog));
            response.setQuarantinedByProductCount(getProductWiseScanCount(userTotalLog));
            response.setQuarantinedBySourceCount(getSourceWiseScanCount(userTotalLog));
            
            response = setDefaultResponse(true,response);
        }

        else {
            response = setDefaultResponse(false,response);
        }
        
        AuditLog auditLog = AuditLog.builder().action(VIEW_DASH).createdBy(userName)
				.createdDate(Utilities.getCurrentDate()).currentValue("").customerId("").screenName(DASHBOARD)
				.lastUpdateDate("").modifiedBy("").oldValue("").roleName("").productName("")
				.sourceName("").status(SUCCESS).message(userName+ " accessed dashboard page  ").ucic("")
				.accountNumber("").agreementId("").category("").docTypeId("").documentName("").documentTitle("")
				.userName(userName).updatedDate("").updatedDate("").tableName("edp_user_reports").sessionId("").searchBy("")
				.build();

		auditLog(auditLog);
    	}
    	catch(Exception e) {
    		  AuditLog auditLog = AuditLog.builder().action(VIEW_DASH).createdBy(userName)
  					.createdDate(Utilities.getCurrentDate()).currentValue("").customerId("").screenName(DASHBOARD)
  					.lastUpdateDate("").modifiedBy("").oldValue("").roleName("").productName("")
  					.sourceName("").status(FAILED).message(userName
  							+ " failed to view dashboard page")	.accountNumber("").agreementId("").category("").docTypeId("").documentName("").documentTitle("")
  					.userName(userName).updatedDate("").updatedDate("").tableName("edp_user_reports").sessionId("").searchBy("")
  					.build();

  			auditLog(auditLog);
    		throw e;
    		
    		
    	}
        return response;
    }

    private long getCustomerWiseActionCount(String status, List<AuditLogEntity> auditLogData) {
        Set<String> customerSet = new HashSet<>();
        auditLogData.stream().filter(e -> e.getAction() != null && e.getAction().equals(status) && e.getStatus().equalsIgnoreCase(STATUS))
                .forEach(e-> getUniqueCustomerCount(e, customerSet));
        return customerSet.size();
    }

    private long getSourceWiseActionCount(String status, List<AuditLogEntity> auditLogData) {
        Set<String> customerSet = new HashSet<>();
        return auditLogData.stream().filter(e -> e.getAction() != null && e.getAction().equals(status) && e.getStatus().equalsIgnoreCase(STATUS) &&  e.getSourceName() != null && customerSet.add(e.getSourceName()))
                .count();
    }

    private long getProductWiseActionCount(String status, List<AuditLogEntity> auditLogData) {
        Set<String> customerSet = new HashSet<>();
        return auditLogData.stream().filter(e -> e.getAction() != null && e.getAction().equals(status) && e.getStatus().equalsIgnoreCase(STATUS) && e.getProductName() != null && customerSet.add(e.getProductName()))
                .count();
    }

    private long getCustomerWiseScanCount(List<AuditLogEntity> scanList) {
        Set<String> customerSet = new HashSet<>();
        return scanList.stream().filter(e -> e.getFailedStage()==null && e.getScreenName()!=null && e.getScreenName().equals(AV_SCAN) && e.getStatus().equals(FAILED) && e.getCustomerId() != null && customerSet.add(e.getCustomerId()))
                .count();
    }

    private long getProductWiseScanCount(List<AuditLogEntity> scanList) {
        Set<String> customerSet = new HashSet<>();
        return scanList.stream().filter(e -> e.getFailedStage()==null &&  e.getScreenName()!=null && e.getScreenName().equals(AV_SCAN) && e.getStatus().equals(FAILED) && e.getProductName() != null && customerSet.add(e.getProductName()))
                .count();
    }

    private long getSourceWiseScanCount(List<AuditLogEntity> scanList) {
        Set<String> customerSet = new HashSet<>();
        return scanList.stream().filter(e -> e.getFailedStage()==null &&  e.getScreenName()!=null && e.getScreenName().equals(AV_SCAN) && e.getStatus().equals(FAILED) && e.getSourceName() != null && customerSet.add(e.getSourceName()))
                .count();
    }

    private UserReportsResponse setDefaultResponse(boolean isDataAvailable,UserReportsResponse response) {

    	if (!isDataAvailable) {
            response.setUploadedByCustomerCount(0L);
            response.setUploadedByProductCount(0L);
            response.setUploadedBySourceCount(0L);

            response.setDownloadedByCustomerCount(0L);
            response.setDownloadedByProductCount(0L);
            response.setDownloadedBySourceCount(0L);

            response.setViewedByCustomerCount(0L);
            response.setViewedByProductCount(0L);
            response.setViewedBySourceCount(0L);

            response.setQuarantinedByCustomerCount(0L);
            response.setQuarantinedByProductCount(0L);
            response.setQuarantinedBySourceCount(0L);

            response.setMandDocsPendingByCustomerCount(0L);
            response.setMandDocsPendingByProductCount(0L);
            response.setMandDocsPendingBySourceCount(0L);
            response.setMandDocsNotPendingBySourceCount(0L);
            response.setMandDocsNotPendingByCustomerCount(0L);
            response.setMandDocsNotPendingByProductCount(0L);
    	}
    	else {

            response.setMandDocsPendingByCustomerCount(0L);
            response.setMandDocsPendingByProductCount(0L);
            response.setMandDocsPendingBySourceCount(0L);
            response.setMandDocsNotPendingBySourceCount(0L);
            response.setMandDocsNotPendingByCustomerCount(0L);
            response.setMandDocsNotPendingByProductCount(0L);
    	}
            
        return response;
    }

    private Set<String> getUniqueCustomerCount(AuditLogEntity auditLogEntity, Set<String> customerSet) {
        if (StringUtils.isNotEmpty(auditLogEntity.getCustomerId())) {
            customerSet.add(auditLogEntity.getCustomerId());
        } else if (StringUtils.isEmpty(auditLogEntity.getCustomerId()) && StringUtils.isNotEmpty(auditLogEntity.getAgreementId())) {
            customerSet.add(auditLogEntity.getAgreementId());
        } else if (StringUtils.isEmpty(auditLogEntity.getCustomerId()) && StringUtils.isEmpty(auditLogEntity.getAgreementId()) && StringUtils.isNotEmpty(auditLogEntity.getUcic())) {
            customerSet.add(auditLogEntity.getUcic());
        }
        return customerSet;
    }
    
	@Async
	public void auditLog(AuditLog auditLog) {
		auditLogClient.addAuditLog(auditLog);
	}

}
