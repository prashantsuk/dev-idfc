package com.edms.model;

import com.aerospike.mapper.annotations.AerospikeBin;
import com.aerospike.mapper.annotations.AerospikeRecord;

import lombok.*;



@NoArgsConstructor
@Data
@AerospikeRecord(namespace = "test",set = "edp_auditlog")
public class AuditLogEntity{

	@AerospikeBin(name = "ACTION")
	private String action;

	@AerospikeBin(name = "CUSTOMERID")
	private String customerId;

	@AerospikeBin(name = "SOURCENAME")
	private String sourceName;

	@AerospikeBin(name = "PRODUCTNAME")
	private String productName;

	@AerospikeBin(name = "AGREEMENTID")
	private String agreementId;

	@AerospikeBin(name = "UCIC")
	private String ucic;

	@AerospikeBin(name = "STATUS")
	private String status;
	
	@AerospikeBin(name = "SCREENNAME")
	private String screenName;
	
	@AerospikeBin(name = "FAILEDSTAGE")
	private String failedStage;

}