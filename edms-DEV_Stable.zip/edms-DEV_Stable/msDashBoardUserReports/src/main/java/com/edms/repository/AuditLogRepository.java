package com.edms.repository;

import java.util.List;

import com.aerospike.client.query.Filter;
import com.aerospike.mapper.tools.AeroMapper;
import com.edms.model.AuditLogEntity;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class AuditLogRepository{
	
	@Inject
	AeroMapper aeroMapper;

	public List<AuditLogEntity> findByUserName(String value){
		return aeroMapper.query(AuditLogEntity.class, Filter.equal("USERNAME", value));
	}
	
}
