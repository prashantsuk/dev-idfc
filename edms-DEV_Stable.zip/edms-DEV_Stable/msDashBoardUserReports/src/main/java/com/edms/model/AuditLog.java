package com.edms.model;

import java.time.LocalDateTime;

import javax.validation.constraints.NotNull;

import lombok.AllArgsConstructor;
import lombok.Builder;


@Builder
@AllArgsConstructor
public class AuditLog {

	@NotNull(message = "action field cannot be empty")
	private String action;
	
	private String createdBy;
	
	private String createdDate;
	
	private String currentValue;
	
	private String customerId;
	
	@NotNull(message = "source name field cannot be empty")
	private String sourceName;
		
	private String lastUpdateDate;
	
	private String modifiedBy;
	
	private String oldValue;
	
	@NotNull(message = "status field cannot be empty")
	private String status;
	
	@NotNull(message = "role name field cannot be empty")
	private String roleName;
	
	private String category;
	
	@NotNull(message = "message field cannot be empty")
	private String message;
	
	private String productName;
	
	private String ucic;
	
	private String agreementId;
	
	private String loanNo;
	
	private String accountNumber;
	
	private String screenName;
	
	private String updatedBy;
	
	private String updatedDate;
	
	private String userName;
	
	private LocalDateTime timeStamp;
	
	private String quarantineStatus;
	
	private String documentType;
	
	private String documentName;
	
	private String reason;
	
	private String tableName;
	
	private String documentTitle;
	
	private String documentVersion;
	
	private String docTypeId;
	
	private String failedStage;
	
	private String sessionId;
	
	private String searchBy;
	
	private String searchDate;
}