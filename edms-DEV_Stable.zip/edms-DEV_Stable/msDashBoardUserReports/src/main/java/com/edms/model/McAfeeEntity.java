package com.edms.model;

import com.aerospike.mapper.annotations.AerospikeBin;
import com.aerospike.mapper.annotations.AerospikeRecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;


@Data
@NoArgsConstructor
@AerospikeRecord(namespace = "test", set = "edp_virus_scan")
public class McAfeeEntity{
	@AerospikeBin(name ="QTNSTATUS")
	private String quarantineStatus;
	@AerospikeBin(name ="INFECTED")
	private String infected;
	@AerospikeBin(name ="CUSTOMERID")
	private String custId;
	@AerospikeBin(name ="SOURCE")
	private String source;
	@AerospikeBin(name ="PRODUCTNAME")
	private String productName;
}
