package com.edms.model;



import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class UserReportsResponse {
	private Long uploadedByCustomerCount;
	private Long downloadedByCustomerCount;
	private Long viewedByCustomerCount;
	private Long uploadedByProductCount;
	private Long downloadedByProductCount;
	private Long viewedByProductCount;
	private Long uploadedBySourceCount;	
	private Long downloadedBySourceCount;
	private Long viewedBySourceCount;
	private Long quarantinedBySourceCount;	
	private Long quarantinedByProductCount;
	private Long quarantinedByCustomerCount;
	private Long mandDocsPendingBySourceCount;	
	private Long mandDocsPendingByProductCount;
	private Long mandDocsPendingByCustomerCount;
	private Long mandDocsNotPendingBySourceCount;	
	private Long mandDocsNotPendingByProductCount;
	private Long mandDocsNotPendingByCustomerCount;
	
}
