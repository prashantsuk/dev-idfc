package com.edms.repository;

import java.util.List;

import com.aerospike.client.AerospikeClient;

import com.aerospike.client.policy.Policy;

import com.aerospike.client.query.Filter;
import com.aerospike.mapper.tools.AeroMapper;
import com.edms.model.AuditLogEntity;
import com.edms.model.McAfeeEntity;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class VirusScanRepository {

	@Inject
	AeroMapper aeroMapper;

	public List<McAfeeEntity> findByUserName(String value){
		return aeroMapper.query(McAfeeEntity.class, Filter.equal("CREATEDBY", value));
	}


}

