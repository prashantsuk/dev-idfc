package com.edms.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import org.junit.jupiter.api.Test;

import com.edms.model.AuditLog;
import com.edms.service.AuditLogServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.micronaut.core.type.Argument;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.HttpClient;
import io.micronaut.runtime.server.EmbeddedServer;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import static com.edms.util.Constants.*;

@MicronautTest
class AuditLogControllerTest {

	@Inject
	AuditLogServiceImpl auditLogServiceImpl;
	
	@Inject
    EmbeddedServer server;
	
	@MockBean(AuditLogServiceImpl.class)
	public AuditLogServiceImpl auditLogServiceImpl() {
	    return mock(AuditLogServiceImpl.class);
	}
	
	
	@Test
	void addAuditLogTest() throws InterruptedException, ExecutionException, JsonProcessingException, MalformedURLException
	{
		HttpClient client = HttpClient.create(new URL("http://" + server.getHost()+":"+ server.getPort()));
	    	
		when(auditLogServiceImpl.addAuditLog(any())).thenReturn(SUCCESS);
		
		HttpResponse<String> response = client.toBlocking()
                .exchange(HttpRequest.POST("/auditLog", new AuditLog()), Argument.of(String.class));
    	
		assertEquals(HttpStatus.OK, response.status());
		assertEquals(SUCCESS, response.body());
	}
	
	
	@Test
	void getAuditLogTest() throws InterruptedException, ExecutionException, JsonProcessingException, MalformedURLException
	{
		
		HttpClient client = HttpClient.create(new URL("http://" + server.getHost()+":"+ server.getPort()));
		   
		when(auditLogServiceImpl.getAuditLogData(any(),any(),any(),any(),any(),any())).thenReturn(new ArrayList<AuditLog>());
		
		HttpResponse<List<AuditLog>> response=client.toBlocking()
                .exchange(HttpRequest.GET("/auditLog"), Argument.listOf(AuditLog.class));
    	
		assertEquals(HttpStatus.OK, response.status());
		
		assertEquals(new ArrayList<AuditLog>(), response.body());
	}
}
