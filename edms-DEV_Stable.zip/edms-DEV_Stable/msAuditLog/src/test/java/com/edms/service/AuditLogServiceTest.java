package com.edms.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import com.edms.model.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.edms.domain.EDPAuditLog;
import com.edms.repository.EDPAuditLogRepoImpl;
import com.fasterxml.jackson.core.JsonProcessingException;

import static com.edms.util.Constants.*;

import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;

@MicronautTest
class AuditLogServiceTest {

	@Inject
	private EDPAuditLogRepoImpl edpAuditLogRepoImpl;
	
	@Inject
	private AuditLogServiceImpl auditLogService;
	
	private AuditLog auditLog;
	
	private EDPAuditLog edpAuditLog1;
	private EDPAuditLog edpAuditLog2;
	private EDPAuditLog edpAuditLog3;
	private EDPAuditLog edpAuditLog4;
	private List<EDPAuditLog> edpAuditLogList;
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FORMAT);
	
	@MockBean(EDPAuditLogRepoImpl.class)
	EDPAuditLogRepoImpl edpAuditLogRepoImpl() {
        return mock(EDPAuditLogRepoImpl.class);
    }

	
	@BeforeEach
	void setUp() {
		
		auditLog=AuditLog.builder().action("UPLOAD").category("LIABILITIES").createdBy("ABC").customerId("123").
				message("ABC uploaded document sucessfully for Liabilities main table from : EDP")
				.productName("Kissan credit card").screenName("UPLOAD").sourceName("EDP").userName("ABC").build();
		
		edpAuditLog1=EDPAuditLog.builder().auditDate("24/Mar/2023 04:31 PM").action("UPLOAD").category("LIABILITIES").screenName("UPLOAD").pk(4L).build();
		edpAuditLog2=EDPAuditLog.builder().auditDate("23/Mar/2023 04:31 PM").action("VIEW").category("LIABILITIES").screenName("VIEW").pk(3L).build();
		edpAuditLog3=EDPAuditLog.builder().auditDate("22/Mar/2023 04:31 PM").action("UPLOAD").category("LIABILITIES").screenName("UPLOAD").pk(2L).build();
		edpAuditLog4=EDPAuditLog.builder().auditDate("21/Mar/2023 04:31 PM").action("DOWNLOAD").category("LIABILITIES").screenName("DOWNLOAD").pk(1L).build();
	
		edpAuditLogList=new ArrayList<>();
		edpAuditLogList.add(edpAuditLog1);
		edpAuditLogList.add(edpAuditLog2);
		edpAuditLogList.add(edpAuditLog3);
		edpAuditLogList.add(edpAuditLog4);
	}
	
	
	@Test
	void auditLogInsertSuccess() throws JsonProcessingException
	{
		when(edpAuditLogRepoImpl.findAll()).thenReturn(edpAuditLogList);
		doNothing().when(edpAuditLogRepoImpl).save(any());
		
		assertEquals(SUCCESS, auditLogService.addAuditLog(auditLog));
		
	}
	
	@Test
	void auditLogSearchLast24Hrs() throws JsonProcessingException
	{
		LocalDateTime date=LocalDateTime.now();
		
		edpAuditLog1.setAuditDate(date.format(dtf));
		edpAuditLog2.setAuditDate(date.minusDays(1).format(dtf));
		edpAuditLog3.setAuditDate(date.minusDays(2).format(dtf));
		edpAuditLog4.setAuditDate(date.minusDays(3).format(dtf));
		
		when(edpAuditLogRepoImpl.findAll()).thenReturn(edpAuditLogList);
		
		doNothing().when(edpAuditLogRepoImpl).save(any());

		List<AuditLog> auditLogList=new ArrayList<>();
		auditLogList.add(AuditLog.builder().timeStamp(LocalDateTime.parse(date.format(dtf), dtf)).action("UPLOAD").screenName("UPLOAD").build());
		assertEquals(auditLogList, auditLogService.getAuditLogData("", "", "abc", "", "","1:0:0:0"));
	}



	@Test
	void auditLogSearchDates() throws JsonProcessingException
	{
		when(edpAuditLogRepoImpl.findAll()).thenReturn(edpAuditLogList);

		doNothing().when(edpAuditLogRepoImpl).save(any());

		List<AuditLog> auditLogList=new ArrayList<>();
		auditLogList.add(AuditLog.builder().timeStamp(LocalDateTime.parse("24/Mar/2023 04:31 PM",dtf)).action("UPLOAD").screenName("UPLOAD").build());
		auditLogList.add(AuditLog.builder().timeStamp(LocalDateTime.parse("23/Mar/2023 04:31 PM",dtf)).action("VIEW").screenName("VIEW").build());
	
		assertEquals(auditLogList, auditLogService.getAuditLogData("23/Mar/2023", "24/Mar/2023", "abc", "", "","1:0:0:0"));
	}


	@Test
	void auditLogSearchKey() throws JsonProcessingException
	{
		when(edpAuditLogRepoImpl.findAll()).thenReturn(edpAuditLogList);

		List<EDPAuditLog> list=new ArrayList<>();
		list.add(edpAuditLog2);
		when(edpAuditLogRepoImpl.findByColumn(any(),any())).thenReturn(list);
		doNothing().when(edpAuditLogRepoImpl).save(any());

		List<AuditLog> auditLogList=new ArrayList<>();
		auditLogList.add(AuditLog.builder().timeStamp(LocalDateTime.parse("23/Mar/2023 04:31 PM",dtf)).action("VIEW").screenName("VIEW").build());
	
		assertEquals(auditLogList, auditLogService.getAuditLogData("", "", "abc", "screenName", "VIEW","1:0:0:0"));
	}
	
	
	@Test
	void auditLogSearchKeyAndDate() throws JsonProcessingException
	{
		List<EDPAuditLog> list=new ArrayList<>();
		list.add(edpAuditLog1);
		list.add(edpAuditLog3);

		when(edpAuditLogRepoImpl.findByColumn(any(),any())).thenReturn(list);
		doNothing().when(edpAuditLogRepoImpl).save(any());

		List<AuditLog> auditLogList=new ArrayList<>();
		auditLogList.add(AuditLog.builder().timeStamp(LocalDateTime.parse("24/Mar/2023 04:31 PM",dtf)).action("UPLOAD").screenName("UPLOAD").build());

		assertEquals(auditLogList, auditLogService.getAuditLogData("24/Mar/2023", "24/Mar/2023", "abc", "screenName", "UPLOAD","1:0:0:0"));
	}
	
	
	@Test
	void auditLogSearchKeyAndDateException() throws JsonProcessingException
	{
		List<EDPAuditLog> list=new ArrayList<>();
		list.add(edpAuditLog1);
		list.add(edpAuditLog3);

		when(edpAuditLogRepoImpl.findByColumn(any(),any())).thenThrow(new RuntimeException());//.thenReturn(list);
		doNothing().when(edpAuditLogRepoImpl).save(any());

		List<AuditLog> auditLogList=new ArrayList<>();
		auditLogList.add(AuditLog.builder().timeStamp(LocalDateTime.parse("24/Mar/2023 04:31 PM",dtf)).action("UPLOAD").screenName("UPLOAD").build());

		ErrorResp errorResp=ErrorResp.builder().msgHdr(MsgHdr.builder().rslt("").
				error(ErrorModel.builder().cd(EXP_500).rsn("").
						srvcObject(Srvc.builder().cntxt(DOC_MGMT).nm(DOC_MGMT).
							actnObject(Actn.builder().nm(AUDIT_LOG).paradigm(REPLY).vrsn(VERSION).build()).build()).build())
						.build()).build();
		assertThrows(RuntimeException.class,()-> auditLogService.getAuditLogData("24/Mar/2023", "24/Mar/2023", "abc", "screenName", "UPLOAD","1:0:0:0"));
	}
}
