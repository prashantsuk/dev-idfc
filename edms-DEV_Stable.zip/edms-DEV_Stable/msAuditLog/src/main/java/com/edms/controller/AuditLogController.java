package com.edms.controller;

import java.util.List;

import com.edms.model.AuditLog;
import com.edms.service.AuditLogServiceImpl;
import com.fasterxml.jackson.core.JsonProcessingException;

import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.QueryValue;
import jakarta.inject.Inject;

@Controller
public class AuditLogController {

	@Inject
	AuditLogServiceImpl auditLogServiceImpl;
	
	@Post("/auditLog")
	public HttpResponse<String> addAuditLog(@Body AuditLog auditLog) throws JsonProcessingException
	{
		return HttpResponse.ok(auditLogServiceImpl.addAuditLog(auditLog));
	}
	
	@Get("/auditLog")
	public HttpResponse<List<AuditLog>> getAuditData(
			@QueryValue(defaultValue = "") String fromDate, 
			@QueryValue(defaultValue = "") String toDate,
			
			@QueryValue(defaultValue = "") String searchKey,
			@QueryValue(defaultValue = "") String searchValue
			, HttpRequest<?> request) throws JsonProcessingException
	{
		return HttpResponse.ok(auditLogServiceImpl.getAuditLogData(fromDate,toDate, "",searchKey,searchValue,request.getRemoteAddress().getAddress().getHostAddress()));
	}
}
