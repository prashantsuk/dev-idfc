package com.edms;

import io.micronaut.runtime.Micronaut;

public class AuditLogApplication {

    public static void main(String[] args) {
        Micronaut.run(AuditLogApplication.class, args);
       
    }
}