package com.edms.repository;

import java.util.List;

import com.edms.domain.EDPAuditLog;

public interface EDPAuditLogRepo {

	public List<EDPAuditLog> findAll();
}
