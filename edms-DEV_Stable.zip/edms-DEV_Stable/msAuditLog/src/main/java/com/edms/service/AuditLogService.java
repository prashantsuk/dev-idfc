package com.edms.service;

import java.util.List;

import com.edms.model.AuditLog;
import com.fasterxml.jackson.core.JsonProcessingException;

public interface AuditLogService {

	public String addAuditLog(AuditLog auditLog) throws JsonProcessingException;
	public List<AuditLog> getAuditLogData(String fromDate, String toDate, String user, String searchKey, String searchValue, String ipAddress) throws JsonProcessingException;
}
