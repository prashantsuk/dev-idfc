package com.edms.domain;

import com.aerospike.mapper.annotations.AerospikeBin;
import com.aerospike.mapper.annotations.AerospikeKey;
import com.aerospike.mapper.annotations.AerospikeRecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@AerospikeRecord(namespace = "test",set = "edp_auditlog")
public class EDPAuditLog {

	
	@AerospikeKey
	@AerospikeBin(name = "PK")
	private long pk;
	
	@AerospikeBin(name = "ACTION")
	private String action;
	
	@AerospikeBin(name = "AGREEMENTID")
	private String agreementId;
	
	@AerospikeBin(name = "APPID")
	private String appId;
	
	@AerospikeBin(name = "CREATEBY")
	private String createdBy;
	
	@AerospikeBin(name = "CREATEDDATE")
	private String createdDate;
	
	@AerospikeBin(name = "CURRENTVALUE")
	private String currentValue;
	
	@AerospikeBin(name = "CUSTOMERID")
	private String customerId;
	
	@AerospikeBin(name = "SOURCENAME")
	private String sourceName;
	
	@AerospikeBin(name = "LASTUPDATEDDATE")
	private String lastUpdatedDate;
	
	@AerospikeBin(name = "LOANNO")
	private String loanNo;
	
	@AerospikeBin(name = "MODIFIEDBY")
	private String modifiedBy;
	
	@AerospikeBin(name = "OLDVALUE")
	private String oldValue;
	
	@AerospikeBin(name = "CATEGORY")
	private String category;
	
	@AerospikeBin(name = "STATUS")
	private String status;
	
	@AerospikeBin(name = "TABLENAME")
	private String tableName;
	
	@AerospikeBin(name = "UCIC")
	private String ucic;
	
	@AerospikeBin(name = "USERNAME")
	private String userName;
	
	@AerospikeBin(name = "ROLENAME")
	private String roleName;
	
	@AerospikeBin(name = "REASON")
	private String reason;
	
	@AerospikeBin(name = "ACCOUNTNUMBER")
	private String accountNumber;
	
	@AerospikeBin(name = "SCREENNAME")
	private String screenName;
	
	@AerospikeBin(name = "PRODUCTNAME")
	private String productName;
	
	@AerospikeBin(name = "CUSTOMERTYPE")
	private String customerType;
	
	@AerospikeBin(name = "DOCTYPEID")
	private String docTypeId;
	
	@AerospikeBin(name = "DOCUMENTNAME")
	private String documentName;
	
	@AerospikeBin(name = "DOCUMENTSTATUS")
	private String documentStatus;
	
	@AerospikeBin(name = "DOCUMENTTITLE")
	private String documentTitle;
	
	@AerospikeBin(name = "DOCUMENTVERSION")
	private String documentVersion;
	
	@AerospikeBin(name = "DOCUMENTTYPE")
	private String documentType;
	
	@AerospikeBin(name = "CUSTOMERNAME")
	private String customerName;
	
	@AerospikeBin(name = "FILEPATH")
	private String filePath;
	
	@AerospikeBin(name = "FAILEDSTAGE")
	private String failedStage;
	
	@AerospikeBin(name = "QUARANTINSTATUS")
	private String quarantineStatus;
	
	@AerospikeBin(name = "SEARCHBY")
	private String searchBy;

	@AerospikeBin(name = "SEARCHDATE")
	private String searchDate;
	
	@AerospikeBin(name = "AUDITDATE")
	private String auditDate;
	
	@AerospikeBin(name = "IPADDRESS")
	private String ipAddress;
}
