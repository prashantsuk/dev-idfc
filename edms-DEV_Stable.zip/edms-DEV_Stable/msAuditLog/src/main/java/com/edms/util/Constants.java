package com.edms.util;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Constants {
	private Constants() {}
	
	public static final String EXP_400="EXP_400";
	public static final String EXP_415="EXP_415";
	public static final String EXP_404="EXP_404";
	public static final String EXP_405="EXP_405";
	public static final String EXP_503="EXP_503";
	public static final String EXP_500="EXP_500";
	public static final String EXP_504="EXP_504";
	
	public static final String SYS_400="SYS_400";
	public static final String SYS_415="SYS_415";
	public static final String SYS_404="SYS_404";
	public static final String SYS_405="SYS_405";
	public static final String SYS_503="SYS_503";
	public static final String SYS_500="SYS_500";
	public static final String SYS_504="SYS_504";
	
	
	protected static final Map<String, String> errorDef=new HashMap<>();
	
	static {
		errorDef.put(EXP_400, "Bad Request");
		errorDef.put(SYS_400, "Bad Request");
		errorDef.put(EXP_404, "Resource not found");
		errorDef.put(SYS_404, "Resource not found");
		errorDef.put(EXP_415, "Unsupported Media type");
		errorDef.put(SYS_415, "Unsupported Media type");
		errorDef.put(EXP_405, "Method not allowed");
		errorDef.put(SYS_405, "Method not allowed");
		errorDef.put(EXP_503, "Connectivity Error");
		errorDef.put(SYS_503, "Connectivity Error");
		errorDef.put(EXP_500, "Internal Server error");
		errorDef.put(SYS_500, "Internal Server error");
		errorDef.put(EXP_504, "HTTP Request timeout");
		errorDef.put(SYS_504, "HTTP Request timeout");
	}
	
	
	public static final String OK="OK";
	
	public static final String VERSION="1.0.0";
	
	public static final String REPLY="Reply";
	
	public static final String EXCEPTION_OCCURED="Exception occured: {}";
	
	public static final String AUDIT_LOG="AUDIT LOG";
	
	public static final String DOC_MGMT="doc-mgmt";
	
	public static final String ERROR="ERROR";
	
	public static final String SUCCESS="SUCCESS";
	
	public static final String FAILED="FAILED";
	
	public static final String CUSTOMER_ID="CustomerId";
	
	public static final String AGREEMENT_ID="AgreementId";
	
	public static final String UCIC="Ucic";
	
	public static final String MOBILE_NUMBER="MobileNo";
	
	public static final String ASSETS="Assets";
	
	public static final String LIABILITIES="Liabilities";
	
	public static final String MAIN="Main";
	
	public static final String STAGING="Staging";
	
	public static final String NO="N";
	
	public static final String YES="Y";

	public static final String DATE_FORMAT="dd/MMM/yyyy hh:mm a";
	
	public static final String FROM_DATE=" from date : ";
	
	public static final String TO_DATE=" to date : ";
	
	public static final String FOR_SEARCH_KEY=" for search key : ";
	
	public static final String FOR_SEARCH_VALUE=" and value : ";
	
	protected static final Map<String, String> SEARCH_KEY;
	
	static {
		SEARCH_KEY=new HashMap<>();
		SEARCH_KEY.put("category", "CATEGORY");
		SEARCH_KEY.put("sourceName", "SOURCENAME");
		SEARCH_KEY.put("productName", "PRODUCTNAME");
		SEARCH_KEY.put("documentType", "DOCUMENTTYPE");
		SEARCH_KEY.put("documentName", "DOCUMENTNAME");
		SEARCH_KEY.put("userName", "USERNAME");
		SEARCH_KEY.put("screenName", "SCREENNAME");
	}
	
	public static final Map<String, String> SEARCH_KEY_MAP=Collections.unmodifiableMap(SEARCH_KEY);
}
