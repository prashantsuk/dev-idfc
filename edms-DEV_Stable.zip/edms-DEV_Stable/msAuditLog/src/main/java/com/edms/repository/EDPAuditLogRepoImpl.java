package com.edms.repository;

import java.util.List;

import com.aerospike.client.query.Filter;
import com.aerospike.mapper.tools.AeroMapper;
import com.edms.domain.EDPAuditLog;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class EDPAuditLogRepoImpl implements EDPAuditLogRepo{
	
	@Inject
	AeroMapper aeroMapper;
	
	
	public List<EDPAuditLog> findAll()
	{
		return aeroMapper.scan(EDPAuditLog.class);
	}	
	
	public void save(EDPAuditLog edpAuditLog)
	{
		aeroMapper.save(edpAuditLog);
	}
	
	
	public List<EDPAuditLog> findByColumn(String binName,String value)
	{
		return aeroMapper.query(EDPAuditLog.class,Filter.equal(binName, value));
	}
}
