package com.edms.service;

import org.slf4j.Marker;
import static com.edms.util.Constants.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.slf4j.MarkerFactory;

import com.edms.domain.EDPAuditLog;
import com.edms.model.AuditLog;
import com.edms.repository.EDPAuditLogRepoImpl;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

@Singleton
@Slf4j
public class AuditLogServiceImpl implements AuditLogService {

	@Inject
	private EDPAuditLogRepoImpl edpAuditLogRepoImpl;
	
	private Marker marker=MarkerFactory.getMarker("ACCESS");
	
	private DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FORMAT);
	
	public String addAuditLog(AuditLog auditLog) throws JsonProcessingException
	{
		log.info("audit log called with request: {}",new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT).writeValueAsString(auditLog));
		
		//inserting in access log flat file
		log.info(marker,auditLog.getMessage());
		
		String date=getCurrentDate();
		
		Long pk=edpAuditLogRepoImpl.findAll().stream().map(EDPAuditLog::getPk).max(Comparator.naturalOrder()).orElse(0L);
		
		EDPAuditLog edpAuditLog=EDPAuditLog.builder().action(auditLog.getAction()).createdDate(auditLog.getCreatedDate()).createdBy(auditLog.getCreatedBy()).documentType(auditLog.getDocumentType()).failedStage(auditLog.getFailedStage()).
				currentValue(auditLog.getCurrentValue()).customerId(auditLog.getCustomerId()).sourceName(auditLog.getSourceName()).docTypeId(auditLog.getDocTypeId()).customerType("").reason(auditLog.getReason()).ipAddress(auditLog.getIpAddress()).
				lastUpdatedDate(auditLog.getLastUpdateDate()).modifiedBy(auditLog.getModifiedBy()).oldValue(auditLog.getOldValue()).status(auditLog.getStatus()).quarantineStatus(auditLog.getQuarantineStatus()).auditDate(date).
				roleName(auditLog.getRoleName()).pk(pk+1L).agreementId(auditLog.getAgreementId()).appId("").category(auditLog.getCategory()).productName(auditLog.getProductName()).searchBy(auditLog.getSearchBy()).searchDate(date)
				.loanNo(auditLog.getLoanNo()).tableName(auditLog.getTableName()).ucic(auditLog.getUcic()).userName(auditLog.getCreatedBy()).accountNumber(auditLog.getAccountNumber()).screenName(auditLog.getScreenName()).
				documentName(auditLog.getDocumentName()).documentStatus("").documentTitle(auditLog.getDocumentTitle()).documentVersion(auditLog.getDocumentVersion()).customerName(auditLog.getCreatedBy()).filePath("").build();
		
		edpAuditLogRepoImpl.save(edpAuditLog);	
		
		return SUCCESS;
	}
	
	
	public List<AuditLog> getAuditLogData(String fromDate, String toDate, String user, String searchKey, String searchValue, String ipAddress) throws JsonProcessingException
	{
		String message="";
		try 
		{
			String date=getCurrentDate();
		
			List<EDPAuditLog> list=null;
			
			//filter out last 24hrs data
			if( fromDate.length()==0 && toDate.length()==0 && searchKey.length()==0)
			{
				message=" for last 24 hours";
				list=searchLast24Hours();	
			}
			
			//filter based on Dates only
			else if( searchKey.length()==0 && fromDate.length()>0 && toDate.length()>0) {
				
				message=FROM_DATE+fromDate+TO_DATE+toDate;
				list=searchBasedOnDates(list, fromDate, toDate);	
			}
			
			//filter based on search key and value only
			else if(fromDate.length()==0&& toDate.length()==0 && SEARCH_KEY_MAP.containsKey(searchKey))
			{
				message=FOR_SEARCH_KEY+searchKey+FOR_SEARCH_VALUE+searchValue;
				list=searchBasedOnSearchKey(SEARCH_KEY_MAP.get(searchKey), searchValue);	
			}
			
			//filter based on combination of search key, value and fromDate, toDate
			else if(SEARCH_KEY_MAP.containsKey(searchKey))
			{
				message=FOR_SEARCH_KEY+searchKey+FOR_SEARCH_VALUE+searchValue+FROM_DATE+fromDate+TO_DATE+toDate;
				list=searchBasedOnSearchKeyAndDates(SEARCH_KEY_MAP.get(searchKey), searchValue, fromDate, toDate);
			}
			
			List<AuditLog> auditLoglist= list==null? new ArrayList<>(): buildAuditLogMetaData(list);
			auditLoglist=auditLoglist.stream().sorted(Comparator.comparing(AuditLog::getTimeStamp).reversed()).collect(Collectors.toList());

			AuditLog auditLog=AuditLog.builder().action(AUDIT_LOG).searchBy(user).searchDate(date).currentValue("").oldValue("").roleName("")	
					.screenName(AUDIT_LOG).userName(user).status(SUCCESS).message(user+" searched for audit log" +message).ipAddress(ipAddress).build();
			
			addAuditLog(auditLog);
			
			return auditLoglist;
		}
		catch (Exception e) 
		{
			String date=getCurrentDate();
			AuditLog auditLog=AuditLog.builder().action(AUDIT_LOG).searchBy(user).searchDate(date).currentValue("").oldValue("").roleName("").ipAddress(ipAddress)	
					.screenName(AUDIT_LOG).userName(user).status(FAILED).message(user+" searched for audit log" +message).failedStage("Get audit log details from db") .build();
			
			addAuditLog(auditLog);
			
			throw e;
		}
	}
	
	
	private List<EDPAuditLog> searchLast24Hours()
	{
		List<EDPAuditLog> list= edpAuditLogRepoImpl.findAll();
		
		LocalDateTime yesterdaysDate =LocalDateTime.now().minusDays(1);
		
		list=list.stream().filter(f->Objects.nonNull(f.getAuditDate())).filter(f-> LocalDateTime.parse(f.getAuditDate(), dtf).isAfter(yesterdaysDate)).collect(Collectors.toList());
		
		return list;
	}
	
	
	private List<EDPAuditLog> searchBasedOnSearchKey(String searchKey, String searchValue )
	{
		return edpAuditLogRepoImpl.findByColumn(searchKey, searchValue);
	}
	
	
	private List<EDPAuditLog> searchBasedOnDates(List<EDPAuditLog> list, String fromDate, String toDate)
	{
		if(list==null)
			list= edpAuditLogRepoImpl.findAll();
		
		fromDate=fromDate.concat(" 00:00 AM");
		toDate=toDate.concat(" 11:59 PM");
		LocalDateTime fromDateTime=LocalDateTime.parse(fromDate, dtf);
		LocalDateTime toDateTime=LocalDateTime.parse(toDate, dtf);
		
		list=list.stream().filter(f->Objects.nonNull(f.getAuditDate())).filter(f-> {
			LocalDateTime dataDateTime=LocalDateTime.parse(f.getAuditDate(), dtf);
			
			return ((dataDateTime.isAfter(fromDateTime)&&dataDateTime.isBefore(toDateTime))
				||(dataDateTime.isAfter(fromDateTime)&&dataDateTime.isEqual(toDateTime) )
				||(dataDateTime.isEqual(fromDateTime)&&dataDateTime.isBefore(toDateTime))  
				||(dataDateTime.isEqual(fromDateTime)&&dataDateTime.isEqual(toDateTime)));
		})
			.collect(Collectors.toList());
		return list;
	}
	
	
	private List<EDPAuditLog> searchBasedOnSearchKeyAndDates( String searchKey, String searchValue, String fromDate, String toDate)
	{
		List<EDPAuditLog> list= searchBasedOnSearchKey(searchKey, searchValue);
		
		list=searchBasedOnDates(list, fromDate, toDate);
		
		return list;
	}
	
	
	private String getCurrentDate() {
		LocalDateTime now = LocalDateTime.now();
		return (dtf.format(now));
	}
	
	
	private List<AuditLog> buildAuditLogMetaData(List<EDPAuditLog> list)
	{
		List<AuditLog> auditLogList=new ArrayList<>();
		list.stream().filter(f->!f.getAction().contains("LOG IN")).forEach(data->
				auditLogList.add(AuditLog.builder().userName(data.getUserName()).roleName(data.getRoleName()).customerId(data.getCustomerId()).searchBy(data.getSearchBy())
						.productName(data.getProductName()).ucic(data.getUcic()).agreementId(data.getAgreementId()).loanNo(data.getLoanNo()).failedStage(data.getFailedStage())
						.accountNumber(data.getAccountNumber()).action(data.getAction()).screenName(data.getScreenName()).timeStamp(LocalDateTime.parse(data.getAuditDate(), dtf))
						.updatedBy(data.getModifiedBy()).updatedDate(data.getLastUpdatedDate()).createdDate(data.getCreatedDate()).searchDate(data.getSearchDate()).build())
				);
		return auditLogList;
	}
}