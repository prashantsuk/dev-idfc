import React, {useEffect, useState} from 'react';
import './Header.css';
// import axios from 'axios'
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import Avatar from '@mui/material/Avatar';
import SearchIcon from '@mui/icons-material/Search';
import { BsUpload } from "react-icons/bs";
import UploadPage from '../Component/UploadPage/UploadPage';
import LogoutIcon from '@mui/icons-material/Logout';
import { grey } from '@mui/material/colors';
import CloseIcon from '@mui/icons-material/Close';
import { useSelector } from 'react-redux';
import { selectSetUserData } from '../features/userDataSlice';
import { useNavigate } from 'react-router-dom';
// import UploadPage1 from '../Component/UploadPage/UploadPage1';


function Header({setShowLogin}) {

  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [dropdownOpen, setDropdownOpen] = useState(false);
 
  const userData = useSelector(selectSetUserData);
  const navigate = useNavigate();

  const toggleDropdown = () => {
    setDropdownOpen(!dropdownOpen);
  };

  const handleLogout = () => {
    setShowLogin(true);
    clearSessionToken();
    navigate("");
  };
    const clearSessionToken = () => {
    localStorage.removeItem('sessionToken');
    };

  const handleSubmit = async (event) => {
    event.preventDefault();
  //   dispatch(openSearchPage());
    // const response = await axios.get(`https://3dc9-49-36-186-97.in.ngrok.io/searchData?custId=${searchQuery} `);
    // setSearchResults(response.data);
    // console.log(response.data);
    // setSearchQuery('');
  }
  return (
    <div className='header'>
     <div className="header-top">
      <div className="header-left">
        <h5>Enterprise Document Portal</h5>
      </div>
      {/* <div className="header-right dropdown"  style={{ position: "relative" }}> 
      <button style={{outline:'none'}}
        type="button"
        className="btn "
        onClick={toggleDropdown}>
     
        <span style={{color:'white'}}>{userData.userName}<ArrowDropDownIcon/></span>
        <div className="user-role">
        <p style={{paddingRight:'25px'}}>{userData.userRole}</p>
        </div>
        </button>
        {dropdownOpen && (
        <div className="dropdown-menu" style={{ display: "block", position: "absolute", top: "100%", right: 10, padding:'15px 40px 15px 7px' }}>
           <button className="dropdown-item">
           <span className='account-name account-text '><Avatar sx={{ width:25, height: 25, bgcolor: grey[900], marginRight:'7PX'}}/>Account</span>
          </button>
          <button className="dropdown-item" onClick={handleLogout}>
           <span className='account-name logout-text'><LogoutIcon sx ={{marginRight:'7PX'}}/>Logout</span>
          </button>
        </div>
      )}
  
      </div> */}
      </div>
      <div className="header-bottom">
     
        <div className="header-search">
          <input type="text" value={searchQuery} onChange={event => setSearchQuery(event.target.value)} placeholder="Search" />
          <button type="submit" onClick={handleSubmit}><SearchIcon fontSize ="large"/></button>
         {searchResults.map(result => (
        <div key={result.id}>{result.title}</div>
          ))}
      
        </div>
       
        <div className="header-button">
        <div className="header-right dropdown"  style={{ position: "relative" }}> 
      <button style={{outline:'none'}}
        type="button"
        className="btn "
        onClick={toggleDropdown}>
     
        <span style={{color:'white'}}>{userData.userName}<ArrowDropDownIcon/></span>
        <div className="user-role">
        <p>{userData.userRole}</p>
        </div>
        </button>
        {dropdownOpen && (
        <div className="dropdown-menu" style={{ display: "block", position: "absolute", top: "100%", right: 10, padding:'15px 40px 15px 7px' }}>
           <button className="dropdown-item">
           <span className='account-name account-text '><Avatar sx={{ width:25, height: 25, bgcolor: grey[900], marginRight:'7PX'}}/>Account</span>
          </button>
          <button className="dropdown-item" onClick={handleLogout}>
           <span className='account-name logout-text'><LogoutIcon sx ={{marginRight:'7PX'}}/>Logout</span>
          </button>
        </div>
      )}
  
      </div>
      
          <UploadPage userName = {userData.userName}/>
          {/* <UploadPage1/> */}

        </div>
       

      </div>
    </div>
  )
}

export default Header