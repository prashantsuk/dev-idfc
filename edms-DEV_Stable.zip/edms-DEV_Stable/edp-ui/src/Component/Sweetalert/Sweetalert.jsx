import React from 'react';
import './Sweetalert.css';
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';


export default function Sweetalert() {
    const MySwal = withReactContent(Swal);

    const onSubmit = () =>{
        MySwal.fire({
            title: <p>Succesfully Uploaded</p>,
            didOpen: () => {
              Swal.fire(
                  'Successfully Uploaded',
                  'view path',
                  'success'
                )
            },
           
          }).then(() => {
            return MySwal.fire(<p>Shorthand works </p>)
          })
    }

    const onConfirm =() => {
        Swal.fire({
            title: 'Are you sure?',
            text: "You won't be able to revert this!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Yes, delete it!'
          }).then((result) => {
            if (result.isConfirmed) {
              Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            }
          })
    }

  return (
    <div>
      
      <button className='btn btn-success mt-2' onClick = {onSubmit}>Submit</button> <br/>
      <button className='btn btn-danger mt-2' onClick = {onConfirm}>Delete</button>      
    </div>
  )
}
