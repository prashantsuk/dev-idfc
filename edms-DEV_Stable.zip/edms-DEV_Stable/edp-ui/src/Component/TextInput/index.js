import React from 'react';
import './index.css';

const TextInput = (props) => {

    const { placeholder, onChange, name } = props;

    const handleChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        onChange(value, name);
    }

    return (
        <input name={name} className='textInput' placeholder={placeholder} onChange={handleChange} type="text" />
    );
}

export default TextInput;