import React, { useState } from 'react';
import TableCell from '@mui/material/TableCell';
import IconButton from '@mui/material/IconButton';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

const PasswordCell = ({ password }) => {
  const [showPassword, setShowPassword] = useState(false);

  const handleShowPassword = () => {
    setShowPassword(!showPassword);
  };

  const maskedPassword = password ? password.replace(/./g, '*') : '';

  return (
    <TableCell>
        {password && (showPassword ? password : maskedPassword)}
      {password && (
        <IconButton onClick={handleShowPassword}>
          {showPassword ? <VisibilityOff /> : <Visibility />}
        </IconButton>
      )}
    </TableCell>
  );
};

export default PasswordCell;