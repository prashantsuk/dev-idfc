import React,{useState} from 'react';
import './index.css';
import DashboardIcon from '@mui/icons-material/Dashboard';
import IconButton from '@mui/material/IconButton';
import { red} from '@mui/material/colors';

export default function TableData({data, source, keyName}) {
  const [showPassword, setShowPassword] = useState(false);
    console.log(data);
    console.log(source);
    console.log(keyName);
    console.log(keyName[0]);
    console.log(keyName[1]);
    console.log(source === keyName[1]);

    const getPasswordDisplay = (password) => {
      if (!password) {
        return "";
      }
      if (showPassword) {
        return password;
      } else {
        // return password.substring(0, 8).replace(/[.]/g, "*");
        const maskedPassword = password.substring(0, 8).replace(/./g, "*");
    console.log("Masked Password:", maskedPassword);
    return maskedPassword;
      }
    };
    
    
  return (
    <div>
       <div className = 'tab-page'>
        
            <div className='document-view'>
                <div className='doc-no'>
                    <p style={{fontWeight:"bold"}}>Document  <span className='doc-count'> 1</span></p>
                </div>
                <IconButton> <DashboardIcon sx={{ width:15, height: 15, bgcolor: red[900]}}/></IconButton>
            </div>
            
         
           <div style={{height:'400px', overflow:''}}>
           <table className="table">
                <thead>
                    <tr>
                        <th>
                            <input className="form-check-input" type="checkbox" />
                        </th>
                        <th className='table-title-text' scope="col">Document Type</th>
                        <th className='table-title-text' scope="col">Document Name</th>
                        <th className='table-title-text' scope="col">Document ID</th>
                        <th className='table-title-text' scope="col">Document Password</th>
                        <th className='table-title-text' scope="col">File Type</th>
                        <th className='table-title-text' scope="col">Size</th>
                        <th className='table-title-text' scope="col">No. of Pages</th>
                        <th className='table-title-text' scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>

                {data[keyName[0]].map((item, itemIndex) => {
                  return (
                    <tr key={itemIndex}>
                      <td>
                        <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                      </td>
                      <td className='content-text'>{item.docType}</td>
                      <td className='content-text'>{item.docName}</td>
                      <td>{item.docId}</td>
                      <td>
                        <div className='eye-password' style={{ display: "flex" }}>
                          <input type={showPassword ? "text" : "password"} value={getPasswordDisplay(item.docPassword)} readOnly />
                          
                          {item.docPassword && (
                          
                          <button onClick={() => setShowPassword(!showPassword)}>
                          {showPassword ? <i class="bi bi-eye-fill"/> : <i class="bi bi-eye-slash-fill"/>}
                          </button>
                           )}
                        </div>
                    </td>
                      <td>{item.fileType}</td>
                      <td>{item.size}</td>
                      <td>{item.noOfPages}</td>
                      <td><button className='button-stylee' type="button">View</button></td>
                    </tr>
                  )
                })}
                  
       
                </tbody>
            </table> 
             </div>   

            <div className='footer-view'>
                <div className='pagination-text-view'>
                    <p className='content-text'>Items per page</p>
                    <select className='pagination-dropdown' name="page" id="page">
                        <option value="five">5</option>
                        <option value="ten">10</option>
                        <option value="fifteen">15</option>
                        <option value="twenty">20</option>
                    </select>
                    <p className='vertical-line-text'>|</p>
                    <p className='content-text'>1 - 5 of 5 Items</p>
                </div>
                <div className='pagination-button-view'>
                    <p className='content-text'>Viewing page</p>
                    <div className='page-number-box-view'>
                        <p className='pagination-text'>1</p>
                    </div>
                    <p className='content-text'>Of 1 pages</p>
                </div>
            </div>
        </div>  
    </div>
  )
}


// import { useState } from 'react';
// import { Tabs, Tab } from 'react-bootstrap';

//  export default function TableData({ data, keyName }) {
    
//   const [activeTab, setActiveTab] = useState(0);

//   return (
//     <Tabs activeKey={activeTab} onSelect={(key) => setActiveTab(parseInt(key))}>
//       {Object.keys(data).map((keyName, index) => {
//         return (
//           <Tab key={keyName} eventKey={index} title={keyName}>
//             <table className="table">
//               <thead>
//                 <tr>
//                   <th>
//                     <input className="form-check-input" type="checkbox" />
//                   </th>
//                   <th className='table-title-text' scope="col">Document Type</th>
//                   <th className='table-title-text' scope="col">Document Name</th>
//                   <th className='table-title-text' scope="col">Document ID</th>
//                   <th className='table-title-text' scope="col">Document Password</th>
//                   <th className='table-title-text' scope="col">File Type</th>
//                   <th className='table-title-text' scope="col">Size</th>
//                   <th className='table-title-text' scope="col">No. of Pages</th>
//                   <th className='table-title-text' scope="col">Actions</th>
//                 </tr>
//               </thead>
//               <tbody>
//                 {data[keyName].map((item, itemIndex) => {
//                   return (
//                     <tr key={itemIndex}>
//                       <td>
//                         <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
//                       </td>
//                       <td className='content-text'>{item.docType}</td>
//                       <td className='content-text'>{item.docName}</td>
//                       <td>{item.docId}</td>
//                       <td>{item.docPassword}</td>
//                       <td>{item.fileType}</td>
//                       <td>{item.size}</td>
//                       <td>{item.noOfPages}</td>
//                       <td><button className='button-stylee' type="button">View</button></td>
//                     </tr>
//                   )
//                 })}
//               </tbody>
//             </table>
//           </Tab>
//         )
//       })}
//     </Tabs>
//   );
// }



// import { useState } from 'react';
// import { Tabs, Tab } from 'react-bootstrap';
// import AllDocuments from '../AllDocument';


// export default function TableData({ data, keyName }) {
//   const [activeTab, setActiveTab] = useState(0);
//   const[docData, setDocData] = useState([]);

//   return (
//     <div className="grid-container">
//       <div className="tab-list">
//         <Tabs activeKey={activeTab} onSelect={(key) => setActiveTab(parseInt(key))}>
//         {/* <Tab key="AllDocuments" eventKey="AllDocuments" title="All Documents">
//         <AllDocuments />
//       </Tab> */}
//           {Object.keys(data).map((keyName, index) => {
//             return (
//               <Tab key={keyName} eventKey={index} title={keyName}></Tab>
//             )
//           })}
//         </Tabs>
//       </div>
//       <div className="table-content">
//         <Tabs activeKey={activeTab} onSelect={(key) => setActiveTab(parseInt(key))}>
//           {Object.keys(data).map((keyName, index) => {
//             return (
//               <Tab key={keyName} eventKey={index}>
//                 <table className="table">
//                   <thead>
//                     <tr>
//                       <th>
//                         <input className="form-check-input" type="checkbox" />
//                       </th>
//                       <th className='table-title-text' scope="col">Document Type</th>
//                       <th className='table-title-text' scope="col">Document Name</th>
//                       <th className='table-title-text' scope="col">Document ID</th>
//                       <th className='table-title-text' scope="col">Document Password</th>
//                       <th className='table-title-text' scope="col">File Type</th>
//                       <th className='table-title-text' scope="col">Size</th>
//                       <th className='table-title-text' scope="col">No. of Pages</th>
//                       <th className='table-title-text' scope="col">Actions</th>
//                     </tr>
//                   </thead>
//                   <tbody>
//                     {data[keyName].map((item, itemIndex) => {
//                       return (
//                         <tr key={itemIndex}>
//                           <td>
//                             <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
//                           </td>
//                           <td className='content-text'>{item.docType}</td>
//                           <td className='content-text'>{item.docName}</td>
//                           <td>{item.docId}</td>
//                           <td>{item.docPassword}</td>
//                           <td>{item.fileType}</td>
//                           <td>{item.size}</td>
//                           <td>{item.noOfPages}</td>
//                           <td><button className='button-stylee' type="button">View</button></td>
//                         </tr>
//                       )
//                     })}
//                   </tbody>
//                 </table>
//               </Tab>
//             )
//           })}
//         </Tabs>
//       </div>
//     </div>
//   );
// }
