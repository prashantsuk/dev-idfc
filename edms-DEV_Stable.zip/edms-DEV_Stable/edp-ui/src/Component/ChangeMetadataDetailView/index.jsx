import React, { useEffect, useState} from 'react';
import axios from 'axios';
import './index.css';
import TextInput from "../TextInput";
import AllDocuments from '../AllDocument';
import DashboardIcon from '@mui/icons-material/Dashboard';
import IconButton from '@mui/material/IconButton';
import { red} from '@mui/material/colors';
import { fontWeight, textAlign } from '@mui/system';
import TableData from './TableData';
import { Tabs, Tab } from 'react-bootstrap';

const ChangeMetadataDetailView = ({metaData, data, productList, mapList}) => {
    // console.log(data, metaData);
    const [activeTab, setActiveTab] = useState('finnone');
    const [searchText, setSearchText] = useState("");
    const[finnone, setFinnone] = useState(true);
    const[sfdc, setSfdc] = useState(true);
    const[tradefin, setTradefin] = useState(true);
    const[edp, setEdp] = useState(true);
    const[bpm, setBpm] = useState(true);
    const[alldoc, setAlldoc] = useState(false);
    const[activeTradefin, setActiveTradeFin] = useState(false);
    const[activeEdp, setActiveEdp] = useState(false);
    const[activeSfdc, setActiveSfdc] = useState(false);
    const[activeFinnone, setActiveFinnone] = useState(false);
    const[activeDoc, setActiveDoc] = useState(false);
    const[activeBpm, setActiveBpm] = useState(false);
    const[docData, setDocData] = useState([]);
    const[show, setShow] = useState(false);

    // State to keep track of the selected option and the corresponding data
    const [selectedOption, setSelectedOption] = useState(data.productName);
    console.log(Object.keys(mapList)[0]);
    const [selectedData, setSelectedData] = useState(mapList[selectedOption]);
    console.log(mapList[selectedOption]);

    // Handler function to update the selected option and corresponding data
   
        const handleOptionChange = (e) => {
            const option = e.target.value;
            setSelectedOption(option);
            console.log(option);
            setSelectedData(mapList[option]);
            console.log(mapList[option]);
            console.log(Object.keys(selectedData));
            console.log(Object.values(selectedData));
           
        };

    const options = Object.keys(mapList);

    const allDocUrl = `http://52.140.58.184:9414/msGetMetaData/getMetaData/allDocument?custId=${data.custId}`;

    useEffect( () =>{
      const fetchDocData = async() =>{
          const response = await axios.get(allDocUrl, {headers:{"Access-Control-Allow-Origin": "*"}})
        setDocData(response.data);
          console.log(response.data);
      }
      fetchDocData();
    
    },[])

    const handleTabSelect = (tab) => {
        setActiveTab(tab);
      };

    const handleFinnOne = () =>{
        setActiveTab('finnone');
      setFinnone(true);
      setSfdc(false);
      setTradefin(false);
      setEdp(false);
      setBpm(false);
      setAlldoc(false);
      setActiveFinnone(true);
      setActiveSfdc(false);
      setActiveTradeFin(false);
      setActiveEdp(false);
      setActiveDoc(false);
      setActiveBpm(false);
    }
    const handleSfdc = () =>{
        setActiveTab('sfdc');
        setSfdc(true);
        setFinnone(false);
        setTradefin(false);
        setBpm(false);
        setEdp(false);
        setAlldoc(false);
        setActiveSfdc(true);
        setActiveFinnone(false);
        setActiveEdp(false);
        setActiveDoc(false);
        setActiveBpm(false);
        setActiveTradeFin(false);
    }
    const handleTradeFinance = () =>{
        setActiveTab('tradefinance');
        setTradefin(true);
        setSfdc(false);
        setFinnone(false);
        setEdp(false);
        setBpm(false);
        setAlldoc(false);
        setActiveTradeFin(true);
        setActiveDoc(false);
        setActiveEdp(false);
        setActiveSfdc(false);
        setActiveBpm(false);
        setActiveFinnone(false);
    }
    const handleEdp = () =>{
        setActiveTab('edp');
        setEdp(true);
        setTradefin(false);
        setSfdc(false);
        setFinnone(false);
        setBpm(false);
        setAlldoc(false);
        setActiveEdp(true);
        setActiveTradeFin(false);
        setActiveDoc(false);
        setActiveSfdc(false);
        setActiveBpm(false);
        setActiveFinnone(false);
    }
    const handleDoc = () =>{
        setAlldoc(true);
        setEdp(false);
        setTradefin(false);
        setBpm(false);
        setSfdc(false);
        setFinnone(false);
        setActiveEdp(false);
        setActiveTradeFin(false);
        setActiveDoc(true);
        setActiveSfdc(false);
        setActiveFinnone(false);
        setActiveBpm(false);
    }
    const handleBpm = () =>{
        setActiveTab('bpm');
        setBpm(true);
        setAlldoc(false);
        setEdp(false);
        setTradefin(false);
        setSfdc(false);
        setFinnone(false);
        setActiveEdp(false);
        setActiveBpm(true)
        setActiveTradeFin(false);
        setActiveDoc(false);
        setActiveSfdc(false);
        setActiveFinnone(false);
    }

    return (
        <div className= 'view-page-container'>

        <div className='main-container'>

            <div className='header-view-detail'>
             
                <div className="product-name-dropdown">
                    <select className="form-select shadow-none " id=""value = {selectedOption} onChange={handleOptionChange}>
                  
                    {options.map((option, index) => (
                        <option key={index} value={option}>{option}</option>
                    ))}
                    </select>
          
                </div>
            <div className='search-view'>
                    <div></div>
                    <div className='search-input-box'>
                        <TextInput name={"search"} placeholder={"Search Documents"} onChange={(value, name) => setSearchText(value)} />
                    </div>
                </div>
                
            </div>

            <div className='sub-container'>
               

                <div className='tab-background-view'>
               
                    <ul className="nav">
                       
                            <li className="nav-item">
                            <button className= {`nav-link ${finnone === true && data.source === 'FINNONE' ? 'active' : ''}`} style ={{borderRight: activeFinnone ? '#9D1D27':"", color:activeFinnone ? "#9D1D27":"", textAlign:"left"}}  eventKey="finnone" onClick={handleFinnOne} onSelect={() => handleTabSelect('finnone')}>FINNONE</button>
                            </li>
                        
                            <li className="nav-item">
                             <button className= {`nav-link ${ sfdc === true && data.source=== 'SFDC' ? 'active':''}`} style ={{borderRight: activeSfdc ? '#9D1D27':"", color:activeSfdc ? "#9D1D27":"", textAlign:"left"}}  eventKey="sfdc" onClick={handleSfdc}  onSelect={() => handleTabSelect('sfdc')}>SFDC</button>
                            </li>
                       
                            <li className="nav-item">
                            <button className={`nav-link ${ tradefin === true && data.source === 'TRADE FINANCE' ? 'active' : ''}`} style ={{borderBottom: activeTradefin ? '#9D1D27':"", color:activeTradefin ? "#9D1D27":"", textAlign:"left"}} eventKey="tradeFinance" onClick={handleTradeFinance}  onSelect={() => handleTabSelect('tradeFinance')}>TRADE FINANCE</button>
                            </li>
                      
                            <li className="nav-item">
                            <button className={`nav-link ${ bpm === true && data.source=== 'BPM'? 'active' : ''}`} style ={{borderBottom: activeBpm ? '#9D1D27':"", color:activeBpm ? "#9D1D27":"", textAlign:"left"}}  eventKey="bpm" onClick={handleBpm}  onSelect={() => handleTabSelect('bpm')}>BPM</button>
                            </li> 
                         
                            <li className="nav-item">
                            <button className= {`nav-link ${edp === true && data.source === 'EDP'? 'active' : ''}`} style ={{borderBottom: activeEdp ? '#9D1D27':"", color:activeEdp ? "#9D1D27":"", textAlign:"left"}}  eventKey="edp" onClick={handleEdp}  onSelect={() => handleTabSelect('edp')}>EDP</button>
                            </li>
                                         
                            <li className="nav-item">
                            <button className= {`nav-link ${alldoc ? 'active' : ''}`} style ={{borderBottom: activeDoc ? '#9D1D27':"", color:activeDoc ? "#9D1D27":"", textAlign:"left"}} onClick={handleDoc}>ALL DOCUMENTS</button>
                           </li> 
                        
                    </ul>
                   
                </div>
              

   <div className='tab-page'>
      
       
           { (finnone === true && data.source === 'FINNONE')?
              ( 
              
              <TableData data = {selectedData} keyName ={Object.keys(selectedData)} source ={data.source}/>
              
          ) 
              : (data.source === 'SFDC' && sfdc === true) ?
             
              ( 
                  <TableData data = {selectedData} keyName ={Object.keys(selectedData)} source ={data.source}/>
                 
                  )
              : ( tradefin === true && data.source=== 'TRADE FINANCE')? 
              ( 
                
                <TableData data = {selectedData} keyName ={Object.keys(selectedData)} source ={data.source}/>
                
                )
             : ( bpm === true && data.source === 'BPM') ? 
               ( 
                 
                <TableData data = {selectedData} keyName ={Object.keys(selectedData)} source ={data.source}/>
               
                )
              : ( edp === true && data.source === "EDP") ?
              ( 
                  <TableData data = {selectedData} keyName ={Object.keys(selectedData)}  source = {data.source}/>
                
                  )
               : alldoc === true ? <AllDocuments docData = {docData}/> 
              : <div style={{height:'300px', overflow:'auto', display:'flex', justifyContent:'center', alignItems:'center'}}> No Data to Show</div>
          
          } 
      
        </div>
            </div>
           
        </div>
    </div>
    );
}

export default ChangeMetadataDetailView;