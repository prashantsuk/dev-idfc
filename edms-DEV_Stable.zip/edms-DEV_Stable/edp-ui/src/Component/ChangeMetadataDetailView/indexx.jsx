import React, { useEffect, useState} from 'react';
import axios from 'axios';
import './index.css';
import TextInput from "../TextInput";
import AllDocuments from '../AllDocument';
import DashboardIcon from '@mui/icons-material/Dashboard';
import IconButton from '@mui/material/IconButton';
import { red} from '@mui/material/colors';
import { fontWeight, textAlign } from '@mui/system';
import TableData from './TableData';
import { Tabs, Tab } from 'react-bootstrap';

const ChangeMetadataDetailView = ({metaData, data, productList, mapList}) => {
    // console.log(data, metaData);
    const [activeTab, setActiveTab] = useState(0);
    const [searchText, setSearchText] = useState("");
    const[docData, setDocData] = useState([]);
    const[showPassword, setShowPassword] = useState(false);

    const getPasswordDisplay = (password) => {
        if (!password) {
          return "";
        }
        if (showPassword) {
          return password;
        } else {
          // return password.substring(0, 8).replace(/[.]/g, "*");
          const maskedPassword = password.substring(0, 8).replace(/./g, "*");
      console.log("Masked Password:", maskedPassword);
      return maskedPassword;
        }
      };
    // State to keep track of the selected option and the corresponding data
    const [selectedOption, setSelectedOption] = useState(data.productName);
    console.log(Object.keys(mapList)[0]);
    const [selectedData, setSelectedData] = useState(mapList[selectedOption]);
    console.log(mapList[selectedOption]);

    // Handler function to update the selected option and corresponding data
   
        const handleOptionChange = (e) => {
            const option = e.target.value;
            setSelectedOption(option);
            console.log(option);
            setSelectedData(mapList[option]);
            console.log(mapList[option]);
            console.log(Object.keys(selectedData));
            console.log(Object.values(selectedData));
           
        };

    const options = Object.keys(mapList);

    const allDocUrl = `http://52.140.58.184:9414/msGetMetaData/getMetaData/allDocument?custId=${data.custId}`;

    useEffect( () =>{
      const fetchDocData = async() =>{
          const response = await axios.get(allDocUrl, {headers:{"Access-Control-Allow-Origin": "*"}})
        setDocData(response.data);
          console.log(response.data);
      }
      fetchDocData();
    
    },[])

    // const handleTabSelect = (tab) => {
    //     setActiveTab(tab);
    //   };

   

  const keyName =Object.keys(selectedData);

    return (
        <div className= 'view-page-container'>

        <div className='main-container'>

            <div className='header-view-detail'>
             
                <div className="product-name-dropdown">
                    <select className="form-select shadow-none " id=""value = {selectedOption} onChange={handleOptionChange}>
                  
                    {options.map((option, index) => (
                        <option key={index} value={option}>{option}</option>
                    ))}
                    </select>
          
                </div>
            <div className='search-view'>
                    <div></div>
                    <div className='search-input-box'>
                        <TextInput name={"search"} placeholder={"Search Documents"} onChange={(value, name) => setSearchText(value)} />
                    </div>
                </div>
                
            </div>

            <div className='sub-container'>
           

   <div className='tab-page'>
      
            
              
   <div className="grid-container">
      <div className="tab-list">
        <Tabs  className="custom-tab" activeKey={activeTab} onSelect={(key) => setActiveTab(String(key))}>
          {Object.keys(selectedData).map((keyName, index) => {
            return (
              <Tab key={keyName} eventKey={index} title={keyName}></Tab>
            )
          })}
          <Tab key="AllDocuments" eventKey="AllDocuments" title="All Documents">
        
          </Tab>
        </Tabs>
      </div>
      <div className="table-content">
      {activeTab === 'AllDocuments' && <AllDocuments docData={docData} />}
        <Tabs activeKey={activeTab} onSelect={(key) => setActiveTab(String(key))}>
          {Object.keys(selectedData).map((keyName, index) => {
            return (
              <Tab key={keyName} eventKey={index}>
                <div className='document-view'>
              <div className='doc-no'>
                <p style={{fontWeight:"bold"}}>Document  <span className='doc-count'> 1</span></p>
              </div>
                <IconButton> <DashboardIcon sx={{ width:15, height: 15, bgcolor: red[900]}}/></IconButton>
            </div>
                <table className="table">
                  <thead>
                    <tr>
                      <th>
                        <input className="form-check-input" type="checkbox" />
                      </th>
                      <th className='table-title-text' scope="col">Document Type</th>
                      <th className='table-title-text' scope="col">Document Name</th>
                      <th className='table-title-text' scope="col">Document ID</th>
                      <th className='table-title-text' scope="col">Document Password</th>
                      <th className='table-title-text' scope="col">File Type</th>
                      <th className='table-title-text' scope="col">Size</th>
                      <th className='table-title-text' scope="col">No. of Pages</th>
                      <th className='table-title-text' scope="col">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {selectedData[keyName].map((item, itemIndex) => {
                      return (
                        <tr key={itemIndex}>
                          <td>
                            <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                          </td>
                          <td className='content-text'>{item.docType}</td>
                          <td className='content-text'>{item.docName}</td>
                          <td>{item.docId}</td>
                          <td>
                            <div className='eye-password' style={{ display: "flex" }}>
                            <input type={showPassword ? "text" : "password"} value={getPasswordDisplay(item.docPassword)} readOnly />
                            
                            {item.docPassword && (
                            
                            <button onClick={() => setShowPassword(!showPassword)}>
                            {showPassword ? <i class="bi bi-eye-fill"/> : <i class="bi bi-eye-slash-fill"/>}
                            </button>
                            )}
                            </div>
                          </td>
                          <td>{item.fileType}</td>
                          <td>{item.size}</td>
                          <td>{item.noOfPages}</td>
                          <td><button className='button-stylee' type="button">View</button></td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
                <div className='footer-view'>
                <div className='pagination-text-view'>
                    <p className='content-text'>Items per page</p>
                    <select className='pagination-dropdown' name="page" id="page">
                        <option value="five">5</option>
                        <option value="ten">10</option>
                        <option value="fifteen">15</option>
                        <option value="twenty">20</option>
                    </select>
                    <p className='vertical-line-text'>|</p>
                    <p className='content-text'>1 - 5 of 5 Items</p>
                </div>
                <div className='pagination-button-view'>
                    <p className='content-text'>Viewing page</p>
                    <div className='page-number-box-view'>
                        <p className='pagination-text'>1</p>
                    </div>
                    <p className='content-text'>Of 1 pages</p>
                </div>
            </div>
              </Tab>
              
            )
          })}
        </Tabs>
      </div>
    </div>
              
          
        </div>
            </div>
           
        </div>
    </div>
    );
}

export default ChangeMetadataDetailView;