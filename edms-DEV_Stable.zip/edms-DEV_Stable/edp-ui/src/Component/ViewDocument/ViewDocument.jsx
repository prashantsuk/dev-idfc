import React from 'react';
import './ViewDocument.css';
import { Avatar } from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import {Button} from '@mui/material';
import { deepOrange } from '@mui/material/colors';
import FinnoneData from '../../UserDataViewComponent/FinnoneData/FinnoneData';
import { Router } from '@mui/icons-material';
import UserDataFooter from '../../UserDataViewComponent/UserDataFooter/UserDataFooter';
import SfdcData from '../../UserDataViewComponent/SfdcData/SfdcData';


export default function ViewDocument() {
  return (
    <div className="view-document-screen-layout">
    <div className='view-document'>
         <div className="view-document-screen">
            <div className="user-details">
                <div className="avatar-mg">
                <Avatar src="" sx={{ bgcolor: deepOrange[500] }} />
                </div>
                <div className="user-name">
                    <p className='title'>User name</p>
                    <p className='title-data'>389457839</p>
                </div>
                <div className="edms-id">
                    <p className='title'>EDMS ID</p>
                    <p className='title-data'>10000034568922</p>
                </div>
                <div className="cust-mobile">
                    <p className='title'>Mobile</p>
                    <p className='title-data'>80002456357</p>
                </div>
                <div className="loan-no">
                    <p className='title'>Loan</p>
                    <p className='title-data'>90028543424</p>
                </div>
                <div className="agreement-id">
                    <p className='title'>Agreement Id</p>
                    <p className='title-data'>040024166</p>
                </div>
                <div className="owner-name">
                    <p className='title'>Owner</p>
                    <p className='title-data'>Owner Name</p>
                </div>
            </div>
            <div className="search-field">
             <div div className="header-search">
                <input type="text" placeholder='Search Document'/>
                <SearchIcon fontSize ="small"/>
            </div>
            </div>
            <div className="header-field">
           
                   <Button> FINNONE</Button>
                    <Button> SFDC</Button>
                    <Button> TRADE FINANCE</Button>
                    <Button> EDP</Button>
                    <Button> ALL DOCUMENTS</Button>
             
            </div>
            
            <div className="user-data">
                <FinnoneData/>
            </div>
            <div className="user-detail-footer">
             <UserDataFooter/>
            </div>
          </div>  
          </div>
    </div>
  )
}
