import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './index.css';
import TextInput from "../TextInput";
import SimpleDropDown from "../SimpleDropDown";
import { Avatar } from '@mui/material';
import { red } from '@mui/material/colors';
import Dashboard from '@mui/icons-material/Dashboard';

import AllDocuments from '../AllDocument';
import {
    TableContainer,
    Table,
    TableHead,
    TableBody,
    TableRow,
    TableCell,
    Paper
} from '@mui/material'
import Input from '@mui/material/Input';
import { styled } from '@mui/material/styles';
import Grid from '@mui/material/Grid';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select from '@mui/material/Select';
import PasswordCell from '../PasswordCell';
import ViewFile from './ViewFile';


const ariaLabel = { 'aria-label': 'description' };
const user_avatar = "../../assets/user-avatar.png";
const MetaDataDetailView = ({ metaData, data, tabs, prod }) => {
    const [searchText, setSearchText] = useState("");
    const [finnone, setFinnone] = useState(true);
    const [sfdc, setSfdc] = useState(true);
    const [tradefin, setTradefin] = useState(true);
    const [edp, setEdp] = useState(true);   
    const [bpm, setBpm] = useState(true);
    const [alldoc, setAlldoc] = useState(false);
    const [activeTradefin, setActiveTradeFin] = useState(false);
    const [activeEdp, setActiveEdp] = useState(false);
    const [activeSfdc, setActiveSfdc] = useState(false);
    const [activeFinnone, setActiveFinnone] = useState(false);
    const [activeDoc, setActiveDoc] = useState(false);
    const [activeBpm, setActiveBpm] = useState(false);
    const [docData, setDocData] = useState([]);
    const [show, setShow] = useState(false);
    const values = tabs;
    const [selectedOption, setSelectedOption] = useState(prod[1]);
    const options = prod;
    const handleOptionChange = (event) => {
        setSelectedOption(event.target.value);
    };

    const allDocUrl = `http://52.140.58.184:9414/msGetMetaData/getMetaData/allDocument?custId=${data.custId}`;

    useEffect(() => {
        const fetchDocData = async () => {
            const response = await axios.get(allDocUrl, { headers: { "Access-Control-Allow-Origin": "*" } })
            setDocData(response.data);
            console.log(response.data);
        }
        fetchDocData();

    }, [])

    console.log(prod);

console.log(metaData)
    const handleFinnOne = () => {

        setFinnone(true);
        setSfdc(false);
        setTradefin(false);
        setEdp(false);
        setBpm(false);
        setAlldoc(false);
        setActiveFinnone(true);
        setActiveSfdc(false);
        setActiveTradeFin(false);
        setActiveEdp(false);
        setActiveDoc(false);
        setActiveBpm(false);
    }
    const handleSfdc = () => {
        setSfdc(true);
        setFinnone(false);
        setTradefin(false);
        setBpm(false);
        setEdp(false);
        setAlldoc(false);
        setActiveSfdc(true);
        setActiveFinnone(false);
        setActiveEdp(false);
        setActiveDoc(false);
        setActiveBpm(false);
        setActiveTradeFin(false);
    }
    const handleTradeFinance = () => {
        setTradefin(true);
        setSfdc(false);
        setFinnone(false);
        setEdp(false);
        setBpm(false);
        setAlldoc(false);
        setActiveTradeFin(true);
        setActiveDoc(false);
        setActiveEdp(false);
        setActiveSfdc(false);
        setActiveBpm(false);
        setActiveFinnone(false);
    }
    const handleEdp = () => {
        setEdp(true);
        setTradefin(false);
        setSfdc(false);
        setFinnone(false);
        setBpm(false);
        setAlldoc(false);
        setActiveEdp(true);
        setActiveTradeFin(false);
        setActiveDoc(false);
        setActiveSfdc(false);
        setActiveBpm(false);
        setActiveFinnone(false);
    }
    const handleDoc = () => {
        setAlldoc(true);
        setEdp(false);
        setTradefin(false);
        setBpm(false);
        setSfdc(false);
        setFinnone(false);
        setActiveEdp(false);
        setActiveTradeFin(false);
        setActiveDoc(true);
        setActiveSfdc(false);
        setActiveFinnone(false);
        setActiveBpm(false);
    }
    const handleBpm = () => {
        setBpm(true);
        setAlldoc(false);
        setEdp(false);
        setTradefin(false);
        setSfdc(false);
        setFinnone(false);
        setActiveEdp(false);
        setActiveBpm(true)
        setActiveTradeFin(false);
        setActiveDoc(false);
        setActiveSfdc(false);
        setActiveFinnone(false);
    }
    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'center',
        color: theme.palette.text.secondary,
    }));
    const [age, setAge] = React.useState('');

    const handleChange = (event) => {
        setAge(event.target.value);
    };

    return (
        <div className='main-container '>



            <div className='d-flex justify-content-between ms-4 header_top'>
                {/* <Grid container spacing={3} columns={56}>
                    <Grid item xs={8}>

                        <Item style={{ boxShadow: "none" }} sx={{
                            height: 140,
                            width: 160,
                        }}>  <Avatar sx={{ width: 40, height: 40, bgcolor: red[900], marginLeft: "3rem" }} /><br></br>
                            <b>Customer Name</b> <br></br><span className='data_text'>{data.custId}</span></Item>
                    </Grid>
                    <Grid item xs={8}>
                        <Item style={{ boxShadow: "none" }}
                            sx={{
                                height: 140,
                                width: 160,
                                border: "none",
                            }}>Customer ID<br></br><span className='data_text'>{data.custId}</span></Item>
                    </Grid>
                    <Grid item xs={8}>
                        <Item style={{ boxShadow: "none" }}
                            sx={{
                                height: 140,
                                width: 160,
                            }}>Customer Name<br></br><span className='data_text'>{data.customerName}</span></Item>
                    </Grid>
                    <Grid item xs={8}>
                        <Item style={{ boxShadow: "none" }}
                            sx={{
                                height: 140,
                                width: 160,
                            }}>Mobile Number<br></br><span className='data_text'>{data.mobileNumber}</span></Item>
                    </Grid>
                    <Grid item xs={8}>
                        <Item style={{ boxShadow: "none" }}
                            sx={{
                                height: 140,
                                width: 160,
                            }}>Email Id<br></br><span className='data_text'>{data.email}</span></Item>
                    </Grid>
                    <Grid item xs={8}>
                        <Item style={{ boxShadow: "none" }}
                            sx={{
                                height: 140,
                                width: 160,
                            }}>Category<br></br><span className='data_text'>{data.category}</span></Item>
                    </Grid>

                </Grid> */}
                <SimpleDropDown
                    options={options}
                    value={selectedOption}
                    onChange={handleOptionChange}
                />
                <div className='search-input-box'>
                    <Input name={"search"} placeholder="Search Documents" inputProps={ariaLabel} onChange={(value, name) => setSearchText(value)} />

                </div>
            </div>

            <div className='sub-container'>
                {/* <div className='search-view'>
                    <div className='search-input-box'>
                        <Input name={"search"} placeholder="Search Documents" inputProps={ariaLabel} onChange={(value, name) => setSearchText(value)} />

                    </div>
                </div> */}
                <div className="container">
                    <div className='row'>
                        <div className='col-sm-2 side_nav_bar'>    <div className='tab-background-view'>
                            <ul className="nav">
                                <li className={`nav-item ${values.includes("FINNONE") ? "active" : ""}`}>
                                    <button
                                        className={`nav-link ${finnone === true && data.source === 'FINNONE' ? 'active' : ''}`}
                                        style={{ borderBottom: activeFinnone ? '#9D1D27' : "", color: activeFinnone ? "#9D1D27" : "" }}
                                        onClick={handleFinnOne}
                                    >
                                        FINNONE
                                    </button>
                                </li>
                                <li className={`nav-item ${values.includes("SFDC") ? "active" : ""}`}>
                                    <button
                                        className={`nav-link ${sfdc === true && data.source === 'SFDC' && activeSfdc === true ? 'active' : ''}`}
                                        style={{ borderBottom: activeSfdc ? '#9D1D27' : "", color: activeSfdc ? "#9D1D27" : "" }}
                                        onClick={handleSfdc}
                                    >
                                        SFDC
                                    </button>
                                </li>
                                <li className={`nav-item ${values.includes("TRADE FINANCE") ? "active" : ""}`}>
                                    <button
                                        className={`nav-link ${tradefin === true && data.source === 'TRADE FINANCE' ? 'active' : ''}`}
                                        style={{ borderBottom: activeTradefin ? '#9D1D27' : "", color: activeTradefin ? "#9D1D27" : "" }}
                                        onClick={handleTradeFinance}
                                    >
                                        TRADE FINANCE
                                    </button>
                                </li>
                                <li className={`nav-item ${values.includes("BPM") ? "active" : ""}`}>
                                    <button
                                        className={`nav-link ${bpm === true && data.source === 'BPM' ? 'active' : ''}`}
                                        style={{ borderBottom: activeBpm ? '#9D1D27' : "", color: activeBpm ? "#9D1D27" : "" }}
                                        onClick={handleBpm}
                                    >
                                        BPM
                                    </button>
                                </li>
                                <li className={`nav-item ${values.includes("EDP") ? "active" : ""}`}>
                                    <button
                                        className={`nav-link ${edp === true && data.source === 'EDP' ? 'active' : ''}`}
                                        style={{ borderBottom: activeEdp ? '#9D1D27' : "", color: activeEdp ? "#9D1D27" : "" }}
                                        onClick={handleEdp}
                                    >
                                        EDP
                                    </button>
                                </li>
                                <li className={`nav-item ${values.includes("ALL DOCUMENTS") ? "active" : ""}`}>
                                    <button
                                        className={`nav-link ${alldoc ? 'active' : ''}`}
                                        style={{ borderBottom: activeDoc ? '#9D1D27' : "", color: activeDoc ? "#9D1D27" : "" }}
                                        onClick={handleDoc}
                                    >
                                        ALL DOCUMENTS
                                    </button>                   
                                </li>
                            </ul>

                        </div></div>
                        <div className='col-sm-10'>

                            {(finnone === true && data.source === 'FINNONE') ?
                                (<div>
                                    <div className='export-button-view'>
                                        <div></div>
                                        {/* <button className='export-button-style' type="button">Export</button> */}

                                    </div>


                                    <div className='TableContainer' style={{ height: '300px', overflow: 'auto' }}>

                                        
                            <TableContainer sx={{ maxHeight: '300px' }} component={Paper}>
                                <Table stickyHeader aria-label='simple table'>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Document Type</TableCell>
                                            <TableCell >Document Name</TableCell>
                                            <TableCell >Document ID</TableCell>
                                            <TableCell >Document Password</TableCell>
                                            <TableCell >File Type</TableCell>
                                            <TableCell >Size</TableCell>
                                            <TableCell >No. of Pages</TableCell>
                                            <TableCell >Actions</TableCell>


                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {metaData.map((item, index) => (
                                            <TableRow
                                                key={index}
                                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                                <TableCell className='content-text'>{item.docType}</TableCell>
                                                <TableCell className='content-text'>{item.docName}</TableCell>
                                                <TableCell>{item.docId}</TableCell>
                                                <TableCell>{item.docPassword}</TableCell>
                                                <TableCell>{item.fileType}</TableCell>
                                                <TableCell>{item.size}</TableCell>
                                                <TableCell>{item.noOfPages}</TableCell>
                                                <TableCell><button className='button-stylee' type="button" >View</button></TableCell>


                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                                    </div>

                                    <div className='footer-view'>
                                        <div className='pagination-text-view'>
                                            <p className='content-text'>Items per page</p>
                                            <select className='pagination-dropdown' name="page" id="page">
                                                <option value="five">5</option>
                                                <option value="ten">10</option>
                                                <option value="fifteen">15</option>
                                                <option value="twenty">20</option>
                                            </select>
                                            <p className='vertical-line-text'>|</p>
                                            <p className='content-text'>1 - 5 of 5 Items</p>
                                        </div>
                                        <div className='pagination-button-view'>
                                            <p className='content-text'>Viewing page</p>
                                            <div className='page-number-box-view'>
                                                <p className='pagination-text'>1</p>
                                            </div>
                                            <p className='content-text'>Of 1 pages</p>
                                        </div>
                                    </div>
                                </div>
                                )
                                : (sfdc === true && data.source === 'SFDC') ?
                                    (<div>
                                          <div className='header_bottom'>
                                                        {/* <button className='export-button-style' type="button">Export</button> */}
                                                        <div className='d-flex flex-row'>
                                                            <h3>Documents </h3>
                                                            <p className='count'>{values.length}</p>
                                                        </div>
                                                        <div className='Dashboard_icon'><Dashboard /></div>

                                                    </div>

                                        <div className='TableContainer' style={{ height: '300px', overflow: 'auto' }}>

                                          
                            <TableContainer sx={{ maxHeight: '300px' }} component={Paper}>
                                <Table stickyHeader aria-label='simple table'>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Document Type</TableCell>
                                            <TableCell >Document Name</TableCell>
                                            <TableCell >Document ID</TableCell>
                                            <TableCell >Document Password</TableCell>
                                            <TableCell >File Type</TableCell>
                                            <TableCell >Size</TableCell>
                                            <TableCell >No. of Pages</TableCell>
                                            <TableCell >Actions</TableCell>


                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {metaData.map((item, index) => (
                                            <TableRow
                                                key={index}
                                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                                <TableCell className='content-text'>{item.docType}</TableCell>
                                                <TableCell className='content-text'>{item.docName}</TableCell>
                                                <TableCell>{item.docId}</TableCell>
                                                <TableCell>{item.docPassword}</TableCell>
                                                <TableCell>{item.fileType}</TableCell>
                                                <TableCell>{item.size}</TableCell>
                                                <TableCell>{item.noOfPages}</TableCell>
                                                <TableCell><button className='button-stylee' type="button" >View</button></TableCell>


                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>


                                        </div>

                                        <div className='footer-view'>
                                            <div className='pagination-text-view'>
                                                <p className='content-text'>Items per page</p>
                                                <select className='pagination-dropdown' name="page" id="page">
                                                    <option value="five">5</option>
                                                    <option value="ten">10</option>
                                                    <option value="fifteen">15</option>
                                                    <option value="twenty">20</option>
                                                </select>
                                                <p className='vertical-line-text'>|</p>
                                                <p className='content-text'>1 - 5 of 5 Items</p>
                                            </div>
                                            <div className='pagination-button-view'>
                                                <p className='content-text'>Viewing page</p>
                                                <div className='page-number-box-view'>
                                                    <p className='pagination-text'>1</p>
                                                </div>
                                                <p className='content-text'>Of 1 pages</p>
                                            </div>
                                        </div>
                                    </div>
                                    )
                                    : (tradefin === true && data.source === 'TRADE FINANCE') ?
                                        (<div>
                                             <div className='header_bottom'>
                                                        {/* <button className='export-button-style' type="button">Export</button> */}
                                                        <div className='d-flex flex-row'>
                                                            <h3>Documents </h3>
                                                            <p className='count'>{values.length}</p>
                                                        </div>
                                                        <div className='Dashboard_icon'><Dashboard /></div>

                                                    </div>

                                            <div className='TableContainer' style={{ height: '300px', overflow: 'auto' }}>

                                          
                            <TableContainer sx={{ maxHeight: '300px' }} component={Paper}>
                                <Table stickyHeader aria-label='simple table'>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Document Type</TableCell>    
                                            <TableCell >Document Name</TableCell>
                                            <TableCell >Document ID</TableCell>
                                            <TableCell >Document Password</TableCell>
                                            <TableCell >File Type</TableCell>
                                            <TableCell >Size</TableCell>
                                            <TableCell >No. of Pages</TableCell>
                                            <TableCell >Actions</TableCell>


                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {metaData.map((item, index) => (
                                            <TableRow
                                                key={index}
                                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                                <TableCell className='content-text'>{item.docType}</TableCell>
                                                <TableCell className='content-text'>{item.docName}</TableCell>
                                                <TableCell>{item.docId}</TableCell>
                                                <TableCell>{item.docPassword}</TableCell>
                                                <TableCell>{item.fileType}</TableCell>
                                                <TableCell>{item.size}</TableCell>
                                                <TableCell>{item.noOfPages}</TableCell>
                                                <TableCell><button className='button-stylee' type="button" >View</button></TableCell>


                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                                            </div>

                                            <div className='footer-view'>
                                                <div className='pagination-text-view'>
                                                    <p className='content-text'>Items per page</p>
                                                    <select className='pagination-dropdown' name="page" id="page">
                                                        <option value="five">5</option>
                                                        <option value="ten">10</option>
                                                        <option value="fifteen">15</option>
                                                        <option value="twenty">20</option>
                                                    </select>
                                                    <p className='vertical-line-text'>|</p>
                                                    <p className='content-text'>1 - 5 of 5 Items</p>
                                                </div>
                                                <div className='pagination-button-view'>
                                                    <p className='content-text'>Viewing page</p>
                                                    <div className='page-number-box-view'>
                                                        <p className='pagination-text'>1</p>
                                                    </div>
                                                    <p className='content-text'>Of 1 pages</p>
                                                </div>
                                            </div>
                                        </div>
                                        )
                                        : (bpm === true && data.source === 'BPM') ?
                                            (<div>
                                                 <div className='header_bottom'>
                                                        {/* <button className='export-button-style' type="button">Export</button> */}
                                                        <div className='d-flex flex-row'>
                                                            <h3>Documents </h3>
                                                            <p className='count'>{values.length}</p>
                                                        </div>
                                                        <div className='Dashboard_icon'><Dashboard /></div>

                                                    </div>


                                                <div className='TableContainer' style={{ height: '300px', overflow: 'auto' }}>

                                                
                            <TableContainer sx={{ maxHeight: '300px' }} component={Paper}>
                                <Table stickyHeader aria-label='simple table'>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Document Type</TableCell>
                                            <TableCell >Document Name</TableCell>
                                            <TableCell >Document ID</TableCell>
                                            <TableCell >Document Password</TableCell>
                                            <TableCell >File Type</TableCell>
                                            <TableCell >Size</TableCell>
                                            <TableCell >No. of Pages</TableCell>
                                            <TableCell >Actions</TableCell>


                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {metaData.map((item, index) => (
                                            <TableRow
                                                key={index}
                                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                                <TableCell className='content-text'>{item.docType}</TableCell>
                                                <TableCell className='content-text'>{item.docName}</TableCell>
                                                <TableCell>{item.docId}</TableCell>
                                                <TableCell>{item.docPassword}</TableCell>
                                                <TableCell>{item.fileType}</TableCell>
                                                <TableCell>{item.size}</TableCell>
                                                <TableCell>{item.noOfPages}</TableCell>
                                                <TableCell><button className='button-stylee' type="button" >View</button></TableCell>


                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                                                </div>

                                                <div className='footer-view'>
                                                    <div className='pagination-text-view'>
                                                        <p className='content-text'>Items per page</p>
                                                        <select className='pagination-dropdown' name="page" id="page">
                                                            <option value="five">5</option>
                                                            <option value="ten">10</option>
                                                            <option value="fifteen">15</option>
                                                            <option value="twenty">20</option>
                                                        </select>
                                                        <p className='vertical-line-text'>|</p>
                                                        <p className='content-text'>1 - 5 of 5 Items</p>
                                                    </div>
                                                    <div className='pagination-button-view'>
                                                        <p className='content-text'>Viewing page</p>
                                                        <div className='page-number-box-view'>
                                                            <p className='pagination-text'>1</p>
                                                        </div>
                                                        <p className='content-text'>Of 1 pages</p>
                                                    </div>
                                                </div>
                                            </div>
                                            )
                                            : (edp === true && data.source === 'EDP') ?
                                                (<div>
                                                    <div className='header_bottom'>
                                                        {/* <button className='export-button-style' type="button">Export</button> */}
                                                        <div className='d-flex flex-row'>
                                                            <h3>Documents </h3>
                                                            <p className='count'>{values.length}</p>
                                                        </div>
                                                        <div className='Dashboard_icon'><Dashboard /></div>

                                                    </div>


                                                    <div className='TableContainer' style={{ height: '300px', overflow: 'auto' }}>

                                                  
                            <TableContainer sx={{ maxHeight: '300px' }} component={Paper}>
                                <Table stickyHeader aria-label='simple table'>
                                    <TableHead>
                                        <TableRow>
                                            <TableCell>Document Type</TableCell>
                                            <TableCell >Document Name</TableCell>
                                            <TableCell >Document ID</TableCell>
                                            <TableCell >Document Password</TableCell>
                                            <TableCell >File Type</TableCell>
                                            <TableCell >Size</TableCell>
                                            <TableCell >No. of Pages</TableCell>
                                            <TableCell >Actions</TableCell>


                                        </TableRow>
                                    </TableHead>
                                    <TableBody>
                                        {metaData.map((item, index) => (
                                            <TableRow
                                                key={index}
                                                sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                                                <TableCell className='content-text'>{item.docType}</TableCell>
                                                <TableCell className='content-text'>{item.docName}</TableCell>
                                                <TableCell>{item.docId}</TableCell>
                                                <PasswordCell password={item.docPassword} />
                                                <TableCell>{item.fileType}</TableCell>
                                                <TableCell>{item.size}</TableCell>
                                                <TableCell>{item.noOfPages}</TableCell>
                                                <TableCell><ViewFile docId = {item.docId}/></TableCell>


                                            </TableRow>
                                        ))}
                                    </TableBody>
                                </Table>
                            </TableContainer>
                                                    </div>

                                                    <div className='footer-view'>
                                                        <div className='pagination-text-view'>
                                                            <p className='content-text'>Items per page</p>
                                                            <select className='pagination-dropdown' name="page" id="page">
                                                                <option value="five">5</option>
                                                                <option value="ten">10</option>
                                                                <option value="fifteen">15</option>
                                                                <option value="twenty">20</option>
                                                            </select>
                                                            <p className='vertical-line-text'>|</p>
                                                            <p className='content-text'>1 - 5 of 5 Items</p>
                                                        </div>
                                                        <div className='pagination-button-view'>
                                                            <p className='content-text'>Viewing page</p>
                                                            <div className='page-number-box-view'>
                                                                <p className='pagination-text'>1</p>
                                                            </div>
                                                            <p className='content-text'>Of 1 pages</p>
                                                        </div>
                                                    </div>
                                                </div>
                                                )
                                                : alldoc === true ? <AllDocuments docData={docData} />
                                                    : <div style={{ height: '300px', overflow: 'auto', display: 'flex', justifyContent: 'center', alignItems: 'center' }}> No Data to Show</div>

                            }

                        </div>
                    </div>

                </div>






            </div>

        </div>
    );
}

export default MetaDataDetailView;