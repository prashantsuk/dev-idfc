import React, { useEffect, useState} from 'react';
import axios from 'axios';
import './index.css';
import TextInput from "../TextInput";
import AllDocuments from '../AllDocument';
import DashboardIcon from '@mui/icons-material/Dashboard';
import IconButton from '@mui/material/IconButton';
import { red} from '@mui/material/colors';
import { fontWeight, textAlign } from '@mui/system';

const MetaDataDetailViews = ({metaData, data, productList, mapList}) => {
    // console.log(data, metaData);
    const[prodName, setProdName] = useState("");
    const [searchText, setSearchText] = useState("");
    const[finnone, setFinnone] = useState(true);
    const[sfdc, setSfdc] = useState(true);
    const[tradefin, setTradefin] = useState(true);
    const[edp, setEdp] = useState(true);
    const[bpm, setBpm] = useState(true);
    const[alldoc, setAlldoc] = useState(false);
    const[activeTradefin, setActiveTradeFin] = useState(false);
    const[activeEdp, setActiveEdp] = useState(false);
    const[activeSfdc, setActiveSfdc] = useState(false);
    const[activeFinnone, setActiveFinnone] = useState(false);
    const[activeDoc, setActiveDoc] = useState(false);
    const[activeBpm, setActiveBpm] = useState(false);
    const[docData, setDocData] = useState([]);
    const[show, setShow] = useState(false);

    // State to keep track of the selected option and the corresponding data
    const [selectedOption, setSelectedOption] = useState("");
    const [selectedData, setSelectedData] = useState([]);

    // Handler function to update the selected option and corresponding data
        const handleOptionChange = (e) => {
            const option = e.target.value;
            setSelectedOption(option);
            setSelectedData(mapList[option]);
            console.log(mapList[option]);
        };

    const options = Object.keys(mapList);

    const allDocUrl = `http://52.140.58.184:9414/msGetMetaData/getMetaData/allDocument?custId=${data.custId}`;

    useEffect( () =>{
      const fetchDocData = async() =>{
          const response = await axios.get(allDocUrl, {headers:{"Access-Control-Allow-Origin": "*"}})
        setDocData(response.data);
          console.log(response.data);
      }
      fetchDocData();
    
    },[])

 

    const handleFinnOne = () =>{
     
      setFinnone(true);
      setSfdc(false);
      setTradefin(false);
      setEdp(false);
      setBpm(false);
      setAlldoc(false);
      setActiveFinnone(true);
      setActiveSfdc(false);
      setActiveTradeFin(false);
      setActiveEdp(false);
      setActiveDoc(false);
      setActiveBpm(false);
    }
    const handleSfdc = () =>{
        setSfdc(true);
        setFinnone(false);
        setTradefin(false);
        setBpm(false);
        setEdp(false);
        setAlldoc(false);
        setActiveSfdc(true);
        setActiveFinnone(false);
        setActiveEdp(false);
        setActiveDoc(false);
        setActiveBpm(false);
        setActiveTradeFin(false);
    }
    const handleTradeFinance = () =>{
        setTradefin(true);
        setSfdc(false);
        setFinnone(false);
        setEdp(false);
        setBpm(false);
        setAlldoc(false);
        setActiveTradeFin(true);
        setActiveDoc(false);
        setActiveEdp(false);
        setActiveSfdc(false);
        setActiveBpm(false);
        setActiveFinnone(false);
    }
    const handleEdp = () =>{
        setEdp(true);
        setTradefin(false);
        setSfdc(false);
        setFinnone(false);
        setBpm(false);
        setAlldoc(false);
        setActiveEdp(true);
        setActiveTradeFin(false);
        setActiveDoc(false);
        setActiveSfdc(false);
        setActiveBpm(false);
        setActiveFinnone(false);
    }
    const handleDoc = () =>{
        setAlldoc(true);
        setEdp(false);
        setTradefin(false);
        setBpm(false);
        setSfdc(false);
        setFinnone(false);
        setActiveEdp(false);
        setActiveTradeFin(false);
        setActiveDoc(true);
        setActiveSfdc(false);
        setActiveFinnone(false);
        setActiveBpm(false);
    }
    const handleBpm = () =>{
        setBpm(true);
        setAlldoc(false);
        setEdp(false);
        setTradefin(false);
        setSfdc(false);
        setFinnone(false);
        setActiveEdp(false);
        setActiveBpm(true)
        setActiveTradeFin(false);
        setActiveDoc(false);
        setActiveSfdc(false);
        setActiveFinnone(false);
    }

    return (
        <div className='main-container'>

            <div className='header-view-detail'>
                {/* <div className="product-name-dropdown">
                    <select className="form-select shadow-none " id=""value = {prodName} onChange = {(e) => setProdName(e.target.value)}>
                
                    {
                        productList.map((type, id) =>{
                        return(
                            <option key = {id} value = {data.productName}>{type.productName}</option>
                        )
                        })
                    }
                    </select>
          
                </div> */}
                <div className="product-name-dropdown">
                    <select className="form-select shadow-none " id=""value = {selectedOption} onChange={handleOptionChange}>
                
                    {options.map((option, index) => (
                        <option key={index} value={option}>{option}</option>
                    ))}
                    </select>
          
                </div>
            <div className='search-view'>
                    <div></div>
                    <div className='search-input-box'>
                        <TextInput name={"search"} placeholder={"Search Documents"} onChange={(value, name) => setSearchText(value)} />
                    </div>
                </div>
                
            </div>

            <div className='sub-container'>
               

                <div className='tab-background-view'>
                    <ul className="nav">
                       
                            <li className="nav-item">
                            <button className= {`nav-link ${finnone === true && data.source === 'FINNONE' ? 'active' : ''}`} style ={{borderRight: activeFinnone ? '#9D1D27':"", color:activeFinnone ? "#9D1D27":"", textAlign:"left"}} onClick={handleFinnOne}>FINNONE</button>
                            </li>
                        
                            <li className="nav-item">
                             <button className= {`nav-link ${ sfdc === true && data.source === 'SFDC' && activeSfdc === true ? 'active' : ''}`} style ={{borderRight: activeSfdc ? '#9D1D27':"", color:activeSfdc ? "#9D1D27":"", textAlign:"left"}} onClick={handleSfdc}>SFDC</button>
                            </li>
                       
                            <li className="nav-item">
                            <button className={`nav-link ${ tradefin === true && data.source === 'TRADE FINANCE' ? 'active' : ''}`} style ={{borderBottom: activeTradefin ? '#9D1D27':"", color:activeTradefin ? "#9D1D27":"", textAlign:"left"}} onClick={handleTradeFinance}>TRADE FINANCE</button>
                            </li>
                      
                            <li className="nav-item">
                            <button className={`nav-link ${ bpm === true && data.source === 'BPM'? 'active' : ''}`} style ={{borderBottom: activeBpm ? '#9D1D27':"", color:activeBpm ? "#9D1D27":"", textAlign:"left"}} onClick={handleBpm}>BPM</button>
                            </li> 
                         
                            <li className="nav-item">
                            <button className= {`nav-link ${edp === true && data.source === 'EDP'? 'active' : ''}`} style ={{borderBottom: activeEdp ? '#9D1D27':"", color:activeEdp ? "#9D1D27":"", textAlign:"left"}} onClick={handleEdp}>EDP</button>
                            </li>
                                         
                            <li className="nav-item">
                            <button className= {`nav-link ${alldoc ? 'active' : ''}`} style ={{borderBottom: activeDoc ? '#9D1D27':"", color:activeDoc ? "#9D1D27":"", textAlign:"left"}} onClick={handleDoc}>ALL DOCUMENTS</button>
                           </li> 
                        
                    </ul>
                </div>
              
              <div className='tab-page'>
           
               { (finnone === true && data.source === 'FINNONE')?
                  ( <div>
                <div className='document-view'>
                    <div className='doc-no'>
                        <p style={{fontWeight:"bold"}}>Document <span className='doc-count'>4</span></p>
                    </div>
                    <IconButton> <DashboardIcon sx={{ width:20, height: 20, bgcolor: red[900]}}/></IconButton>
                </div>
                
             
               <div style={{height:'300px', overflow:'auto'}}>
               <table className="table">
                    <thead>
                        <tr>
                            <th>
                                <input className="form-check-input" type="checkbox" />
                            </th>
                            <th className='table-title-text' scope="col">Document Type</th>
                            <th className='table-title-text' scope="col">Document Name</th>
                            <th className='table-title-text' scope="col">Document ID</th>
                            <th className='table-title-text' scope="col">Document Password</th>
                            <th className='table-title-text' scope="col">File Type</th>
                            <th className='table-title-text' scope="col">Size</th>
                            <th className='table-title-text' scope="col">No. of Pages</th>
                            <th className='table-title-text' scope="col">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                    { 
               metaData.map((item, index) =>{ 
               return(
                    <tr key = {index}>
                         <td>
                                <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                            </td>
                        <td className='content-text'>{item.docType}</td>
                        <td className='content-text'>{item.docName}</td>
                        <td>{item.docId}</td>
                        <td>{item.docPassword}</td>
                        <td>{item.fileType}</td>
                        <td>{item.size}</td>
                        <td>{item.noOfPages}</td>
                        <td><button className='button-stylee' type="button" >View</button></td>
                    </tr>
                )
               }) 
            }        
                    </tbody>
                </table> 
                 </div>   

                <div className='footer-view'>
                    <div className='pagination-text-view'>
                        <p className='content-text'>Items per page</p>
                        <select className='pagination-dropdown' name="page" id="page">
                            <option value="five">5</option>
                            <option value="ten">10</option>
                            <option value="fifteen">15</option>
                            <option value="twenty">20</option>
                        </select>
                        <p className='vertical-line-text'>|</p>
                        <p className='content-text'>1 - 5 of 5 Items</p>
                    </div>
                    <div className='pagination-button-view'>
                        <p className='content-text'>Viewing page</p>
                        <div className='page-number-box-view'>
                            <p className='pagination-text'>1</p>
                        </div>
                        <p className='content-text'>Of 1 pages</p>
                    </div>
                </div>
                </div> 
              ) 
                  : (sfdc===true && data.source === 'SFDC') ?
                  ( <div>
                    <div className='document-view'>
                    <div className='doc-no'>
                        <p style={{fontWeight:"bold"}}>Document <span className='doc-count'>4</span></p>
                    </div>
                    <IconButton> <DashboardIcon sx={{ width:20, height: 20, bgcolor: red[900]}}/></IconButton>
                   </div>
                    
                 
                   <div style={{height:'300px', overflow:'auto'}}>
                   <table className="table">
                        <thead>
                            <tr>
                                <th>
                                    <input className="form-check-input" type="checkbox" />
                                </th>
                                <th className='table-title-text' scope="col">Document Type</th>
                                <th className='table-title-text' scope="col">Document Name</th>
                                <th className='table-title-text' scope="col">Document ID</th>
                                <th className='table-title-text' scope="col">Document Password</th>
                                <th className='table-title-text' scope="col">File Type</th>
                                <th className='table-title-text' scope="col">Size</th>
                                <th className='table-title-text' scope="col">No. of Pages</th>
                                <th className='table-title-text' scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        { 
                 metaData.map((item, index) =>{ 
                   return(
                        <tr key = {index}>
                             <td>
                                    <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                </td>
                            <td className='content-text'>{item.docType}</td>
                            <td className='content-text'>{item.docName}</td>
                            <td>{item.docId}</td>
                            <td>{item.docPassword}</td>
                            <td>{item.fileType}</td>
                            <td>{item.size}</td>
                            <td>{item.noOfPages}</td>
                            <td><button className='button-stylee' type="button" >View</button></td>
                        </tr>
                    )
                   }) 
                }        
                        </tbody>
                    </table> 
                     </div>   
    
                    <div className='footer-view'>
                        <div className='pagination-text-view'>
                            <p className='content-text'>Items per page</p>
                            <select className='pagination-dropdown' name="page" id="page">
                                <option value="five">5</option>
                                <option value="ten">10</option>
                                <option value="fifteen">15</option>
                                <option value="twenty">20</option>
                            </select>
                            <p className='vertical-line-text'>|</p>
                            <p className='content-text'>1 - 5 of 5 Items</p>
                        </div>
                        <div className='pagination-button-view'>
                            <p className='content-text'>Viewing page</p>
                            <div className='page-number-box-view'>
                                <p className='pagination-text'>1</p>
                            </div>
                            <p className='content-text'>Of 1 pages</p>
                        </div>
                    </div>
                    </div>
                      )
                  : ( tradefin === true && data.source === 'TRADE FINANCE')? 
                  ( <div>
                    <div className='document-view'>
                    <div className='doc-no'>
                        <p style={{fontWeight:"bold"}}>Document <span className='doc-count'>4</span></p>
                    </div>
                    <IconButton> <DashboardIcon sx={{ width:20, height: 20, bgcolor: red[900]}}/></IconButton>
                   </div>
                    
                 
                   <div style={{height:'300px', overflow:'auto'}}>
                   <table className="table">
                        <thead>
                            <tr>
                                <th>
                                    <input className="form-check-input" type="checkbox" />
                                </th>
                                <th className='table-title-text' scope="col">Document Type</th>
                                <th className='table-title-text' scope="col">Document Name</th>
                                <th className='table-title-text' scope="col">Document ID</th>
                                <th className='table-title-text' scope="col">Document Password</th>
                                <th className='table-title-text' scope="col">File Type</th>
                                <th className='table-title-text' scope="col">Size</th>
                                <th className='table-title-text' scope="col">No. of Pages</th>
                                <th className='table-title-text' scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        {
                  metaData.map((item, index) =>{
                    return(
                        <tr key = {index}>
                             <td>
                                    <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                </td>
                            <td className='content-text'>{item.docType}</td>
                            <td className='content-text'>{item.docName}</td>
                            <td>{item.docId}</td>
                            <td>{item.docPassword}</td>
                            <td>{item.fileType}</td>
                            <td>{item.size}</td>
                            <td>{item.noOfPages}</td>
                            <td><button className='button-stylee' type="button" >View</button></td>
                        </tr>
                    )
                   }) 
                }        
                        </tbody>
                    </table>
                    </div>   
    
                    <div className='footer-view'>
                        <div className='pagination-text-view'>
                            <p className='content-text'>Items per page</p>
                            <select className='pagination-dropdown' name="page" id="page">
                                <option value="five">5</option>
                                <option value="ten">10</option>
                                <option value="fifteen">15</option>
                                <option value="twenty">20</option>
                            </select>
                            <p className='vertical-line-text'>|</p>
                            <p className='content-text'>1 - 5 of 5 Items</p>
                        </div>
                        <div className='pagination-button-view'>
                            <p className='content-text'>Viewing page</p>
                            <div className='page-number-box-view'>
                                <p className='pagination-text'>1</p>
                            </div>
                            <p className='content-text'>Of 1 pages</p>
                        </div>
                    </div>
                    </div>
                    )
                 : ( bpm === true && data.source === 'BPM') ? 
                   ( <div>
                    <div className='document-view'>
                    <div className='doc-no'>
                        <p style={{fontWeight:"bold"}}>Document <span className='doc-count'>4</span></p>
                    </div>
                    <IconButton> <DashboardIcon sx={{ width:20, height: 20, bgcolor: red[900]}}/></IconButton>
                </div>
                    
                 
                   <div style={{height:'300px', overflow:'auto'}}>
                   <table className="table">
                        <thead>
                            <tr>
                                <th>
                                    <input className="form-check-input" type="checkbox" />
                                </th>
                                <th className='table-title-text' scope="col">Document Type</th>
                                <th className='table-title-text' scope="col">Document Name</th>
                                <th className='table-title-text' scope="col">Document ID</th>
                                <th className='table-title-text' scope="col">Document Password</th>
                                <th className='table-title-text' scope="col">File Type</th>
                                <th className='table-title-text' scope="col">Size</th>
                                <th className='table-title-text' scope="col">No. of Pages</th>
                                <th className='table-title-text' scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        {
                  metaData.map((item, index) =>{
                    return(
                        <tr key = {index}>
                             <td>
                                    <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                </td>
                            <td className='content-text'>{item.docType}</td>
                            <td className='content-text'>{item.docName}</td>
                            <td>{item.docId}</td>
                            <td>{item.docPassword}</td>
                            <td>{item.fileType}</td>
                            <td>{item.size}</td>
                            <td>{item.noOfPages}</td>
                            <td><button className='button-stylee' type="button" >View</button></td>
                        </tr>
                    )
                   }) 
                }        
                        </tbody>
                    </table>
                    </div>   
    
                    <div className='footer-view'>
                        <div className='pagination-text-view'>
                            <p className='content-text'>Items per page</p>
                            <select className='pagination-dropdown' name="page" id="page">
                                <option value="five">5</option>
                                <option value="ten">10</option>
                                <option value="fifteen">15</option>
                                <option value="twenty">20</option>
                            </select>
                            <p className='vertical-line-text'>|</p>
                            <p className='content-text'>1 - 5 of 5 Items</p>
                        </div>
                        <div className='pagination-button-view'>
                            <p className='content-text'>Viewing page</p>
                            <div className='page-number-box-view'>
                                <p className='pagination-text'>1</p>
                            </div>
                            <p className='content-text'>Of 1 pages</p>
                        </div>
                    </div>
                    </div>
                    )
                  : ( edp === true && data.source === 'EDP') ?
                  ( <div>
                   <div className='document-view'>
                    <div className='doc-no'>
                        <p style={{fontWeight:"bold"}}>Document <span className='doc-count'>4</span></p>
                    </div>
                    <IconButton> <DashboardIcon sx={{ width:20, height: 20, bgcolor: red[900]}}/></IconButton>
                </div>
                    
                 
                   <div style={{height:'300px', overflow:'auto'}}>
                   <table className="table">
                        <thead>
                            <tr>
                                <th>
                                    <input className="form-check-input" type="checkbox" />
                                </th>
                                <th className='table-title-text' scope="col">Document Type</th>
                                <th className='table-title-text' scope="col">Document Name</th>
                                <th className='table-title-text' scope="col">Document ID</th>
                                <th className='table-title-text' scope="col">Document Password</th>
                                <th className='table-title-text' scope="col">File Type</th>
                                <th className='table-title-text' scope="col">Size</th>
                                <th className='table-title-text' scope="col">No. of Pages</th>
                                <th className='table-title-text' scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                        {
                  metaData.map((item, index) =>{
                    return(
                        <tr key = {index}>
                             <td>
                                    <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" />
                                </td>
                            <td className='content-text'>{item.docType}</td>
                            <td className='content-text'>{item.docName}</td>
                            <td>{item.docId}</td>
                            <td>{item.docPassword}</td>
                            <td>{item.fileType}</td>
                            <td>{item.size}</td>
                            <td>{item.noOfPages}</td>
                            <td><button className='button-stylee' type="button" >View</button></td>
                        </tr>
                    )
                   }) 
                }        
                        </tbody>
                    </table>
                    </div>   
    
                    <div className='footer-view'>
                        <div className='pagination-text-view'>
                            <p className='content-text'>Items per page</p>
                            <select className='pagination-dropdown' name="page" id="page">
                                <option value="five">5</option>
                                <option value="ten">10</option>
                                <option value="fifteen">15</option>
                                <option value="twenty">20</option>
                            </select>
                            <p className='vertical-line-text'>|</p>
                            <p className='content-text'>1 - 5 of 5 Items</p>
                        </div>
                        <div className='pagination-button-view'>
                            <p className='content-text'>Viewing page</p>
                            <div className='page-number-box-view'>
                                <p className='pagination-text'>1</p>
                            </div>
                            <p className='content-text'>Of 1 pages</p>
                        </div>
                    </div>
                    </div>
                      )
                   : alldoc === true ? <AllDocuments docData = {docData}/> 
                  : <div style={{height:'300px', overflow:'auto', display:'flex', justifyContent:'center', alignItems:'center'}}> No Data to Show</div>
              
              } 
          
            </div>

   
            </div>
           
        </div>
    );
}

export default MetaDataDetailViews;