import React, { useState, useEffect, atob} from 'react';

import axios from 'axios';

function ViewFile({docId}) {
  const [fileData, setFileData] = useState(null);
  const [fileType, setFileType] = useState(null);
  const[data, setData] = useState([]);
  const viewUrl = `http://52.140.58.184:9414/msLiabilitiesAddDocument/viewDoc?docIndx=${docId}&tableType=Main`

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(viewUrl);
        setData(response.data.msgBdy);
        console.log(response.data.msgBdy);
        setFileData(response.data.msgBdy.bs64Doc);
        setFileType(response.data.msgBdy.fileType);
      } catch (error) {
        console.log(error);
      }
    };
    fetchData();
  }, []);

  const viewFile = () => {
    console.log('function is called');
    const binary = window.atob(fileData);
    const array = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      array[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([array], { type: fileType });
    // const blob = new Blob([atob(fileData.split(',')[1])], { type: fileType });

    const url = URL.createObjectURL(blob);
    window.open(url);
   
  };

  return (
    <div>

      {fileData && fileType &&
      <button className='button-stylee' type="button" onClick={viewFile} >View</button>
      }
    </div>
  );
}

export default ViewFile;

// import axios from "axios";
// import { useState } from "react";

// function ViewFile({ docId }) {
//   const [fileData, setFileData] = useState(null);
//   const [fileType, setFileType] = useState(null);
//   const [zoom, setZoom] = useState(1);

//   const viewUrl = `http://52.140.58.184:9414/msLiabilitiesAddDocument/viewDoc?docIndx=${docId}&tableType=Main`;

//   const fetchData = async () => {
//     try {
//       const response = await axios.get(viewUrl);
//       setFileData(response.data.msgBdy.bs64Doc);
//       setFileType(response.data.msgBdy.fileType);
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   const viewFile = () => {
//     fetchData();
//   };

//   const handleZoomIn = () => {
//     setZoom(zoom + 0.1);
//   };

//   const handleZoomOut = () => {
//     setZoom(zoom - 0.1);
//   };

//   return (
//     <div>
//       {fileData && fileType && (
//         <div>
//           <object
//             data={`data:${fileType};base64,${fileData}`}
//             type={fileType}
//             style={{ transform: `scale(${zoom})` }}
//           >
//             <p>Sorry, your browser doesn't support embedded videos.</p>
//           </object>
//           <div>
//             <button type="button" onClick={handleZoomIn}>
//               Zoom In
//             </button>
//             <button type="button" onClick={handleZoomOut}>
//               Zoom Out
//             </button>
//           </div>
//         </div>
//       )}

//       <button className="button-stylee" type="button" onClick={viewFile}>
//         View
//       </button>
//     </div>
//   );
// }

// export default ViewFile;

// import axios from "axios";
// import { useState } from "react";
// import { Modal, Button } from "react-bootstrap";

// function ViewFile({ docId }) {
//   const [fileData, setFileData] = useState(null);
//   const [fileType, setFileType] = useState(null);
//   const [zoom, setZoom] = useState(1);
//   const [showModal, setShowModal] = useState(false);

//   const viewUrl = `http://52.140.58.184:9414/msLiabilitiesAddDocument/viewDoc?docIndx=${docId}&tableType=Main`;

//   const fetchData = async () => {
//     try {
//       const response = await axios.get(viewUrl);
//       setFileData(response.data.msgBdy.bs64Doc);
//       setFileType(response.data.msgBdy.fileType);
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   const viewFile = () => {
//     setShowModal(true);
//     fetchData();
//   };

//   const handleZoomIn = () => {
//     setZoom(zoom + 0.1);
//   };

//   const handleZoomOut = () => {
//     setZoom(zoom - 0.1);
//   };

//   const handleCloseModal = () => {
//     setShowModal(false);
//   };

//   return (
//     <div>
//       <Button className="button-stylee" type="button" onClick={viewFile}>
//         View
//       </Button>

//       <Modal show={showModal} onHide={handleCloseModal} size="lg">
//         <Modal.Header closeButton>
//           <Modal.Title>File Preview</Modal.Title>
//         </Modal.Header>
//         <Modal.Body>
//           {fileData && fileType && (
//             <div>
//               <iframe
//                 src={`data:${fileType};base64,${fileData}`}
//                 style={{ transform: `scale(${zoom})` }}
//               />
//               <div>
//                 <button type="button" onClick={handleZoomIn}>
//                   Zoom In
//                 </button>
//                 <button type="button" onClick={handleZoomOut}>
//                   Zoom Out
//                 </button>
//               </div>
//             </div>
//           )}
//         </Modal.Body>
//         <Modal.Footer>
//           <Button variant="secondary" onClick={handleCloseModal}>
//             Close
//           </Button>
//         </Modal.Footer>
//       </Modal>
//     </div>
//   );
// }

// export default ViewFile;

// import axios from "axios";
// import { useState } from "react";
// import { Dialog, IconButton } from "@material-ui/core";
// import { Close as CloseIcon, ZoomIn as ZoomInIcon, ZoomOut as ZoomOutIcon } from "@material-ui/icons";

// function ViewFile({ docId }) {
//   const [fileData, setFileData] = useState(null);
//   const [fileType, setFileType] = useState(null);
//   const [zoom, setZoom] = useState(1);
//   const [showModal, setShowModal] = useState(false);

//   const viewUrl = `http://52.140.58.184:9414/msLiabilitiesAddDocument/viewDoc?docIndx=${docId}&tableType=Main`;

//   const fetchData = async () => {
//     try {
//       const response = await axios.get(viewUrl);
//       setFileData(response.data.msgBdy.bs64Doc);
//       setFileType(response.data.msgBdy.fileType);
//     } catch (error) {
//       console.log(error);
//     }
//   };

//   const viewFile = () => {
//     setShowModal(true);
//     fetchData();
//   };

//   const handleZoomIn = () => {
//     setZoom(zoom + 0.1);
//   };

//   const handleZoomOut = () => {
//     setZoom(zoom - 0.1);
//   };

//   const handleCloseModal = () => {
//     setShowModal(false);
//   };

//   return (
//     <div>
//       <IconButton className="button-stylee" onClick={viewFile}>
//         View
//       </IconButton>

//       <Dialog open={showModal} onClose={handleCloseModal} maxWidth="lg">
//         <div style={{ position: "relative", overflow: "hidden" }}>
//           <IconButton
//             style={{ position: "absolute", top: 0, right: 0 }}
//             onClick={handleCloseModal}
//           >
//             <CloseIcon />
//           </IconButton>
//           {fileData && fileType && (
//             <div>
//               <iframe
//                 src={`data:${fileType};base64,${fileData}`}
//                 style={{ transform: `scale(${zoom})` }}
//               />
//               <div>
//                 <IconButton onClick={handleZoomIn}>
//                   <ZoomInIcon />
//                 </IconButton>
//                 <IconButton onClick={handleZoomOut}>
//                   <ZoomOutIcon />
//                 </IconButton>
//               </div>
//             </div>
//           )}
//         </div>
//       </Dialog>
//     </div>
//   );
// }

// export default ViewFile;
