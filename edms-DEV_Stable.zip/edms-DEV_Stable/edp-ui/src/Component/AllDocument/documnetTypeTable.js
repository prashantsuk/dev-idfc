import React from 'react';
import './index.css';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Button from '@mui/material/Button';
import NorthIcon from '@mui/icons-material/North';
// import papa from 'papa';


const DocumnetTypeTable = ({docData}) => {
    console.log(docData);
    // const handleExport = (docData) => {
    //     const csv = papa.unparse(docData);
    //     const file = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    //     const link = document.createElement('a');
    //     link.href = URL.createObjectURL(file);
    //     link.setAttribute('download', 'metadata.csv');
    //     document.body.appendChild(link);
    //     link.click();
    //   };
      

    return (
        <TableContainer>
            <Table>
                <TableHead>
                <TableRow>
                    <TableCell className="table-cell" align="center">Document Type</TableCell>
                    <TableCell className="table-cell" align="center">Document Name</TableCell>
                    <TableCell className="table-cell" align="center">FIle Type</TableCell>
                    <TableCell className="table-cell" align="center">FIle Name</TableCell>
                    <TableCell className="table-cell" align="center">Size</TableCell>
                    <TableCell className="table-cell" align="center">Actions</TableCell>
                </TableRow>
                </TableHead>
                <TableBody>
        
                  
               {    
               docData.map((data, index) =>{
                  return(
                    <TableRow key = {index} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>
                    <TableCell className="table-cell" align="center">{data.docType}</TableCell>
                    <TableCell className="table-cell" align="center">{data.docName}</TableCell>
                    <TableCell className="table-cell" align="center">{data.fileType}</TableCell>
                    <TableCell className="table-cell" align="center">{data.fileName}</TableCell>
                    <TableCell className="table-cell" align="center">{data.actualFileSize}</TableCell>
                    <TableCell className="table-cell tab-btn" align="center">
                        <Button
                            variant="outlined"
                            size='small'
                            className='table-btn'
                            style={{marginRight: '5px'}}
                        > View
                        </Button>
                   
                    </TableCell>
                </TableRow>
                  )
           })  
                   
}
                </TableBody>
            </Table>
        </TableContainer>
    );
}

export default DocumnetTypeTable;