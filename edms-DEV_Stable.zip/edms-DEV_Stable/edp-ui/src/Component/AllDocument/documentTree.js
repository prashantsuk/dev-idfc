import React, {useEffect, useState} from 'react';
import './index.css';
import TreeView from '@mui/lab/TreeView';
import TreeItem from '@mui/lab/TreeItem';
import './CollapseIcon.png';
import expIcon from  './ExpandIcon.png';



const DocumentTree = ({docData}) => {
    const [dataWithTreeList, setDataWithTreeList] = useState(null);
    
    const createTreeToDocClass = (data) => {
        let tempData = {};
        let tempTreeList = [];
        let tempAssetsList = [];
        let tempLiabilitiesList = [];
        let tempSourceDataList = [];
        tempData.idfcedp = data[0].docClass.split('/')[0];
        tempData.customerId = data[0].docClass.split('/')[1];
        data.forEach(element => {
            let tempDocClassArr = element.docClass.split('/');
            if(tempDocClassArr[2].toLowerCase() === 'assets') {
                if (tempDocClassArr[3].toLowerCase() === 'finnone') {
                    tempSourceDataList.push({
                        type: 'Assets',
                        source: 'FINNONE',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if(tempDocClassArr[3].toLowerCase() === 'sfdc') {
                    tempSourceDataList.push({
                        type: 'Assets',
                        source: 'SFDC',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if (tempDocClassArr[3].toLowerCase() === 'trade finance') {
                    tempSourceDataList.push({
                        type: 'Assets',
                        source: 'TRADE FINANCE',
                        edpId: element.edpId,
                        productName: element.productName,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if (tempDocClassArr[3].toLowerCase() === 'edp') {
                    tempSourceDataList.push({
                        type: 'Assets',
                        source: 'EDP',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if (tempDocClassArr[3].toLowerCase() === 'bpm') {
                    tempSourceDataList.push({
                        type: 'Assets',
                        source: 'BPM',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                } 
            }

            if(tempDocClassArr[2].toLowerCase() === 'liabilities') {
                if (tempDocClassArr[3].toLowerCase() === 'finnone') {
                    tempSourceDataList.push({
                        type: 'Liabilities',
                        source: 'FINNONE',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if(tempDocClassArr[3].toLowerCase() === 'sfdc') {
                    tempSourceDataList.push({
                        type: 'Liabilities',
                        source: 'SFDC',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if (tempDocClassArr[3].toLowerCase() === 'trade finance') {
                    tempSourceDataList.push({
                        type: 'Liabilities',
                        source: 'TRADE FINANCE',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if (tempDocClassArr[3].toLowerCase() === 'edp') {
                    tempSourceDataList.push({
                        type: 'Liabilities',
                        source: 'EDP',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                }
                else if (tempDocClassArr[3].toLowerCase() === 'bpm') {
                    tempSourceDataList.push({
                        type: 'Liabilities',
                        source: 'BPM',
                        productName: element.productName,
                        edpId: element.edpId,
                        docTitle: element.docTitle,
                        docType: element.docType,
                        docName: element.docName,
                        customerName: element.customerName,
                        actualFileSize: element.actualFileSize,
                        compressFileSize: element.compressFileSize,
                        fileType: element.fileType,
                        noOfPages: element.noOfPages,
                        mobileNumber: element.mobileNumber,
                        fileName: element.fileName,
                        size: element.size
                    })
                } 
            }
            
            // tempData.treeViewList(tempTreeObj);    
        });
        let filteredAssetsArray = tempSourceDataList.filter((itm) => {
            return itm.type.toLowerCase() === 'assets';
        });
        let filteredLiabilitiesArray = tempSourceDataList.filter((itm) => {
            return itm.type.toLowerCase() === 'liabilities';
        });
        
        if(filteredAssetsArray.length > 0) {
            let filteredFINNONEArray = filteredAssetsArray.filter((itm) => {
                return itm.source.toLowerCase() === 'finnone';
            });
            let filteredSFDCArray = filteredAssetsArray.filter((itm) => {
                return itm.source.toLowerCase() === 'sfdc';
            });
            let filteredTRADEFINANCEArray = filteredAssetsArray.filter((itm) => {
                return itm.source.toLowerCase() === 'trade finance';
            });
            let filteredEDPArray = filteredAssetsArray.filter((itm) => {
                return itm.source.toLowerCase() === 'edp';
            });
            let filteredBPMArray = filteredAssetsArray.filter((itm) => {
                return itm.source.toLowerCase() === 'bpm';
            });
            if(filteredFINNONEArray.length > 0) {
                tempAssetsList.push({
                    source: 'FINNONE',
                    sourceDataList: filteredFINNONEArray
                });
            }
            if(filteredSFDCArray.length > 0) {
                tempAssetsList.push({
                    source: 'SFDC',
                    sourceDataList: filteredSFDCArray
                });
            }
            if(filteredTRADEFINANCEArray.length > 0) {
                tempAssetsList.push({
                    source: 'TRADE FINANCE',
                    sourceDataList: filteredTRADEFINANCEArray
                });
            }
            if(filteredEDPArray.length > 0) {
                tempAssetsList.push({
                    source: 'EDP',
                    sourceDataList: filteredEDPArray
                });
            }
            if(filteredBPMArray.length > 0) {
                tempAssetsList.push({
                    source: 'BPM',
                    sourceDataList: filteredBPMArray
                });
            }

            if(tempAssetsList.length > 0) {
                tempTreeList.push({
                    type: 'Assets',
                    sourceList: tempAssetsList
                });
            }
        }

        if(filteredLiabilitiesArray.length > 0) {
            let filteredFINNONEArray = filteredLiabilitiesArray.filter((itm) => {
                return itm.source.toLowerCase() === 'finnone';
            });
            let filteredSFDCArray = filteredLiabilitiesArray.filter((itm) => {
                return itm.source.toLowerCase() === 'sfdc';
            });
            let filteredTRADEFINANCEArray = filteredLiabilitiesArray.filter((itm) => {
                return itm.source.toLowerCase() === 'trade finance';
            });
            let filteredEDPArray = filteredLiabilitiesArray.filter((itm) => {
                return itm.source.toLowerCase() === 'edp';
            });
            let filteredBPMArray = filteredLiabilitiesArray.filter((itm) => {
                return itm.source.toLowerCase() === 'bpm';
            });
            if(filteredFINNONEArray.length > 0) {
                tempLiabilitiesList.push({
                    source: 'FINNONE',
                    sourceDataList: filteredFINNONEArray
                });
            }
            if(filteredSFDCArray.length > 0) {
                tempLiabilitiesList.push({
                    source: 'SFDC',
                    sourceDataList: filteredSFDCArray
                });
            }
            if(filteredTRADEFINANCEArray.length > 0) {
                tempLiabilitiesList.push({
                    source: 'TRADE FINANCE',
                    sourceDataList: filteredTRADEFINANCEArray
                });
            }
            if(filteredEDPArray.length > 0) {
                tempLiabilitiesList.push({
                    source: 'EDP',
                    sourceDataList: filteredEDPArray
                });
            }
            if(filteredBPMArray.length > 0) {
                tempLiabilitiesList.push({
                    source: 'BPM',
                    sourceDataList: filteredEDPArray
                });
            }
            
            if(tempLiabilitiesList.length > 0) {
                tempTreeList.push({
                    type: 'Liabilities',
                    sourceList: tempLiabilitiesList
                });
            }
        }
        tempData.treeList = tempTreeList;
        setDataWithTreeList(tempData);
    }
   
   
    useEffect(() =>{
        createTreeToDocClass(docData);
    }, []);

    return (
        <>
        {dataWithTreeList &&
            <TreeView
                defaultCollapseIcon={
                    <img
                        className='tree-view-icon'
                        src="./CollapseIcon.png"
                        alt='Collapse Icon'
                    />
                }
                defaultExpandIcon={
                    <img
                        className='tree-view-icon'
                        src={expIcon}
                        alt='Expand Icon'
                    />
                }
                sx={{
                    height: '100%',
                    flexGrow: 1,
                    maxWidth: 400,
                    overflowY: 'auto'
                }}
            >
                <TreeItem nodeId="1" label="IDFC EDP">
               
                    <TreeItem nodeId="2" label={dataWithTreeList.customerId}>
                        {dataWithTreeList.treeList.length > 0 &&
                        dataWithTreeList.treeList.map((item, index) => {
                            return (
                              
                                    <TreeItem nodeId={"treeList"+index} label={item.type}> 
                                       {item.sourceList.length > 0 &&
                                         item.sourceList.map((item, index) => {
                                        return (
                                            <TreeItem nodeId={'sourceList'+index} label={item.source}>
                                                {item.sourceDataList.length > 0 &&
                                                item.sourceDataList.map((item, index) => {
                                                    return (
                                                        <TreeItem nodeId={'sourceDataList'+index} label={item.docType}>
                                                            <TreeItem nodeId={'docName'+index} label={item.docName}>
                                                                <TreeItem nodeId={'fileName'+index} label={item.fileName} />
                                                            </TreeItem>
                                                        </TreeItem>
                                                    )
                                                })}
                                            </TreeItem>
                                           
                                        )
                                    })}
                                   
                                </TreeItem>
                            )
                        })}
                    </TreeItem>
                  
                </TreeItem>
                {/* <TreeItem nodeId="1" label="IDFC EDP">
                    <TreeItem nodeId="2" label={dataWithTreeList.customerId}>
                        {dataWithTreeList.treeList.length > 0 &&
                        dataWithTreeList.treeList.map((item, index) => {
                            const docNamesByType = item.sourceList.reduce((acc, source) => {
                            source.sourceDataList.forEach(sourceData => {
                                const { docName, docType } = sourceData;
                                if (!acc[docType]) {
                                acc[docType] = [];
                                }
                                acc[docType].push(docName);
                            });
                            return acc;
                            }, {});

                            return (
                            <TreeItem nodeId={"treeList"+index} label={item.type}>
                                {Object.entries(docNamesByType).map(([docType, docNames,i]) => (
                                <TreeItem key ={i} nodeId={`docType-${docType}`} label={docType}>
                                    {docNames.map((docName, index) => (
                                    <TreeItem nodeId={`docName-${docType}-${index}`} label={docName}>
                                        <TreeItem nodeId={`fileName-${docType}-${index}`} label={item.fileName} />
                                    </TreeItem>
                                    ))}
                                </TreeItem>
                                ))}
                            </TreeItem>
                            );
                        })}
                    </TreeItem>
               </TreeItem> */}

            </TreeView>
        }
       </> 
    );
}

export default DocumentTree;