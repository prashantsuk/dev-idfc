import React , {useState} from 'react';
import './index.css';
import Grid from '@mui/material/Grid';
import DocumentTrees from './documentTrees';
import DocumnetTypeTable from './documnetTypeTable';
const AllDocuments = ({docData}) => {
    function createTree(docs) {
        const tree = {};
        
        for (let doc of docs) {
          const path = doc.docClass.split('/');
          let currentNode = tree;
          for (let i = 0; i < path.length; i++) {
            const segment = path[i];
            if (!currentNode[segment]) {
              currentNode[segment] = {};
            }
            currentNode = currentNode[segment];
          }
        }
        return tree;
      }
    const treeData = createTree(docData);
    function Tree({ data, depth = 0 }) {
      const [isExpanded, setIsExpanded] = useState(false);
    
      function handleToggle() {
        setIsExpanded(!isExpanded);
      }
    
      if (!isExpanded) {
        return (
          <div className="Tree-node" style={{ paddingLeft: depth * 20 }} onClick={handleToggle}>
            <span><img
                    className='tree-view-icon'
                    src="./ExpandIcon.png"
                    alt='Expand Icon'
                /></span>
            {Object.keys(data)}
          </div>
        );
      }
    
      return (
        <div>
          <div className="Tree-node" style={{ paddingLeft: depth * 20 }} onClick={handleToggle}>
            <span> <img
                    className='tree-view-icon'
                    src="./CollapseIcon.png"
                    alt='Collapse Icon'
                /> </span>
            {Object.keys(data)}
          </div>
          {Object.entries(data).map(([key, value]) => (
            <div key={key}>
              <div className="Tree-node" style={{ paddingLeft: (depth + 1) * 20 }}>
                {/* {key} */}
              </div>
              {typeof value === 'object' ? <Tree data={value} depth={depth + 1} /> : null}
            </div>
          ))}
        </div>
      );
    }

    return (
        <>
            <Grid container spacing={0} className='all-document-container'>
                <Grid item xs={3} className='left-container'>
                    {/* <DocumentTrees docData = {treeData}/> */}
                    <Tree data={treeData} />
                </Grid>
                <Grid item xs={9} className='right-container'>
                    <DocumnetTypeTable  docData = {docData}/>
                </Grid>
            </Grid>
        </>
    );
}

export default AllDocuments;