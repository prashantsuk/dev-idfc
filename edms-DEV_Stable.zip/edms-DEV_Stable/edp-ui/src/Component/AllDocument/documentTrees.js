import React, { useEffect } from 'react';
import './index.css';
import TreeView from '@mui/lab/TreeView';
import TreeItem from '@mui/lab/TreeItem';

const DocumentTree = ({docData}) => {
    
        // const hierarchy = docData.docClass.split('/');
        // console.log(hierarchy);
  
    

    return (
        <TreeView
            defaultCollapseIcon={
                <img
                    className='tree-view-icon'
                    src="./CollapseIcon.png"
                    alt='Collapse Icon'
                />
            }
          
            defaultExpandIcon={
                <img
                    className='tree-view-icon'
                    src="./ExpandIcon.png"
                    alt='Expand Icon'
                />
            }
            sx={{
                height: '100%',
                flexGrow: 1,
                maxWidth: 400,
                overflowY: 'auto'
            }}
        >


        {/* <TreeItem nodeId={hierarchy[0]} label={hierarchy[0]}>  
                <TreeItem nodeId = {hierarchy[1]} label={hierarchy[1]}>
                      <TreeItem nodeId = {hierarchy[2]} label={hierarchy[2]}>
                            <TreeItem  nodeId = {hierarchy[3]} label={hierarchy[3]}>
                            <TreeItem  nodeId = {hierarchy[4]} label={hierarchy[4]}>
                            <TreeItem  nodeId = {hierarchy[5]} label={hierarchy[5]}>
                            </TreeItem>
                            <TreeItem  nodeId = {hierarchy[6]} label={hierarchy[6]}>
                            </TreeItem>
                            <TreeItem  nodeId = {hierarchy[7]} label={hierarchy[7]}>
                            </TreeItem>
                            </TreeItem>
                            </TreeItem>
                      </TreeItem>
                      
                </TreeItem>
        </TreeItem>
    */}
              
   
    

 
  {/* {docData.map((data,index) =>{
    const hierarchy = data.docClass.split('/');
    return (
        <TreeItem key={index} nodeId={data.edpId} label={hierarchy[0]}>
            {hierarchy.slice(1).map((label, i) => (
                <TreeItem key={i} nodeId = {hierarchy[1]} label={label}>
                    {hierarchy.slice(2).map((label, i) => (
                      <TreeItem key={i} nodeId = {hierarchy[2]} label={label}>
                         {hierarchy.slice(3).map((label, i) => (
                            <TreeItem key={i} nodeId = {hierarchy[3]} label={label}>
                            
                            </TreeItem>
                        ))} 
                      </TreeItem>
                   ))} 
                </TreeItem>
            ))}
        </TreeItem>
    );
    
})}  */}
   
{
    docData.map((data,index) =>{
        const hierarchy = data.docClass.split('/');
        console.log(hierarchy);
        return(
        <TreeItem key= {index} nodeId='1' label={hierarchy[0]}>
            <TreeItem nodeId='2' label={hierarchy[1]}>
                <TreeItem nodeId='3' label={hierarchy[2]}>
                    <TreeItem nodeId='4' label={hierarchy[3]}> 
                        <TreeItem nodeId='5' label={hierarchy[4]}> 
                        <TreeItem nodeId='6' label={hierarchy[5]}> 
                        <TreeItem nodeId='7' label={hierarchy[6]}> 
                        <TreeItem nodeId='8' label={hierarchy[7]}> 
                        <TreeItem nodeId='9' label={hierarchy[8]}> 
                         </TreeItem>
                         </TreeItem>
                         </TreeItem>
                        </TreeItem>
                        </TreeItem>
                    </TreeItem>
                </TreeItem>
            </TreeItem>
        </TreeItem>
        );
    })
}

{/* {docData.map(data => {
        const hierarchy = data.docClass.split('/');
        return (
          <TreeItem nodeId={data.edpId} label={hierarchy[0]}>
            <TreeItem nodeId={data.edpId} label={hierarchy[1]}>
             <TreeItem nodeId={data.edpId} label={hierarchy[2]}>
            {hierarchy.slice(3).map((label, index) => (
              <TreeItem nodeId={`${data.edpId}-${index}`} label={label} />
            ))}
            </TreeItem>
            </TreeItem>
          </TreeItem>
          
           
        );
      })} */}
{/* //             <TreeItem nodeId="1" label="IDFC EDP">
//                 <TreeItem nodeId="2" label="Customer ID">
//                     <TreeItem nodeId="3" label="Assets">
//                         <TreeItem nodeId="5" label="Product Name">
//                             <TreeItem nodeId="6" label="SFDC">
//                                 <TreeItem nodeId="7" label="Document Type">
//                                     <TreeItem nodeId="8" label="Document Name">
//                                         <TreeItem nodeId="9" label="PAN V2.0" />
//                                         <TreeItem nodeId="10" label="PAN V1.0" />
//                                         <TreeItem nodeId="11" label="Aadhar V1.0" />
//                                     </TreeItem>
//                                 </TreeItem>
//                             </TreeItem>
//                         </TreeItem>
//                     </TreeItem>
//                     <TreeItem nodeId="12" label="Liabilities">
//                             <TreeItem nodeId="13" label="Product Name">
//                                 <TreeItem nodeId="14" label="SFDC">
//                                     <TreeItem nodeId="15" label="Document Type">
//                                         <TreeItem nodeId="16" label="Document Name">
//                                             <TreeItem nodeId="17" label="Aadhar V1.0" />
//                                         </TreeItem>
//                                     </TreeItem>
//                                 </TreeItem>
//                                 <TreeItem nodeId="18" label="Trade Finance"></TreeItem>
//                                 <TreeItem nodeId="19" label="EDP"></TreeItem>
//                             </TreeItem>
//                         </TreeItem>
//                 </TreeItem>
//             </TreeItem> */}
        </TreeView>
    );
}

export default DocumentTree;


    