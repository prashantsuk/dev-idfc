import React, { useState } from 'react';

export default function TreeComponent({ data }) {
  const [isExpanded, setIsExpanded] = useState(false);

  function handleToggle() {
    setIsExpanded(!isExpanded);
  }

  if (!isExpanded) {
    return (
      <div onClick={handleToggle}>
        <span>▶️</span>
        {Object.keys(data).length} {Object.keys(data).length === 1 ? 'item' : 'items'}
      </div>
    );
  }

  return (
    <div>
      <div onClick={handleToggle}>
        <span>🔽</span>
        {Object.keys(data).length} {Object.keys(data).length === 1 ? 'item' : 'items'}
      </div>
      <ul>
        {Object.entries(data).map(([key, value]) => (
          <li key={key}>
            <div>{key}</div>
            {typeof value === 'object' ? <Tree data={value} /> : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

