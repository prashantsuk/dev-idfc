import React from 'react';
import TreeView from '@mui/lab/TreeView';
import TreeItem from '@mui/lab/TreeItem';

function buildTree(hierarchy, index, key) {
    const label = hierarchy[index];
    const children = [];
  
    // Recursively build child nodes
    if (index + 1 < hierarchy.length) {
      let i = index + 1;
      while (i < hierarchy.length) {
        if (hierarchy[i] === label) {
          // Group child trees with same label under same parent node
          const [subtree, j] = buildTree(hierarchy, i, `${key}-${i}`);
          children.push(subtree);
          i = j;
        } else {
          const [subtree, j] = buildTree(hierarchy, i, `${key}-${i}`);
          children.push(subtree);
          i = j;
        }
      }
    }
  
    return (
      <TreeItem key={key} nodeId={key} label={label}>
        {children}
        
      </TreeItem>
    );
  }
  
  export function DocumentTreess({ docData }) {
    const treeNodes = docData.map((data, index) => {
      const hierarchy = data.docClass.split('/');
      return buildTree(hierarchy, 0, `${index}`);
    });
  
    return (
      <TreeView>
        {treeNodes}
      </TreeView>
    );
  }

  
  
  
  
  