import React from 'react';
import './index.css';

const Button = (props) => {

    const { buttonTitle, buttonStyle, className } = props;

    return (
        <div className={className | "btn"} style={{ ...{ height: 40, width: 148, borderRadius: 20, justifyContent: 'center', alignItems: 'center', backgroundColor: "#9d1d27" }, ...buttonStyle }}>
            <p>{buttonTitle}</p>
        </div>
    );
}

export default Button;