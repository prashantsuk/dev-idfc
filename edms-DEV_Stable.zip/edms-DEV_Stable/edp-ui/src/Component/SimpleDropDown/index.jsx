import React from 'react';
import { FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import './simpleDropDown.css';
function SimpleDropDown({ options, label, value, onChange }) {
  return (
    <FormControl variant="standard" sx={{ minWidth: 120, width: "200px" }} style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
      <InputLabel>{label}</InputLabel>
      <Select
        value={value}
        onChange={onChange}
        MenuProps={{
          anchorOrigin: {
            vertical: 'bottom',
            horizontal: 'center',
          },
        }}
        sx={{
            textOverflow: 'ellipsis',
            overflow: 'hidden',
            whiteSpace: 'nowrap',
            '&:hover': {
              backgroundColor: 'transparent',
              borderBottom: 'none !important', // add this line to remove the border on hover
            },
            '&:before': {
              borderBottom: 'none !important',
            },
            '&:after': {
              borderBottom: 'none !important',
            },
          }}
      >
        {options.map((option, index) => (
          <MenuItem key={index} value={option}>
            {option}
          </MenuItem>
        ))}
      </Select>
    </FormControl>
  );
}

export default SimpleDropDown;