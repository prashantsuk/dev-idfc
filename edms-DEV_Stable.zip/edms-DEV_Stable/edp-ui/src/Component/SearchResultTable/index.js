import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './index.css';
import MetaDataDetailView from '../MetaDataDetailView';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
// import { BsDownload } from "react-icons/bs";
import {
    TableContainer,
    Table,
    TableHead,
    TableBody,
    TableRow,
    TableCell,
    Paper
} from '@mui/material'
const SearchResultTable = ({ data, activetabs, productListItems }) => {
    const [showModal, setShowModal] = useState(false);
    const [selectedData, setSelectedData] = useState({});
    const [itemData, setItemData] = useState(null);
    console.log(productListItems)

    // useEffect(() => {
    //     const fetchMetaData = async () => {
    //         const response = await axios.get(`http://52.140.58.184:9414/msGetMetaData/getMetaData?sourceName=EDP&custId=${item.custId}`,{headers:{"Access-Control-Allow-Origin": "*"}});
    //         // setSelectType(response.data);
    //         setSelectedData(response.data);
    //         console.log(response.data);
    //     }
    //     fetchMetaData() 
    // }, [])

    const handleModal = async (item) => {
        setItemData(item);
        console.log(item);
        const response = await axios.get(`http://52.140.58.184:9414/msGetMetaData/getMetaData?custId=${item.custId}&category=${item.category}`, { headers: { "Access-Control-Allow-Origin": "*" } });
        setSelectedData(response.data.documentDataList);
        console.log(response.data.documentDataList);


        setShowModal(!showModal);
        const tabl = document.querySelector('.table-block');
        tabl.style.display = 'none';

    };
    const handleBack = () => {
        setShowModal(!showModal);
        const tabl = document.querySelector('.table-block');
        tabl.style.display = 'block';
    }

    return (
        <div className='search-result-table' >


            <div className='table-container'>

                {showModal && (
                    <div className='transparent-view'>
                        <p onClick={handleBack}><ArrowBackIcon style={{ width: '15' }} />Back to Result</p>
                        <div className='modal-view'>
                            <MetaDataDetailView metaData={selectedData} data={itemData} tabs={activetabs} prod={productListItems}/>
                        </div>
                    </div>
                )}

                <div className='table-block'>
                    <div className='header-view'>
                        <p className='title-text'>Search Result</p>
                        {/* <button className='button-style' type="button"><BsDownload fontWeight={200}/> Export All</button> */}
                    </div>
                    {/*          
            <table className="table">
                <thead>
                    <tr>
                        <th scope="col">Customer ID</th>
                        <th scope="col">Mobile Number</th>
                        <th scope="col">Category</th>
                        <th scope="col">Source</th>
                        <th scope="col">Product Name</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    {
              data.map((item, index) =>{
                return(
                    <tr key = {index}>
                        <td>{item.custId}</td>
                        <td>{item.mobileNumber}</td>
                        <td>{item.category}</td>
                        <td>{item.source}</td>
                        <td>{item.productName}</td>
                        <td><button className='button-style' type="button" onClick={() => handleModal(item)}>Detailed View</button></td>
                    </tr>
                )
               }) 
            }
                </tbody>
            </table> */}
                    <TableContainer sx={{maxHeight: '400px'}} component={Paper}>
                    {/* <TableContainer sx={{ maxHeight: '300px' }} component={Paper}> */}
                        <Table stickyHeader aria-label='simple table'>
                            <TableHead>
                                <TableRow>
                                    <TableCell sx={{ fontWeight: 'bold' }}>Customer ID</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold' }}>Mobile Number</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold' }}>Category</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold' }}>Source</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold' }}>Product Name</TableCell>
                                    <TableCell sx={{ fontWeight: 'bold' }}>Actions</TableCell>

                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {data.map((item, index)=> (
                                    <TableRow
                                        key={index}
                                        sx={{ '&:last-child td, &:last-child th': { border: 0 } }}>

                                        <TableCell>{item.custId}</TableCell>
                                        <TableCell>{item.mobileNumber}</TableCell>
                                        <TableCell>{item.category}</TableCell>
                                        <TableCell>{item.source}</TableCell>
                                        <TableCell>{item.productName}</TableCell>
                                        <TableCell><button className='button-style' type="button" onClick={() => handleModal(item)}>Detailed View</button></TableCell>
                                    </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </TableContainer>
                </div>

            </div>

        </div>
    );
}

export default SearchResultTable;