import React, {useState, useEffect} from 'react';
import axios from 'axios';
import './UploadPage.css';
import { Button } from '@mui/material';
import { BsUpload } from "react-icons/bs";
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import ClearIcon from '@mui/icons-material/Clear';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
// import {useNavigate} from 'react-router-dom';



export default function UploadPage({userName}) {
  const assetsUploadUrl ="http://52.140.58.184:9414/msAssetAddDocument/assets/addDocument";
  const liabilitiesUploadUrl ="http://52.140.58.184:9414/msLiabilitiesAddDocument/addDoc/liabilities";
  const virusScanUrl ="http://52.140.58.184:9414/msEdpMcafeeVirusScan/scanFile";
  // const liabilitiesUploadUrl = "https://jsonplaceholder.typicode.com/pos";
  // const assetsUploadUrl = "https://jsonplaceholder.typicode.com/posts"

  const [custIdError, setCustIdError] = useState(false);
  const [docNameError, setDocNameError] = useState(false);
  const [docTypeError, setDocTypeError] = useState(false);
  const [prodNameError, setProdNameError] = useState(false);
  const [categoryError, setCategoryError] = useState(false);
  const [fileFieldError, setFileFieldError] = useState(false);

  const[custId, setCustId] = useState("");
  const[password, setPassword] = useState("");
  const[prodName, setProdName] = useState("");
  const[selectType, setSelectType] = useState([]);
  const[selectName, setSelectName] = useState([]);
  const[productName, setProductName] = useState([]);
  const[doctypeId, setDoctypeId] = useState("");
  const[assetName, setAssetName] =useState("")
  const[docType, setDocType] = useState("");
  const[docName, setDocName] = useState("");
  const[fileName, setFileName] = useState("");
  const[fileType, setFileType] = useState("");
  const [bs64Img, setBs64Img] = useState("");
  const[fileSize, setFileSize] = useState("")
  const [isOpen, setIsOpen] = useState(false);
  const[data, setData] = useState("");
  const[hide, setHide] = useState(false);
  const [isLoading, setLoading] = useState(false);
  // const navigate = useNavigate();

  // empty field error
  const handleCustIdBlur = () => {
    if (custId.trim() === '') {
      setCustIdError(true);
    } else {
      setCustIdError(false);
    }
  }
  const handleDocName = (e) => {
    const selectedValue = e.target.value;
    setDocName(selectedValue);
    setDocNameError(selectedValue === 'None');
  };

  const handleDocType = (e) => {
    const selectedValue = e.target.value;
    setDocType(selectedValue);
    setDocTypeError(selectedValue === 'None');
  };
  const handleProductName = (e) => {
    const selectedValue = e.target.value;
    setProdName(selectedValue);
    setProdNameError(selectedValue === 'None');
  };

  const handleCategory = (e) => {
    const selectedValue = e.target.value;
    setAssetName(selectedValue);
    setCategoryError(selectedValue === 'None');
  };

  useEffect(() => {
    const fetchProductName = async () => {
        const response = await axios.get(`http://52.140.58.184:9414/msGetDocumentMasterData/edms/productName?category=${assetName}`,{headers:{"Access-Control-Allow-Origin": "*"}});
        // setSelectType(response.data);
        console.log(response.data);
        setProductName(response.data);
        // const unique = response.data.filter((v, i, a) => a.findIndex(t => t.productId === v.productId) === i);
        // setProductName(unique);
        // console.log(unique);
    }
    fetchProductName() 
}, [assetName])
 
useEffect(() => {
    const fetchDocType = async () => {
        const response = await axios.get(`http://52.140.58.184:9414/msGetDocumentMasterData/edms?category=${assetName}`,{headers:{"Access-Control-Allow-Origin": "*"}});
        // setSelectType(response.data);
        console.log(response.data);
        const unique = response.data.filter((v, i, a) => a.findIndex(t => t.doctypeid === v.doctypeid) === i);
        setSelectType(unique);
        console.log(unique);
    }
    fetchDocType() 
}, [assetName])


  useEffect(() =>{
    try {
      const fetchDocName = async () =>{
        const response = await axios.get(`http://52.140.58.184:9414/msGetDocumentMasterData/edms?category=${assetName}`,{headers:{"Access-Control-Allow-Origin": "*"}});
        const selectedDocTypeId = selectType.find(doctype => doctype.doctypename === docType).doctypeid;
        console.log(selectedDocTypeId);
        setDoctypeId(selectedDocTypeId);
        const filteredDocs = response.data.filter(doc => doc.doctypeid === selectedDocTypeId);
        setSelectName(filteredDocs);
        console.log(filteredDocs);
      }
     if(docType){
      fetchDocName();
    } 
      
    } catch (error) {
      console.log(error);
      
    }
  },[docType])

  const handleCustId = (e) =>{
    const numberRegExp = new RegExp(/^\d{0,16}$/);
    const Id = e.target.value;
    if(numberRegExp.test(Id) && Id >= 0){
      setCustId(Id);
    }
  }

// to handle file delete from selection

const handleFileDelete = () =>{
  setHide(false);
  setFileName("");
  setBs64Img("");
  setFileType("");
  setFileSize("");
}


const handleDragOver = (e) =>{
   e.preventDefault();
}

const handleDrop =  async (e) => {
  e.preventDefault();
    const file = e.dataTransfer.files[0];
    setLoading(true); 
    if (file === '') {
      setFileFieldError(true);
    } else {
      setFileFieldError(false);
    }
    // virusScan(file);
    const isInfected = await virusScan(file);
    if (isInfected) {
      // Handle infected file
      const uploadButton = document.querySelector('.button-upload');
      uploadButton.disabled = true;
    } else {
      // Handle clean file
      const uploadButton = document.querySelector('.button-upload');
      uploadButton.disabled = false;
    }
    setLoading(false); 
    
   console.log(e.dataTransfer.files[0]);
   console.log(file.name, file.type, file.size);
          const allowedFileTypes=["pdf","txt","doc","docx","tif","tiff","jpg","jpeg","xls","xlsx","xlsb","eml","html","htm","png","msg","ppt","pptx","csv","zip"];

          if(!file.name.match(/\.(jpg|pdf|txt|doc|docx|tif|tiff|jpg|jpe|jpeg|xls|xlsx|xlsb|eml|html|htm|png|msg|ppt|pptx|csv|zip|7z|PDF|TXT|DOC|DOCX|TIF|TIFF|JPG|JPE|JPEG|XLS|XLSX|XLSB|EML|HTML|HTM|PNG|MSG|PPT|PPTX|CSV|ZIP|7Z|Pdf|Txt|Doc|Docx|Tif|Tiff|Jpg|Jpe|Jpeg|Xls|Xlsx|Xlsb|Eml|Html|Htm|Png|Msg|Ppt|Ppptx|Csv|Zip|JFIF|jfif|Jfif)$/)){
            alert(`File type does not support. File type must be ${allowedFileTypes.join(", ")}`);
            return false;
          }

          if(file.size > 10e6){
            alert("File size should be less than 10 MB");
            return false;
          }
          
          setFileType(file.type);
          setFileName(file.name);
          setFileSize(file.size);
          convertBase64(file);
          setHide(true);
}
        const onChange = async (e) =>{
          const file = e.target.files[0];
          e.target.value = ''; 
          setLoading(true); 
          if (file === '') {
            setFileFieldError(true);
          } else {
            setFileFieldError(false);
          }
          // virusScan(file);
          const isInfected = await virusScan(file);
          if (isInfected) {
            // Handle infected file
            const uploadButton = document.querySelector('.button-upload');
            uploadButton.disabled = true;
          } else {
            // Handle clean file
            const uploadButton = document.querySelector('.button-upload');
            uploadButton.disabled = false;
          }
          setLoading(false); 

          console.log(file);
          console.log(file.name, file.type, file.size);
          const allowedFileTypes=["pdf","txt","doc","docx","tif","tiff","jpg","jpeg","xls","xlsx","xlsb","eml","html","htm","png","msg","ppt","pptx","csv","zip"];

          if(!file.name.match(/\.(jpg|pdf|txt|doc|docx|tif|tiff|jpg|jpe|jpeg|xls|xlsx|xlsb|eml|html|htm|png|msg|ppt|pptx|csv|zip|7z|PDF|TXT|DOC|DOCX|TIF|TIFF|JPG|JPE|JPEG|XLS|XLSX|XLSB|EML|HTML|HTM|PNG|MSG|PPT|PPTX|CSV|ZIP|7Z|Pdf|Txt|Doc|Docx|Tif|Tiff|Jpg|Jpe|Jpeg|Xls|Xlsx|Xlsb|Eml|Html|Htm|Png|Msg|Ppt|Ppptx|Csv|Zip|JFIF|jfif|Jfif)$/)){
            alert(`File type does not support. File type must be ${allowedFileTypes.join(", ")}`);
            return false;
          }

          if(file.size > 10e6){
            alert("File size should be less than 10 MB");
            return false;
          }
          setFileType(file.type);
          setFileName(file.name);
          setFileSize(file.size);
          convertBase64(file);      
          setHide(true);
        
        }
      const onLoad = (fileString) =>{
        setBs64Img(fileString);
       
      }
            const convertBase64 =(file)=>{
            
                 const fileReader = new FileReader();
                 fileReader.readAsDataURL(file);
                 fileReader.onload = () =>{
                    onLoad(fileReader.result);
                 }
               }

    const handleSubmit = async (e) =>{
      e.preventDefault();
    
   
    if (custId === '') {
      setCustIdError(true);
      return; // Stop form submission
    }
    else if(assetName === '' || assetName === 'None'){
      setCategoryError(true);
      return;
    }
    else if(prodName === '' || prodName === 'None'){
      setProdNameError(true);
      return;
    }
    else if (docType === '' || docType === 'None'){
      setDocTypeError(true);
      return;
    }
    else if (docName === '' || docName === 'None' ){
      setDocNameError(true);
      return;
    }
    else if (bs64Img === '' || fileName === 'None' ){
      setFileFieldError(true);
      return;
    }
      else if (assetName === "ASSETS"){ 
        
        const data =  {uploadDocuments:{objectBean:{content:bs64Img,fileLocation:fileName,
          property:[{propertyName:"CF_DocumentName",propertyValue:docName},{propertyName:"DocumentTitle",propertyValue:fileName},
          {propertyName:"CF_DocumentTypeName",propertyValue:docName},{propertyName:"CF_UploadedBy",propertyValue:docName},
          {propertyName:"CF_OriginalPhotocopy",propertyValue:docName},{propertyName:"CF_Mandatory",propertyValue:custId},
          {propertyName:"CF_DealerOnboardingID",propertyValue:custId},{propertyName:"CF_FinnOneLoanNumber",propertyValue:custId},
          {propertyName:"CF_CRMId",propertyValue:custId},{propertyName:"CF_ApplicationId",propertyValue:custId}] }},password,prodName,userName, prntFldrIndx:"100",srcFldrIndx:"101", mimeType:fileType, documentType:docType, doctypeId,sourceId:"1",sourceName:"EDP"};
        console.log(data);
        try {
          const res = await axios.post(assetsUploadUrl, data,{headers:{"Access-Control-Allow-Origin": "*"}});
          console.log(res.data);
          const MySwal = withReactContent(Swal);
          MySwal.fire({
            title: <p>Succesfully Uploaded</p>,
            didOpen: () => {
              Swal.fire({
                text:'Successfully Uploaded',
                icon:'success'
              })
            },
           
          }).then(() => {
            return MySwal.fire(<p>Shorthand works </p>)
          }) 
          const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
          closeButton.click();
          
        } catch (error) {
          const MySwal = withReactContent(Swal);
          MySwal.fire({
          // title: 'Error Occured!',
          text: error.message,
          icon: 'error',
          });  
        }
        const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
        closeButton.click();
      }
      else if (assetName === "LIABILITIES"){
        // const fileInput = document.querySelector('#fileInput').files[0];
        // if(await virusScan(fileInput)){
        //   return true;
        //  }
        const data = {uploadDMSDocReq:{msgBdy:{custId, assetName, prodName, userName, docType, docName, bs64Img, password,prntFldrIndx:"1",srcFldrIndx:"2", srcNm: "EDP", fileName, fileType, doctypeId}}};
        setData(data);
        console.log(data);
        try {
          const res = await axios.post(liabilitiesUploadUrl, data,{headers:{"Access-Control-Allow-Origin": "*", "Custom-Header": userName}});
          console.log(res.data);
          const MySwal = withReactContent(Swal);
          MySwal.fire({
          title: <p>Succesfully Uploaded</p>,
          didOpen: () => {
            Swal.fire({
                text:'Successfully Uploaded',
                icon:'success'
             })
          },
         
        }).then(() => {
          return MySwal.fire(<p>Shorthand works </p>)
        }) 
        const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
        closeButton.click();
        } catch (error) {
          const errorCode = error.response?.data?.uploadDMSDocResp?.msgHdr?.error?.cd;
          const errorMsg = error.response?.data?.uploadDMSDocResp?.msgHdr?.error?.rsn;
          if (errorCode === "EXP_400"){
            const MySwal = withReactContent(Swal);
            MySwal.fire({
            // title: 'Error Occured!',
            text: errorMsg,
            icon: 'error',
            });
          }
         else {
          const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
          closeButton.click(); 
         }
         
        }
       
        }
    }
    const virusScan = async (file) =>{
      try {
        let data = new FormData();
        data.append("malware",file) 
        const response = await axios.post(virusScanUrl,data,{headers:{"Access-Control-Allow-Origin": "*"}})
          if(response.data.mcafee.infected) {
          const MySwal = withReactContent(Swal);
          MySwal.fire({
            title: "Virus Detected!",
            text: `${file.name} is infected. Please avoid uploading the file.`,
            icon: "warning",
            confirmButtonText: "OK",
          }).then(() => {
            const progressBar = document.querySelector('.progress-bar');
            progressBar.classList.remove('bg-success');
            progressBar.classList.add('bg-danger');
            const progressPercentage = document.querySelector('.file-size > span:first-child');
            progressPercentage.style.visibility = 'hidden';
            // handleFileDelete();
          });
          return true;
          } else{
            return false;
          }
        
      } catch (error) {
         console.log(error);
         const MySwal = withReactContent(Swal);
         MySwal.fire({
         text: error.message,
         icon: 'error',
         }); 
      }
      }

   const handleReset = () =>{
    setCustId("");
    setPassword("");
    setAssetName("");
    setDocType("");
    setDocName("");
    setProdName("");
    setFileName("");
    setBs64Img("");
    setHide(false);
    setCustIdError(false);
    setDocNameError(false);
    setDocTypeError(false);
    setProdNameError(false);
    setCategoryError(false);
    setFileFieldError(false);
     
   }
  return (
    
    <div className='Upload-form'>
       
       <div className="header-button">
        <button type="button"  data-bs-toggle="modal" data-bs-target="#staticBackdrop"  onClick={() => setIsOpen(true)} ><BsUpload fontWeight={200}/> UPLOAD DOCUMENT
        </button>
      </div>
     
    <div className={`modal fade ${isOpen ? "show" : ""}`} id="staticBackdrop"  data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div className="modal-dialog modal-dialog-centered">
    <div className="modal-content">
      <div className="modal-header">
        <h1 className="modal-title fs-5" id="staticBackdropLabel">UPLOAD DOCUMENT</h1>
        <button type="button" className="btn-close close-button" onClick = {handleReset} data-bs-dismiss="modal" aria-label="Close" ></button>
      </div>
      <div className="modal-body">
        {/* <div className="">
            <label htmlFor="" className="form-label">Customer ID<span className='imp'>*</span></label>
            <input type="text" className="form-control shadow-none" id="custId" placeholder="" value={custId}
            onChange = {handleCustId}/>
         </div> */}
         <div className="">
            <label htmlFor="" className={`form-label ${custIdError ? 'text-danger' : ''}`}>Customer ID<span className='imp'>*</span></label>
            <input type="text" className={`form-control shadow-none ${custIdError ? 'border-danger' : ''}`} id="custId" placeholder="" value={custId}
            onChange = {handleCustId} onBlur={handleCustIdBlur} required/>
            {custIdError && <div className="text-danger align-right"> *Please enter customer ID</div>}
         </div>
         <div className="">
            <label htmlFor="" className={`form-label ${categoryError ? 'text-danger' : ''}`}>Category<span className='imp'>*</span></label>
            <select className={`form-select shadow-none ${categoryError ? 'border-danger' : ''}`} id="assetLiabId"  value={assetName}
            onChange = {handleCategory}>
            <option >None</option>
            <option>ASSETS</option>
            <option>LIABILITIES</option>
      
            </select>
            {categoryError && <div className="text-danger align-right">* Please select a valid Category</div>}
          </div>
          {/* <div className="">
            <label htmlFor="" className="form-label">Product Name<span className='imp'>*</span></label>
            <input type="text" className="form-control shadow-none" id="prodName" placeholder="" value={prodName}
            onChange =  {(e) => setProdName(e.target.value)}/>
          </div> */}
           <div className="">
          <label htmlFor="" className={`form-label ${prodNameError ? 'text-danger' : ''}`}>Product Name<span className='imp'>*</span></label>
          <select className={`form-select shadow-none ${prodNameError ? 'border-danger' : ''}`} id=""value = {prodName} onChange = {handleProductName}>
          
            <option >None</option>
              {/* {
                productName.map((type, id) =>{
                  return(
                    <option key = {id} value = {type.productName}>{type.productName}</option>
                  )
                })
              } */}
               {
                productName
                  .sort((a, b) => a.productName.localeCompare(b.productName)) // Sort options alphabetically
                  .map((type, id) => (
                    <option key={id} value={type.productName}>{type.productName}</option>
                  ))
              }
                      </select>
            {prodNameError && <div className="text-danger align-right">* Please select a valid Product Name</div>}
          </div>
         <div className="">
          <label htmlFor="" className={`form-label ${docTypeError ? 'text-danger' : ''}`}>Document Type<span className='imp'>*</span></label>
          <select className={`form-select shadow-none ${docTypeError ? 'border-danger' : ''}`} id=""value = {docType} onChange = {handleDocType}>
          
            <option >None</option>
              {/* {
                selectType.map((type, id) =>{
                  return(
                    <option key = {id} value = {type.doctypename}>{type.doctypename}</option>
                  )
                })
              } */}
              {
                selectType
                  .sort((a, b) => a.doctypename.localeCompare(b.doctypename)) // Sort options alphabetically
                  .map((type, id) => (
                    <option key={id} value={type.doctypename}>{type.doctypename}</option>
                  ))
              }
            </select>
            {docTypeError && <div className="text-danger align-right">* Please select a valid Document Type</div>}
          </div>

          <div className="">
            <label htmlFor="" className={`form-label ${docNameError ? 'text-danger' : ''}`}>Document Name<span className='imp'>*</span></label>
            <select className={`form-select shadow-none ${docNameError ? 'border-danger' : ''}`} id=""  value ={docName} onChange = {handleDocName} required>
           
            <option>None</option>
              {/* {
                 
                selectName.map((name, id) =>{
                  return(
                      <option key ={id} value={name.documentName}>{name.documentName}</option>
                  )
                })
              } */}
               {
                selectName
                  .sort((a, b) => a.documentName.localeCompare(b.documentName)) // Sort options alphabetically
                  .map((name, id) => (
                    <option key={id} value={name.documentName}>{name.documentName}</option>
                  ))
              }
            
            </select>
            {docNameError && <div className="text-danger align-right">* Please select a valid Document Name</div>}
          </div>

          <div className="">
            <label htmlFor="" className="form-label">Document Password</label>
            <input type="password" 
            className="form-control shadow-none" 
            id="docPassword"
            value={password}
            onChange = {(e) => setPassword(e.target.value)} placeholder=""/>
         </div>
          <div className={`browse-file-div ${fileFieldError ? 'border-danger' : ''}`} onDragOver={handleDragOver} onDrop={handleDrop}>
            <label className="custom-file-label form-label">
             <input className="custom-file-input"
              type="file" 
              id="fileInput"
              name ="doc"
              onChange = {onChange}/><span >Click here to Upload Files or drop files here </span>
           </label>
           
          </div>
          {fileFieldError && <div className="text-danger align-right">* Please select a file</div>}
          {isLoading && <div className="loading-symbol">
            <Box sx={{ display: 'flex' }}>
             <CircularProgress style={{color:'green'}}/>
            </Box>
          </div>} {/* Render loading symbol if loading state is true */}
          {
            hide === true &&
         
           <div className="file-path">
           
            <span className='file-name'><InsertDriveFileIcon/> {fileName}</span>
            <div className="file-progress">
            <div className="progress">
              <div className="progress-bar bg-success"  style={{width:'100%'}} ></div>
            </div>
            <div className="file-size"><span>100%</span> <span>{fileSize / 1024} KB</span></div>
            </div>
            <ClearIcon onClick={handleFileDelete}/>
          </div>
           }
        
       </div>
      <div className="modal-footer">
        <Button className="clear-button" 
           style={{color: 'black',textDecoration:'underline', paddingRight:"10px"}} 
           onClick = {handleReset}>
          Clear
        </Button>
        <div className="header-button pl-3">
          <button type="submit" onClick ={handleSubmit} className="button-upload"><BsUpload fontWeight={200}/> UPLOAD DOCUMENT</button>
        </div>
     
      </div>
    </div>
  </div>
</div>

   </div>





  )
}
