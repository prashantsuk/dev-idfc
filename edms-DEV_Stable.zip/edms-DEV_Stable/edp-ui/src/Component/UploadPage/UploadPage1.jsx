import React, {useState, useEffect} from 'react';
import axios from 'axios';
import './UploadPage.css';
import { Button } from '@mui/material';
import { BsUpload } from "react-icons/bs";
import Swal from 'sweetalert2';
import withReactContent from 'sweetalert2-react-content';
import ClearIcon from '@mui/icons-material/Clear';
import InsertDriveFileIcon from '@mui/icons-material/InsertDriveFile';



export default function UploadPage1() {
  // const assetsUploadUrl ="http://52.140.58.184:9414/msAssetAddDocument/doc-upload";
  // const liabilitiesUploadUrl ="http://52.140.58.184:9414/msAddDocument/addDoc/liabilities";
  // const url ="https://jsonplaceholder.typicode.com/posts";
  const liabilitiesUploadUrl = "https://jsonplaceholder.typicode.com/posts";
  const assetsUploadUrl = "https://jsonplaceholder.typicode.com/posts"

  const[custId, setCustId] = useState("");
  const[password, setPassword] = useState("");
  const[selectType, setSelectType] = useState([]);
  const[selectName, setSelectName] = useState([]);
  const[doctypeId, setDoctypeId] = useState("");
  const[assetName, setAssetName] =useState("")
  const[docType, setDocType] = useState("");
  const[docName, setDocName] = useState("");
  const[fileName, setFileName] = useState("");
  const[fileType, setFileType] = useState("");
  const [bs64Img, setBs64Img] = useState("");
  const[fileSize, setFileSize] = useState("")
  const [isOpen, setIsOpen] = useState(false);
  const[data, setData] = useState("");
  const[hide, setHide] = useState(false);
  const [files, setFiles] = useState([]);

 
useEffect(() => {
    const fetchDocType = async () => {
        const response = await axios.get(`http://52.140.58.184:9414/msGetDocumentMasterData/edms?category=${assetName}`,{headers:{"Access-Control-Allow-Origin": "*"}});
        // setSelectType(response.data);
        console.log(response.data);
        const unique = response.data.filter((v, i, a) => a.findIndex(t => t.doctypeid === v.doctypeid) === i);
        setSelectType(unique);
        console.log(unique);
    }
    fetchDocType() 
}, [assetName])


  useEffect(() =>{
    try {
      const fetchDocName = async () =>{
        const response = await axios.get(`http://52.140.58.184:9414/msGetDocumentMasterData/edms?category=${assetName}`,{headers:{"Access-Control-Allow-Origin": "*"}});
        const selectedDocTypeId = selectType.find(doctype => doctype.doctypename === docType).doctypeid;
        console.log(selectedDocTypeId);
        setDoctypeId(selectedDocTypeId);
        const filteredDocs = response.data.filter(doc => doc.doctypeid === selectedDocTypeId);
        setSelectName(filteredDocs);
        console.log(filteredDocs);
      }
     if(docType){
      fetchDocName();
    } 
      
    } catch (error) {
      console.log(error);
      
    }
  },[docType])

  const handleCustId = (e) =>{
    const numberRegExp = new RegExp(/^\d{0,14}$/);
    const Id = e.target.value;
    if(numberRegExp.test(Id) && Id >= 0){
      setCustId(Id);
    }
  }

// to handle file delete from selection

const handleFileDelete = (index) =>{
  let updatedFiles = [...files];
  updatedFiles.splice(index, 1);
  setFiles(updatedFiles);
  setHide(false);
//   setFileName("");
//   setBs64Img("");
//   setFileType("");
//   setFileSize("");
}


const handleDragOver = (e) =>{
   e.preventDefault();
}

const handleDrop = (e) => {
  e.preventDefault();
    // const file = e.dataTransfer.files[0];
    selectedFiles = e.dataTransfer.files;
    setFiles([...files, ...selectedFiles]);
   console.log(e.dataTransfer.files);
//    console.log(files.name, files.type, files.size);
          const allowedFileTypes=["pdf","txt","doc","docx","tif","tiff","jpg","jpeg","xls","xlsx","xlsb","eml","html","htm","png","msg","ppt","pptx","csv","zip"];
         
          for (let i = 0; i < selectedFiles.length; i++) {
            const file = selectedFiles[i];

          if(!file.name.match(/\.(jpg|pdf|txt|doc|docx|tif|tiff|jpg|jpe|jpeg|xls|xlsx|xlsb|eml|html|htm|png|msg|ppt|pptx|csv|zip|7z|PDF|TXT|DOC|DOCX|TIF|TIFF|JPG|JPE|JPEG|XLS|XLSX|XLSB|EML|HTML|HTM|PNG|MSG|PPT|PPTX|CSV|ZIP|7Z|Pdf|Txt|Doc|Docx|Tif|Tiff|Jpg|Jpe|Jpeg|Xls|Xlsx|Xlsb|Eml|Html|Htm|Png|Msg|Ppt|Ppptx|Csv|Zip|JFIF|jfif|Jfif)$/)){
            alert(`File type does not support. File type must be ${allowedFileTypes.join(", ")}`);
            return false;
          }

          if(file.size > 10e6){
            alert("File size should be less than 10 MB");
            return false;
          }
          setFileType(file.type);
          setFileName(file.name);
          setFileSize(file.size);
          convertBase64(file);
          setHide(true);
        }
}
let selectedFiles;
        const onChange = (e) =>{
        //   const file = e.target.files[0];
           selectedFiles = e.target.files;
          setFiles([...files, ...selectedFiles]);
         
          console.log(files);
        //   console.log(file.name, file.type, file.size);
          const allowedFileTypes=["pdf","txt","doc","docx","tif","tiff","jpg","jpeg","xls","xlsx","xlsb","eml","html","htm","png","msg","ppt","pptx","csv","zip"];
       
          for (let i = 0; i < selectedFiles.length; i++) {
            const file = selectedFiles[i];

          if(!file.name.match(/\.(jpg|pdf|txt|doc|docx|tif|tiff|jpg|jpe|jpeg|xls|xlsx|xlsb|eml|html|htm|png|msg|ppt|pptx|csv|zip|7z|PDF|TXT|DOC|DOCX|TIF|TIFF|JPG|JPE|JPEG|XLS|XLSX|XLSB|EML|HTML|HTM|PNG|MSG|PPT|PPTX|CSV|ZIP|7Z|Pdf|Txt|Doc|Docx|Tif|Tiff|Jpg|Jpe|Jpeg|Xls|Xlsx|Xlsb|Eml|Html|Htm|Png|Msg|Ppt|Ppptx|Csv|Zip|JFIF|jfif|Jfif)$/)){
            alert(`File type does not support. File type must be ${allowedFileTypes.join(", ")}`);
            return false;
          }

          if(file.size > 10e6){
            alert("File size should be less than 10 MB");
            return false;
          }
          setFileType(file.type);
          setFileName(file.name);
          setFileSize(file.size);
          setHide(true);
          convertBase64(file);
        }
        
        }
      const onLoad = (fileString) =>{
        setBs64Img(fileString);
      }
            const convertBase64 =(file)=>{
            
                 const fileReader = new FileReader();
                 fileReader.readAsDataURL(file);
                 fileReader.onload = () =>{
                    onLoad(fileReader.result);
                 }
               }

    const handleSubmit = async (e) =>{
      e.preventDefault();
      // || docType === "" || docName === "" || docType === 'none' || docName === 'none'
      if(custId === "" || bs64Img === "" || fileName === "" ){
        alert("Please fill out all mandatory fields");
     }
    //  else if(docType === 'None' || docName === 'None' || assetName === 'None') {
    //     alert("option selected is None, Please select valid option");
        
    //   }
      else if (assetName === "ASSETS"){ 
        const data =  {uploadDocuments:{objectBean:{content:bs64Img,fileLocation:fileName,
          property:[{propertyName:"CF_DocumentName",propertyValue:docName},{propertyName:"DocumentTitle",propertyValue:fileName},
          {propertyName:"CF_DocumentTypeName",propertyValue:docName},{propertyName:"CF_UploadedBy",propertyValue:docName},
          {propertyName:"CF_OriginalPhotocopy",propertyValue:docName},{propertyName:"CF_Mandatory",propertyValue:custId},
          {propertyName:"CF_DealerOnboardingID",propertyValue:custId},{propertyName:"CF_FinnOneLoanNumber",propertyValue:custId},
          {propertyName:"CF_CRMId",propertyValue:custId},{propertyName:"CF_ApplicationId",propertyValue:custId}] }},password,prntFldrIndx:"100",srcFldrIndx:"101", mimeType:fileType, documentType:docType, doctypeId,sourceId:"1",sourceName:"EDP"};
        console.log(data);
        try {
          const res = await axios.post(assetsUploadUrl, data,{headers:{"Access-Control-Allow-Origin": "*"}});
          console.log(res.data);
          const MySwal = withReactContent(Swal);
          MySwal.fire({
            title: <p>Succesfully Uploaded</p>,
            didOpen: () => {
              Swal.fire(
                  'Successfully Uploaded',
                  'view path',
                  'success'
                )
            },
           
          }).then(() => {
            return MySwal.fire(<p>Shorthand works </p>)
          }) 
          const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
          closeButton.click();
          
        } catch (error) {
          const MySwal = withReactContent(Swal);
          MySwal.fire({
          title: 'Error Occured!',
          text: error.message,
          icon: 'error',
          });  
        }
        const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
        closeButton.click();
      }
      else if (assetName === "LIABILITIES"){
        const files = [];
        for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        const fileName = file.name;
        const fileType = file.type;
        const bs64Img = convertBase64(file);
        files.push({ fileName, fileType, bs64Img });
        }

        const data = {
        msgBdy: {custId,assetName,docType,docName,files,password,prntFldrIndx: "1",srcFldrIndx: "2",srcNm: "EDP",doctypeId}
        };
        // const data = {msgBdy:{custId, assetName, docType, docName, bs64Img, password,prntFldrIndx:"1",srcFldrIndx:"2", srcNm: "EDP", fileName, fileType, doctypeId}};
        setData(data);
        console.log(data);
        try {
          const res = await axios.post(liabilitiesUploadUrl, data,{headers:{"Access-Control-Allow-Origin": "*"}});
          console.log(res.data);
          const MySwal = withReactContent(Swal);
          MySwal.fire({
          title: <p>Succesfully Uploaded</p>,
          didOpen: () => {
            Swal.fire(
                'Successfully Uploaded',
                'view path',
                'success'
              )
          },
         
        }).then(() => {
          return MySwal.fire(<p>Shorthand works </p>)
        }) 
        const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
        closeButton.click();
        } catch (error) {
          const MySwal = withReactContent(Swal);
          MySwal.fire({
          title: 'Error Occured!',
          text: error.message,
          icon: 'error',
          });
         
        }
        const closeButton = document.querySelector('[data-bs-dismiss="modal"]');
        closeButton.click(); 
        }
    }


   const handleReset = () =>{
      setCustId("");
      setPassword("");
      setAssetName("");
      setDocType("");
      setDocName("");
      setFileName("");
      setBs64Img("");
      setFiles("");
      setHide(false);
     
   }
  return (
    
    <div className='Upload-form'>
       
       <div className="header-button">
        <button type="button"  data-bs-toggle="modal" data-bs-target="#staticBackdrop"  onClick={() => setIsOpen(true)} > <BsUpload fontWeight={200}/> Upload Document
        </button>
      </div>
     
    <div className={`modal fade ${isOpen ? "show" : ""}`} id="staticBackdrop"  data-bs-backdrop="static" data-bs-keyboard="false" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div className="modal-dialog modal-dialog-centered">
    <div className="modal-content">
      <div className="modal-header">
        <h1 className="modal-title fs-5" id="staticBackdropLabel">UPLOAD DOCUMENT</h1>
        <button type="button" className="btn-close close-button" onClick = {handleReset} data-bs-dismiss="modal" aria-label="Close" ></button>
      </div>
      <div className="modal-body">
        <div className="">
            <label htmlFor="" className="form-label">Customer ID<span className='imp'>*</span></label>
            <input type="text" className="form-control shadow-none" id="custId" placeholder="" value={custId}
            onChange = {handleCustId}/>
         </div>
         <div className="">
            <label htmlFor="" className="form-label">Assets / Liabilities<span className='imp'>*</span></label>
            <select className="form-select shadow-none" id="assetLiabId"  value={assetName}
            onChange = {(e) => setAssetName(e.target.value)}>
            <option >None</option>
            <option>ASSETS</option>
            <option>LIABILITIES</option>
      
            </select>
          
          </div>
         <div className="">
          <label htmlFor="" className="form-label">Document Type<span className='imp'>*</span></label>
          <select className="form-select shadow-none" id=""value = {docType} onChange = {(e) => setDocType(e.target.value)}>
          
            <option >None</option>
              {
                selectType.map((type, id) =>{
                  return(
                    <option key = {id} value = {type.doctypename}>{type.doctypename}</option>
                  )
                })
              }
            </select>
          </div>

          <div className="">
            <label htmlFor="" className="form-label">Document Name<span className='imp'>*</span></label>
            <select className="form-select shadow-none" id=""  value ={docName} onChange = {(e) => setDocName(e.target.value)}>
           
            <option>None</option>
              {
                 
                selectName.map((name, id) =>{
                  return(
                      <option key ={id} value={name.documentName}>{name.documentName}</option>
                  )
                })
              }
            
            </select>
          </div>

          <div className="">
            <label htmlFor="" className="form-label">Document Password</label>
            <input type="password" 
            className="form-control shadow-none" 
            id="docPassword"
            value={password}
            onChange = {(e) => setPassword(e.target.value)} placeholder=""/>
         </div>
       
          <div className="browse-file-div" onDragOver={handleDragOver} onDrop={handleDrop}>
            <label className="custom-file-label form-label">
             <input className="custom-file-input"
              type="file" 
              id="fileInput"
              name ="doc"
              onChange = {onChange}/><span className='file-browse' multiple> Browse For Files</span>
           </label>
      
          </div>
          
            {
            hide === true &&
            files.map((file, index) => {
                return (
                <div key={index} className="file-path">
                    <span className="file-name"><InsertDriveFileIcon /> {file.name}</span>
                    <div className="file-progress">
                    <div className="progress">
                        <div className="progress-bar bg-success" style={{width: '100%'}} />
                    </div>
                    <div className="file-size">
                        <span>100%</span> <span>{file.size / 1024} KB</span>
                    </div>
                    </div>
                    <ClearIcon onClick={() => handleFileDelete(index)} />
                </div>
                );
            })
            }
        
       </div>
      <div className="modal-footer">
        <Button className="clear-button" 
           style={{color: 'black',textDecoration:'underline', paddingRight:"10px"}} 
           onClick = {handleReset}>
          Clear
        </Button>
        <div className="header-button pl-3">
          <button type="submit" onClick ={handleSubmit} className="button-upload"><BsUpload fontWeight={200}/> Upload Document</button>
        </div>
     
      </div>
    </div>
  </div>
</div>

   </div>
  )
}
