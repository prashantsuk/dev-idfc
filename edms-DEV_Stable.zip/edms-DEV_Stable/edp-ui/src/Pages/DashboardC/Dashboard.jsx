import React, {useState} from 'react';
import './Dashboard.css';
import AssetsPieChart from '../../Charts/AssetsPieChart';
import AssetsBarChart from '../../Charts/AssetsBarChart';
import LiabilitiesBarChart from '../../Charts/LiabilitiesBarChart';
import LiabilitiesPieChart from '../../Charts/LiabilitiesPieChart';
import SearchIcon from '@mui/icons-material/Search';
import {useNavigate} from 'react-router-dom';


export default function Dashboard() {
  const [isFocused, setIsFocused] = useState(false);
  const navigate = useNavigate();

  {isFocused && (
 
    navigate('/search')
  )}
  return (
    <>
   
    <div className='dashboard'>
     <div className='global-search-box'>
      <div className="global-search">
        <form >
            <button type="submit" disabled ><SearchIcon fontSize ="large"/></button>
            <input type="text" placeholder="Search" onFocus={() => setIsFocused(true)} onBlur={() => setIsFocused(false)} />
        </form>
        
        </div>
        </div>

       <div className="dashboard-metrics">
          <div className="dashboard-assets">
            <div className="dashboard-assetdoughnutchart">
            <AssetsPieChart name="Assets-Pie chart"/>
            </div>
            <div className="dashboard-assetbarchart">
            <AssetsBarChart name="Assets-Bar chart"/>
            </div>
          </div>
          <div className="divider">
            <h1>hello</h1>
          </div>
          <div className="dashboard-liabilities">
            <div className="dashboard-liabilitiesdoughtnutchart">
            <LiabilitiesPieChart name="Liabilities-Pie chart"/>
            </div>
            <div className="dashboard-liabilitiesbarchart">
            <LiabilitiesBarChart name="Liabilities-Bar chart"/>
            </div>
          </div>
       </div> 
      
      
     
     
    </div>
    </>
  )
}
