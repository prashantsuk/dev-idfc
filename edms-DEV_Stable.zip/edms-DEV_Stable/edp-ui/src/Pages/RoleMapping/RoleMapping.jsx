import React from 'react'

function RoleMapping() {
  return (
    <div>RoleMapping</div>
  )
}

export default RoleMapping