import React from 'react'

function AssetsFinnOne() {
  return (
    <div>AssetsFinnOne</div>
  )
}

export default AssetsFinnOne