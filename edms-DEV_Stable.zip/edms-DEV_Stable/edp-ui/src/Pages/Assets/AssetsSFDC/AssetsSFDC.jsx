import React from 'react'

function AssetsSFDC() {
  return (
    <div>AssetsSFDC</div>
  )
}

export default AssetsSFDC