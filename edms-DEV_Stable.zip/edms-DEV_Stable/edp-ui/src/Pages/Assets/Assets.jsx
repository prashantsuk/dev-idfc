import React, {useState} from 'react';
import '../Dashboard/Dashboard.css';
import '../Assets/Assets.css';
import AssetsPieChart from '../../Charts/AssetsPieChart';
import AssetsBarChart from '../../Charts/AssetsBarChart';
import SearchIcon from '@mui/icons-material/Search';
import {useNavigate} from 'react-router-dom';
import { ImageOutlined } from '@mui/icons-material';

export default function Assets() {
  const [isFocused, setIsFocused] = useState(false);
  const navigate = useNavigate();

  {isFocused && (
 
    navigate('/search')
  )}
  return (
    <div className='assets'>
        <div className='global-search-box'>
      <div className="global-search">
        <form >
            <button type="submit" disabled ><SearchIcon fontSize ="large"/></button>
            <input type="text" placeholder="Search" onFocus={() => setIsFocused(true)} onBlur={() => setIsFocused(false)} />
        </form>
        
        </div>
        </div>
        <div className="assets-metrics">
            <div className="dashboard-assets">
            <div className="dashboard-assetdoughnutchart">
            <AssetsPieChart name ="Assets-Pie chart"/>
            </div>
            <div className="dashboard-assetbarchart"> 
            <AssetsBarChart name="Assets-Bar chart"/>
          </div>
          </div> 
        </div>
      
    </div>
  )
}
