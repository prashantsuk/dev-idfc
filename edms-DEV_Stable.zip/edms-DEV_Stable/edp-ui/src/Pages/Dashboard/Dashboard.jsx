import React from 'react';
import './Dashboard.css';
import PieChart from '../../Charts/PieChart';
import BarChart from '../../Charts/BarChart';
import Header from '../../Header/Header';


export default function Dashboard() {
  return (
    <>
   
    <div className='dashboard'>
    <Header/>
      <div className="dashboard-assets">
        <div className="dashboard-assetdoughnutchart">
       <PieChart name="Assets-SFDC"/>
        </div>
        <div className="dashboard-assetbarchart">
         <BarChart name="Assets-Finnone"/>
        </div>
      </div>
      <div className="divider">
        <h1>hello</h1>
      </div>
      <div className="dashboard-liabilities">
        <div className="dashboard-liabilitiesdoughtnutchart">
        <PieChart name="Liabilities-SFDC"/>
        </div>
        <div className="dashboard-liabilitiesbarchart">
        <BarChart name="Liabilities-Trade Finace" url/>
        </div>
      </div>
      
     
     
    </div>
    </>
  )
}
