import React from 'react'

function AuditLog() {
  return (
    <div>AuditLog</div>
  )
}

export default AuditLog