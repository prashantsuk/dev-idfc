import React from 'react'

function LiabilitiesTradeFinance() {
  return (
    <div>LiabilitiesTradeFinance</div>
  )
}

export default LiabilitiesTradeFinance