import React from 'react'

function LiabilitiesSFDC() {
  return (
    <div>LiabilitiesSFDC</div>
  )
}

export default LiabilitiesSFDC