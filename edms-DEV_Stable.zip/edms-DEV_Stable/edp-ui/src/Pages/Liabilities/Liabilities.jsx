import React,{useState} from 'react';
import '../Dashboard/Dashboard.css';
import '../Liabilities/Liabilities.css';
import LiabilitiesBarChart from '../../Charts/LiabilitiesBarChart';
import LiabilitiesPieChart from '../../Charts/LiabilitiesPieChart';
import SearchIcon from '@mui/icons-material/Search';
import {useNavigate} from 'react-router-dom';


export default function Liabilities() {
  const [isFocused, setIsFocused] = useState(false);
  const navigate = useNavigate();

  {isFocused && (
 
    navigate('/search')
  )}
 
  return (
    <>
       <div className='liabilities'>
     <div className='global-search-box'>
      <div className="global-search">
        <form >
            <button type="submit" disabled><SearchIcon fontSize ="large"/></button>
            <input type="text" placeholder="Search" onFocus={() => setIsFocused(true)} onBlur={() => setIsFocused(false)} />
        </form>
        
        </div>
        </div>
          <div className="liabilities-metrics">
            <div className="dashboard-liabilities">
              <div className="dashboard-liabilitiesdoughtnutchart">
                <LiabilitiesPieChart name="Liabilities-Pie chart"/>
              </div>
              <div className="dashboard-liabilitiesbarchart">
              <LiabilitiesBarChart name ="Liabilities-Bar chart"/>
              </div>
          </div>
        </div>
     
       
       
    </div>
    </>
    
  )
}
