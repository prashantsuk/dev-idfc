import React from 'react';
import './SidebarList.css'

function SidebarList({Icon, title, selected}) {
  return (
    <div className={`sidebar-list ${selected && 'sidebar-active'}`}>
     <Icon className="icon-color"/>
     <h3>{title}</h3>
    </div>
  )
}

export default SidebarList