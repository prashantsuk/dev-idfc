import React from 'react';
import { useLocation } from 'react-router-dom';
import './Sidebar.css';
import { NavLink } from 'react-router-dom';
import logoLarge from'../Images/IDFC-logo.svg';
import SearchIcon from '@mui/icons-material/Search';
import GroupWorkIcon from '@mui/icons-material/GroupWork';
import Dashboard from '@mui/icons-material/Dashboard';
import DescriptionIcon from '@mui/icons-material/Description';
import CoPresentIcon from '@mui/icons-material/CoPresent';
import GroupIcon from '@mui/icons-material/Group';
import FindInPageIcon from '@mui/icons-material/FindInPage';
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import SidebarList from './SidebarList';


function Sidebar() {
  const location = useLocation();

  return (
    <div className='sidebar'  >
        <div className="sidebar-container">
         <div className="sidebar_logo">
          <img src={logoLarge} alt="" />
        </div>
        <div className="sidebar_search" >
        {/* <NavLink to ="/search" className="link-color">
            <SearchIcon/>  
              <input type="text" placeholder='SEARCH'/>
        </NavLink> */}
        </div>
        <div className="sidebar_panel">
           <NavLink to ="/search" className="link-color">
            <SidebarList Icon={SearchIcon} title ="Search" selected={location.pathname === '/search'}/>
           </NavLink>
           <NavLink to ="/" className="link-color">
            <SidebarList Icon={Dashboard} title ="DASHBOARD" selected={location.pathname === '/'}/>
           </NavLink>
           <NavLink to ="/assets" className="link-color">
            <SidebarList Icon={GroupWorkIcon} title ="ASSETS" selected={location.pathname === '/assets'} />
           </NavLink>
           <NavLink to ="/liabilities" className="link-color">
            <SidebarList Icon={MonetizationOnIcon} title ="LIABILITIES" selected={location.pathname === '/liabilities'} />
           </NavLink>
           <NavLink to ="/auditLog" className="link-color">
           <SidebarList Icon={FindInPageIcon} title ="AUDIT LOG" selected={location.pathname === '/auditLog'} />
           </NavLink>
            <NavLink to ="/roleMapping" className="link-color">
            <SidebarList Icon={CoPresentIcon} title ="ROLE MAPPING" selected={location.pathname === '/roleMapping'}/>  
            </NavLink>
            <NavLink to ="/reports" className="link-color">
            <SidebarList Icon={DescriptionIcon} title ="REPORTS" selected={location.pathname === '/reports'} />
            </NavLink>
            <NavLink to="/users" className="link-color">
            <SidebarList Icon={GroupIcon} title ="USERS" selected={location.pathname === '/users'}/>
            </NavLink>
        </div>
    </div> 
      
    </div>
  )
}

export default Sidebar


