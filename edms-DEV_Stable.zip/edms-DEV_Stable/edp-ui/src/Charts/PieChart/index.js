import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ReactEcharts from "echarts-for-react";
import './index.css';


const PieChart = (props) => {
    const pieChartUrl = props.url;
    const [data, setData] = useState([]);

    useEffect(() => {
        const fetchPieChartData = async () => {
            try {
                const response = await axios.get(pieChartUrl);
                setData(response.data);
                console.log(response.data);
                
            } catch (error) {
                console.log(error);
            }
        };

        fetchPieChartData();
    }, []);

    const option = {
        title: {
            text: props.name,
            left: 'left'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        
        // legend: {
        //     bottom: 5,
        //     left: 'center',
        //     data: ['SFDC', 'Finnone', 'Optimus', 'BR.Net', 'BPM']
        // },
        series: [
            {
                name: 'Assets',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
               
                emphasis: {
                    label: {
                        show: false,
                        fontSize: 40,
                        fontWeight: 'bold'
                    }
                },
              
                label: {
                    show: true,
                    position: 'outside',
                    fontSize:'10px',
                    formatter: '{b} \n {d}%'
                },
                labelLine: {
                    show: false,
                    length: 10,
                    length2: 5
                },
               
               
                data: [
                    {
                        value: 1045, name: 'SFDC', itemStyle: {
                            color: '#43BCCD',
                        }
                    },
                    {
                        value: 735, name: 'Finnone', itemStyle: {
                            color: '#9D1D27'
                        }
                    },
                    {
                        value: 300, name: 'BPM', itemStyle: {
                            color: '#43BCCD'
                        }
                    },
                    {
                        value: 580, name: 'Optimus', itemStyle: {
                            color: '#F9C82E'
                        }
                    },
                    {
                        value: 676, name: 'BR.Net', itemStyle: {
                            color: '#F9C82E'
                        }
                    },
                ]

                // data: [
                //     {
                //       value: data.map(item => item.value),
                //       name: data.map(item => item.name),
                //       itemStyle: { color: ['#43BCCD','#9D1D27','#43BCCD','#F86624','#F9C82E']}
                //     }
                //   ]
                  
                
            }
        ]
    };

    return (
        <div className='chart-container'>
            <ReactEcharts option={option} style={{ width: '100%', height: '100%' }} />
        </div>
    );
}

export default PieChart;