import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ReactEcharts from "echarts-for-react";
import './index.css';

const BarChart = (props) => {
    const barChartUrl = "";
    const [data, setData] = useState([]);

    useEffect(() => {
        const fetchBarChartData = async () => {
            try {
                const response = await axios.get(barChartUrl);
                setData(response.data);
            } catch (error) {
                console.log(error);
            }
        };

        fetchBarChartData();
    }, []);

    const option = {
        title: {
            text: props.name,
            left: 'left'
          },
        tooltip: {
            trigger: 'item'
        },
        xAxis: {
            type: 'category',
            data: ['SDFC', 'Finning', 'Optimus', 'BR.Net', 'BPM']
            // data: data.map(item => item.name)
        },
        yAxis: {
            type: 'value',
        },
        series: [
            {
                data: [
                    {
                        value: 10,
                        itemStyle: {
                            color: '#43BCCD',
                        }
                    },
                    {
                        value: 20,
                        itemStyle: {
                            color: '#9D1D27'
                        }
                    },
                    {
                        value: 40,
                        itemStyle: {
                            color: '#F86624'
                        }
                    },
                    {
                        value: 60,
                        itemStyle: {
                            color: '#F9C82E'
                        }
                    },
                    {
                        value: 80,
                        itemStyle: {
                            color: '#43BCCD'
                        }
                    },
                ],
                  // data: [
                //     {
                //       value: data.map(item => item.value),
                //       itemStyle: { color: ['#43BCCD','#9D1D27','#43BCCD','#F86624','#F9C82E']}
                //     }
                //   ],
                  
                type: 'bar',
                barWidth: 22,
        // barGap: 0.1,
        // barCategoryGap: 0.2
            }
        ]
    };

    return (
        <div className='chart-container'>
            <ReactEcharts option={option} theme={'my_customised_theme'} style={{ width: '100%', height: '100%' }} />
        </div>
    );
}

export default BarChart;