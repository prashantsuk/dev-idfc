import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ReactEcharts from "echarts-for-react";
import './index.css';


const AssetsPieChart = (props) => {
    const pieChartUrl = "http://52.140.58.184:9414/msDashBoardMetrics/getAssetsMetrics";
    const [data, setData] = useState([]);

    useEffect(() => {
        const fetchPieChartData = async () => {
            try {
                const response = await axios.get(pieChartUrl);
                setData(response.data);
                console.log(response.data);
               
                
            } catch (error) {
                console.log(error);
            }
        };

        fetchPieChartData();
    }, []);

    const option = {
        title: {
            text: props.name,
            left: 'left'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        
        // legend: {
        //     bottom: 5,
        //     left: 'center',
        //     data: ['SFDC', 'Finnone', 'Optimus', 'BR.Net', 'BPM']
        // },
        series: [
            {
                name: 'Assets',
                type: 'pie',
                radius: ['40%', '70%'],
                avoidLabelOverlap: false,
               
                emphasis: {
                    label: {
                        show: false,
                        fontSize: 40,
                        fontWeight: 'bold'
                    }
                },
              
                label: {
                    show: true,
                    position: 'outside',
                    fontSize:'10px',
                    formatter: '{b} \n {d}%'
                },
                labelLine: {
                    show: false,
                    length: 10,
                    length2: 5
                },
                // data.filter(item => item.sourceName === 'SFDC')
               
                // data: data.map(item => ({
                //     value: item.percentage,
                //     name: item.sourceName,
                //     itemStyle: {
                //         color: ['#43BCCD','#9D1D27','#F86624','#F9C82E','#F86624'][data.indexOf(item)]
                //     }
                // }))
                data: data
                .filter(item => item.percentage !== 0)
                .map(item => ({
                    value: item.percentage,
                    name: item.sourceName,
                    itemStyle: {
                    color: ['#43BCCD','#9D1D27','#F86624','#F9C82E','#F86624'][data.indexOf(item)]
                    }
                }))

                  
            }
        ]
    };

    return (
        <div className='chart-container'>
            <ReactEcharts option={option} style={{ width: '100%', height: '100%' }} />
     
        </div>
    );
}

export default AssetsPieChart;