import React, { useState, useEffect } from 'react';
import axios from 'axios';
import ReactEcharts from "echarts-for-react";
import './index.css';

const AssetsBarChart = (props) => {
    const barChartUrl = "http://52.140.58.184:9414/msDashBoardMetrics/getAssetsMetrics";
    const [data, setData] = useState([]);

    useEffect(() => {
        const fetchBarChartData = async () => {
            try {
                const response = await axios.get(barChartUrl);
                setData(response.data);
                console.log(response.data);
            } catch (error) {
                console.log(error);
            }
        };

        fetchBarChartData();
    }, []);

    const option = {
        title: {
            text: props.name,
            left: 'left'
          },
        tooltip: {
            trigger: 'item'
        },
        xAxis: {
            // data: ['SDFC', 'Finning', 'Optimus', 'BR.Net', 'BPM']
           
            // data: data.map(item => item.sourceName)
           
                type: 'category',
                data: data.filter(item => item.percentage !== 0).map(item => item.sourceName)
        
        },
        yAxis: {
            type: 'value'
        },
        
        
        series: [
            {
                data: data.filter(item => item.percentage !== 0).map(item => ({
                    value: item.percentage,
                    itemStyle: {
                        color: ['#43BCCD','#9D1D27','#F86624','#F9C82E','#F86624'][data.indexOf(item)]
                    }
                })),
                type: 'bar',
                barWidth: 22
            }
        ]
    };

    return (
        <div className='chart-container'>
            <ReactEcharts option={option} theme={'my_customised_theme'} style={{ width: '100%', height: '100%' }}  />
           
        </div>
    );
}

export default AssetsBarChart;