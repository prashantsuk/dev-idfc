import { createSlice } from '@reduxjs/toolkit';


export const userDataSlice = createSlice({
  name: 'userdata',
  initialState:{
    userData: {userName:localStorage.getItem('userName') || "", userRole:localStorage.getItem('userRole') || ""}
  },
 
  reducers: {
    loginUserData: (state, action) => {
      state.userData = {
        
          userName: action.payload.userName,
          userRole: action.payload.userRole
        
      };
      localStorage.setItem('userName', action.payload.userName);
      localStorage.setItem('userRole', action.payload.userRole);
    }
   
  },

});

export const { loginUserData} = userDataSlice.actions;

export const selectSetUserData = (state) => state.userdata.userData;

export default userDataSlice.reducer;
