import React, { useState, useRef } from 'react';
import axios from 'axios';
import './Login.css';
import logo from '../Images/logo.svg';
import mobileweb from '../Images/mobileweb.svg';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { loginUserData } from '../features/userDataSlice';
import Box from '@mui/material/Box';
import Input from '@mui/material/Input';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';

const ariaLabel = { 'aria-label': 'description' };


export default function Login({ setShowLogin }) {
  const loginUrl = "http://52.140.58.184:9414/msUserManagement/user/login";
  //  const loginUrl = 'https://jsonplaceholder.typicode.com/posts';
  const dispatch = useDispatch();
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [usernameError, setUsernameError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);

  // empty field error
  const handleUserNameError = () => {
    if (username === '') {
      setUsernameError(true);
    } else {
      setUsernameError(false);
    }
  }

  const handlePasswordError = () => {
    if (password === '') {
      setPasswordError(true);
    } else {
      setPasswordError(false);
    }
  }
  const navigate = useNavigate();

  const usernameRef = useRef(null);
  const passwordRef = useRef(null);

  const setSessionToken = (token) => {
    localStorage.setItem('sessionToken', token);
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    console.log(username, password);
    if (username === '') {
      setUsernameError(true);
      return; // Stop form submission
    }  else if(password === ''){
      setPasswordError(true);
      return;
    }

    const loginData = { userId: username, currPasswd: password };
    const response = await axios.post(loginUrl, loginData, { headers: { "Access-Control-Allow-Origin": "*" } });
    console.log(response.data);
    console.log(response.data.userName, response.data.roleNames)
    console.log(response.data.sessionToken);

    dispatch(loginUserData({ userName: response.data.userName, userRole: response.data.roleNames }));

    if (response.data.isValidUser === false) {
      console.log(`user id and password does not match`);
      const panel = document.querySelector('.hide-panel');
      panel.style.display = "block";
      setUsername("");
      setPassword("");
      usernameRef.current.value = "";
      passwordRef.current.value = "";
    } else {
      setShowLogin(false);
      navigate('/');
      setSessionToken(response.data.userName);
    }

  }


  
  return (

    <div className='login-page'>
      <div className="bg-black">
        <div className="image-bg">
          <button type="button" className="btn edp-button"><strong>Enterprise Document Portal</strong>
            <p>Manage your documents easily!</p>
          </button>

          <img src={mobileweb} alt="loginPage" />
        </div>
      </div>
      <div className="bg-red">


        <div className="login-page-section">
          <div className="login-form">
            <img className="logo-img" src={logo} alt="" />
            <h3>LOGIN</h3>
            <p className='welcome-text'>Welcome back! Please login to your account</p>
            < div className='hide-panel' style={{ display: "none" }}>
              <p>Sorry unable to login, Please check your ID, Password</p>
            </div>
            <form className="form-style" action=" " onSubmit={handleSubmit}>
              <p className='get-started-text'>Let's get started</p>
              <div className="mb-4">
                <div className="input-group">
                  {/* <input type="text" className="form-control form-control-sm" placeholder="User ID" onChange={(e) => setUsername(e.target.value)} id="Email" autoCapitalize='off' autoComplete='true' required ref={usernameRef} /> */}
                  <Box
                    component="form"
                    sx={{
                      '& > :not(style)': { m: -1 },
                      '& .MuiInputBase-root:focus': {
                        borderColor: 'yellow !important',
                      },
                    }}
                    noValidate
                  >
                    <Input sx={{ fontSize: "1.3rem" }} className={`form-control shadow-none ${usernameError ? 'border-danger' : ''}`} placeholder="User ID" inputProps={ariaLabel} onChange={(e) => setUsername(e.target.value)} value={username} id="Email" autoCapitalize='off' autoComplete='true' required ref={usernameRef} />
                    {usernameError && <div className="text-danger align-right" style={{paddingTop:'15px', paddingRight:'15px'}}> *Please enter User ID</div>}
                  </Box>
                </div>
              </div>
              <div className="mb-2">
                <div className="input-group">
                  {/* <input type="password" className="form-control" placeholder="Password" onChange={(e) => setPassword(e.target.value)} id="Password" autoCapitalize='off' autoComplete='true' required ref={passwordRef} /> */}
                  <Box
                    component="form"
                    sx={{
                      '& > :not(style)': { m: -1 },
                    }}
                    noValidate
                  >
                    <Input sx={{ fontSize: "1.3rem"}} type="password" className={`form-control shadow-none ${passwordError ? 'border-danger' : ''}`} placeholder="Password" inputProps={ariaLabel} onChange={(e) => setPassword(e.target.value)}  value={password}id="Password" autoCapitalize='off' autoComplete='true' required ref={passwordRef} />
                    {passwordError && <div className="text-danger align-right" style={{paddingTop:'15px', paddingRight:'15px'}}> *Please enter Password</div>}
                  </Box>
                </div>
                <div className="form-check" style={{ visibility: "Hidden" }}>
                  <input className="form-check-input" type="checkbox" value="" id="flexCheckDefault" /> Remember me
                  <span className="form-text">Forgot Password</span>
                </div>

              </div>
              <div className=' '>
                {/* <button type="submit" className="btn btn-danger login-button">Login</button> */}
                <Stack spacing={2} direction="row">
                  <Button 
                   type="submit" className="btn btn-danger login-button" variant="contained">Login</Button>
                </Stack>
              </div>
            </form>
          </div>
        </div>

      </div>
    </div>
  )
}

