import React, {useState, useEffect} from 'react';
import axios from 'axios';
import './Search.css';
import SearchIcon from '@mui/icons-material/Search';
import SearchResultTable from '../Component/SearchResultTable';
import img from '../Images/searchrecord.png';
import image from '../Images/norecordfound.png'

export default function Search() {
   const [searchError, setSearchError] = useState(false);
    const [searchQuery, setSearchQuery] = useState("");
    // const [searchType, setSearchType] = useState('select');
    const [searchResults, setSearchResults] = useState([]);
    const[resMsg, setResMsg] = useState("");
    const [show, setShow] = useState(true);
    const[hide, setHide] = useState(false);
    const[showNoRecord, setShowNoRecord] = useState(false);
    const [tabs,setTabs] = useState([]);
    const [products,setProducts] = useState([]);


    const handleSearchCriteria = (e) =>{
      const numberRegExp = new RegExp(/^\d{0,16}$/);
      const Id = e.target.value;
      if(numberRegExp.test(Id) && Id >= 0){
        setSearchQuery(Id);
        console.log(Id);
      }
    }
  
    const handleSubmit = async (event) => {
      event.preventDefault();
      if(searchQuery===""){
        // alert("“Please enter Customer ID/Agreement ID/UCIC No/Mobile No");
        setSearchError(true);
      }
      else {
        // const response = await axios.get(`https://jsonplaceholder.typicode.com/posts?searchId=${searchQuery}`);
        const response = await axios.get('http://52.140.58.184:9414/msSearchData/searchData?searchId='+searchQuery,{headers:{"Access-Control-Allow-Origin": "*"}});
        setSearchResults(response.data.documentDataList);
        let uniqueSource = [...new Set(response.data.documentDataList?.map(item => item.source))];
        uniqueSource.push("ALL DOCUMENTS")
        setTabs(uniqueSource)
        let productsList = [...new Set(response.data.documentDataList?.map(item => item.productName))];
        setProducts(productsList);
        console.log(response.data.message);
        setResMsg(response.data.message);
        // setSearchQuery('');
        setHide(true)
        setShow(false);
        setSearchError(false);
        if(response.data.message === `Your Search-${searchQuery}-Did not match any document`){
          console.log(`Your Search-${searchQuery}-Did not match any document`)
           setShowNoRecord(true);
           setHide(false)
           setShow(false);
           setSearchError(false);
        }
      }
    }
    useEffect(() => {

        handleSubmit(); 
    },[])
  
  return (
    <div className='search-result-global'>
         <div className='global-search-box'>
          <div className="global-search">
            <form onSubmit={handleSubmit}>
                <button type="submit" ><SearchIcon fontSize ="large"/></button>
                <input type="text" autoFocus name = "searchvalue" value={searchQuery} onChange={handleSearchCriteria} placeholder="Search" />
                
                  {/* <p className='error-message'>*Please enter Customer ID/Agreement ID/UCIC No/Mobile No</p> */}
              
                {/* <select value={searchType} className = "select-any" onChange={event => setSearchType(event.target.value)}>
                  <option value="select" disabled className='first-option'>Select Any</option>
                  <option value="userId">Customer ID</option>
                  <option value="agreementId">Agreement ID</option>
                  <option value="ucicNo">UCIC No</option>
                  <option value="mobileNo">Mobile No</option>
                </select> */}
                {searchError && <div className="search-error-field text-danger align-right"> *Please enter Customer ID/Agreement ID/UCIC No/Mobile No</div>}
            </form>
         </div>
        </div>
     {
      show && 
      <div className="search-record">
       <img src={img} alt="search for record"/>
      </div>
     }

     { hide ? 
      <SearchResultTable data={searchResults} activetabs={tabs} productListItems={products}/>
      : 
      showNoRecord && 
      <div className="no-search-record">
        <p>{resMsg}</p>
       <img src={image} alt="search for record"/>
      </div>
     }
    </div>
  )
}
