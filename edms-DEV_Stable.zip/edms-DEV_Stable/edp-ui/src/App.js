import React, {useState} from 'react';
import './App.css';
import Sidebar from './Sidebar/Sidebar.jsx';
import {
  BrowserRouter as Router,
  Routes,
  Route
} from "react-router-dom";
// import Dashboard from './Pages/Dashboard/Dashboard';
import Dashboard from './Pages/DashboardC/Dashboard';
import Assets from './Pages/Assets/Assets';
import AssetsFinnOne from './Pages/Assets/AssetsFinnOne/AssetsFinnOne';
import AssetsSFDC from './Pages/Assets/AssetsSFDC/AssetsSFDC';
import Liabilities from './Pages/Liabilities/Liabilities';
import LiabilitiesSFDC from './Pages/Liabilities/LiabilitiesSFDC/LiabilitiesSFDC';
import LiabilitiesTradeFinance from './Pages/Liabilities/LiabilitiesTradeFinance/LiabilitiesTradeFinance';
import AuditLog from './Pages/AuditLog/AuditLog';
import RoleMapping from './Pages/RoleMapping/RoleMapping';
import Reports from './Pages/Reports/Reports';
import Users from './Pages/Users/Users';
import Search from './Search/Search';
import Header from './Header/Header';
import Login from './Loginn/Login';



function App() {
  const[showLogin, setShowLogin] = useState(!localStorage.getItem("sessionToken"));

  return (
    <div className="App">
     
      <Router>
        {
          showLogin ? 
          <Login showLogin={showLogin} setShowLogin={setShowLogin} />
           : (

           <div className="app-body">
           <Sidebar className="side-bar" id ="sidebar"/>

            <div className="app-pages">
            <Header showLogin={showLogin} setShowLogin={setShowLogin} />
             <Routes> 
                {/* <Route path ="/" element ={<Dashboard/>}/> */}
                <Route path="/login" element={<Login showLogin={showLogin} setShowLogin={setShowLogin} />} />
                <Route path="/" element = {<Dashboard/>} />
                <Route path ="/assets" element ={<Assets/>}/>
                <Route path ="/assets/FinnOne" element ={<AssetsFinnOne/>}/>
                <Route path ="/assets/SFDC" element ={<AssetsSFDC/>}/>
                <Route path ="/liabilities" element ={<Liabilities/>}/>
                <Route path ="/liabilities/SFDC" element ={<LiabilitiesSFDC/>}/>
                <Route path ="/liabilities/TradeFinance" element ={<LiabilitiesTradeFinance/>}/>
                <Route path ="/auditLog" element ={<AuditLog/>}/>
                <Route path ="/roleMapping" element ={<RoleMapping/>}/>
                <Route path ="/reports" element ={<Reports/>}/>
                <Route path ="/users" element ={<Users/>}/>
                <Route path ="/search" element ={<Search/>}/> 
             </Routes> 
            </div>  
          
           </div> 
               
            )
         }  
            
      </Router>
     
      
    </div>
  );
}

export default App;
