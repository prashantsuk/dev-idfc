package com.edms.repository;

import org.springframework.data.aerospike.repository.AerospikeRepository;
import org.springframework.stereotype.Repository;

import com.edms.domain.PDBFolderEntity;


@Repository
public interface PDBFolderRepo extends AerospikeRepository<PDBFolderEntity,Integer> {

	PDBFolderEntity findByName(String name);
}
