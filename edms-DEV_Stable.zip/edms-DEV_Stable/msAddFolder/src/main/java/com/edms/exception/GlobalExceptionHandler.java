package com.edms.exception;

import java.io.IOException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.edms.model.Actn;
import com.edms.model.ErrorModel;
import com.edms.model.MsgHdr;
import com.edms.model.Srvc;
import com.edms.model.downloadDMSDocResp;
import com.edms.util.Constants;

import lombok.extern.slf4j.Slf4j;


@RestControllerAdvice
@Slf4j
public class GlobalExceptionHandler {
	
	  @ExceptionHandler 
	  public ResponseEntity<downloadDMSDocResp> userException(UserException ex) {
	   log.error("Exception occured: {}",ex);
		Actn actn=Actn.builder().nm("addFolder").paradigm("Reply").vrsn("1.0.0").build();
		Srvc srvc=Srvc.builder().ActnObject(actn).cntxt("doc-mgmt").nm("doc-mgmt").build();
		  
		ErrorModel error=ErrorModel.builder().cd(Constants.EXP_500).rsn(ex.getMessage()).SrvcObject(srvc).build();

		MsgHdr msgHdr=MsgHdr.builder().error(error).rslt(Constants.ERROR).build();
			 
		downloadDMSDocResp responseMsg=downloadDMSDocResp.builder().msgHdr(msgHdr).build();
		  
		return new ResponseEntity<downloadDMSDocResp>(responseMsg,HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	  
	  
	  @ExceptionHandler 
	  public ResponseEntity<downloadDMSDocResp> iOException(IOException ex) {
	    log.error("Exception occured: {}",ex);
		Actn actn=Actn.builder().nm("addFolder").paradigm("Reply").vrsn("1.0.0").build();
		Srvc srvc=Srvc.builder().ActnObject(actn).cntxt("doc-mgmt").nm("doc-mgmt").build();
		  
		ErrorModel error=ErrorModel.builder().cd(Constants.EXP_500).rsn(ex.getMessage()).SrvcObject(srvc).build();

		MsgHdr msgHdr=MsgHdr.builder().error(error).rslt(Constants.ERROR).build();
			 
		downloadDMSDocResp responseMsg=downloadDMSDocResp.builder().msgHdr(msgHdr).build();
		  
		return new ResponseEntity<downloadDMSDocResp>(responseMsg,HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	  
	  @ExceptionHandler 
	  public ResponseEntity<downloadDMSDocResp> HttpRequestMethodNotSupportedException(org.springframework.web.HttpRequestMethodNotSupportedException ex) {

		log.error("Exception occured: {}",ex);
		Actn actn=Actn.builder().nm("addFolder").paradigm("Reply").vrsn("1.0.0").build();
		Srvc srvc=Srvc.builder().ActnObject(actn).cntxt("doc-mgmt").nm("doc-mgmt").build();
		  
		ErrorModel error=ErrorModel.builder().cd(Constants.EXP_405).rsn(ex.getMessage()).SrvcObject(srvc).build();

		MsgHdr msgHdr=MsgHdr.builder().error(error).rslt(Constants.ERROR).build();
			 
		downloadDMSDocResp responseMsg=downloadDMSDocResp.builder().msgHdr(msgHdr).build();
		  
		return new ResponseEntity<downloadDMSDocResp>(responseMsg,HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	  
	  @ExceptionHandler 
	  public ResponseEntity<downloadDMSDocResp> commonException(Exception ex) {
			 
		log.error("Exception occured: {}",ex);
		Actn actn=Actn.builder().nm("addFolder").paradigm("Reply").vrsn("1.0.0").build();
		Srvc srvc=Srvc.builder().ActnObject(actn).cntxt("doc-mgmt").nm("doc-mgmt").build();
			  
		ErrorModel error=ErrorModel.builder().cd(Constants.EXP_500).rsn(ex.getMessage()).SrvcObject(srvc).build();

		MsgHdr msgHdr=MsgHdr.builder().error(error).rslt(Constants.ERROR).build();
			 
		downloadDMSDocResp responseMsg=downloadDMSDocResp.builder().msgHdr(msgHdr).build();
		
		return new ResponseEntity<downloadDMSDocResp>(responseMsg,HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	 
}
