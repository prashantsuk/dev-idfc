package com.edms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class MsgBdy {

	//Request
	
//	@NotNull(message = "docName is mandatory")
	private String dcNm;
	private String docName;
	private String fldrNm;
	private String prntFldrIndx;
	private String srcFldrIndx;
	private String custId;
	private String docType;
	private String fileName;
	
	//@NotNull(message = "Image is mandatory")
	private String bs64Img;
	
	//@NotNull(message = "sourceName is mandatory")
	private String srcNm;
	
	//@NotNull(message = "dataDefCriterionObject is missing")
	private DataDefCriterion dataDefCriterion;
	
	//Response
	private String dcIndx;
	private String sts;
	private String msg;
	private String bs64Doc;
	private String docIndx;
	private String isIndx;
	private String fldrIndx;
	private DocumentData documentData;
	private String path;

}
