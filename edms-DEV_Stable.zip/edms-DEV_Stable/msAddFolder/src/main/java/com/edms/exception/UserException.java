package com.edms.exception;

import lombok.Data;

@Data
public class UserException extends Exception{
	
	
	private String msg,methodName;
	
	public UserException(String msg,String methodName) {
		super(msg);
		msg=msg;
		methodName=methodName;
	}

}
