package com.edms.resource;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edms.exception.UserException;
import com.edms.model.AddFolderReq;
import com.edms.model.AddFolderResp;
import com.edms.service.liabilities.AddFolderService;

@RestController
@RequestMapping("/addFolder")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AddFolderController {
	
	@Autowired
	AddFolderService addFolderService;

	@PostMapping("/liabilities")
	public AddFolderResp addFolder(@Valid @RequestBody AddFolderReq addFolderReq) throws UserException
	{
		return addFolderService.addFolder(addFolderReq);
	}
	
	@PostMapping("/liabilities/new")
	public AddFolderResp addFolderLiabilities(@Valid @RequestBody AddFolderReq addFolderReq) throws UserException
	{
		return addFolderService.addFolderLiabilities(addFolderReq);
	}
	
}
