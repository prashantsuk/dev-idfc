package com.edms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FolderMsgBody {
	
	private String parentFldrIndx;
	private String srcFldrIndx;
	private String custId;
	private String docType;
	private String docName;
	private String sourceName;
	private String productType;
	
	//@NotNull(message = "dataDefCriterionObject is missing")
	private DataDefCriterion dataDefCriterion;

}
