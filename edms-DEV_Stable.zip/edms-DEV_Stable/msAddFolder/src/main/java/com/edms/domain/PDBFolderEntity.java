package com.edms.domain;



import org.springframework.data.aerospike.mapping.Document;
import org.springframework.data.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Document(collection = "PDBFolder")
public class PDBFolderEntity {

	@Id
	private int folderIndex;
	
	private int parentFldrInd;
	private String name;
	private String owner;
	private String createdDate;
	private String revisedDate;
	private String accessedDate;
	private String dataDefIndx;
	private String accessType;
	private int imageVolIndx;
	private String folderType;
	private String folderLock;
	private String lockByUser;
	private String location;
	private String deletedDate;
	private String enableVersion;
	private String expiryDate;
	private String commit;
	private String usefulData;
	private String acl;
	private String finalizedFlag;
	private String finalizedDate;
	private String finalizedBy;
	private String aclMoreFlag;
	private String mainGroupId;
	private String enableEfts;
	private String lockMessage;
	private String folderLevel;
	private String ownerInherit;
	private String enableSecure;
	private String revisedBy;
	private String ownerType;
	private String estimestamp;
	private String esindexTime;
	private String esFlag;
}
