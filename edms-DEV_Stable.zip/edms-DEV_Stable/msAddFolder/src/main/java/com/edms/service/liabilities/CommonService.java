package com.edms.service.liabilities;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.edms.model.MsgBdy;
import com.edms.model.MsgHdr;

@Service
public class CommonService {
	
	@Value("${fileLocation}")
	private String fileLocation;

	public MsgBdy setMessageBody(String msg,String sts,String fldrIndx,String path) {
		
		return MsgBdy.builder().msg(msg).sts(sts).docIndx(null).fldrIndx(fldrIndx).path(path).build();
	}
	
	
	public MsgHdr setMessageHeader(String rslt) {
		
		return MsgHdr.builder().rslt(rslt).build();
	}
	
}
