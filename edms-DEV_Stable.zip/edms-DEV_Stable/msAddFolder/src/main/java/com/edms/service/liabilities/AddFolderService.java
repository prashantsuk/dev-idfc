package com.edms.service.liabilities;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.edms.domain.PDBFolderEntity;
import com.edms.exception.UserException;
import com.edms.model.AddFolderReq;
import com.edms.model.AddFolderResp;
import com.edms.repository.PDBFolderRepo;

import lombok.extern.slf4j.Slf4j;

import static com.edms.util.Constants.*;

import java.io.File;
import java.util.Date;
import java.util.Optional;

@Service
@Slf4j
public class AddFolderService {
	
	@Value("${fileLocation}")
	private String fileLocation;
	
	@Autowired
	CommonService commonService;
	
	@Autowired
	PDBFolderRepo pdbFolderRepo;
	
	@Transactional
	public AddFolderResp addFolder(AddFolderReq folderReq) throws UserException {
		
		log.info("Add folder method started");
		
			Optional<PDBFolderEntity> parentFldrOpt=pdbFolderRepo.findById(Integer.parseInt(folderReq.getMsgBdy().getParentFldrIndx()));
			
			if(!parentFldrOpt.isPresent())
				throw new UserException("Parent folder not found","addFolder");	
			
			Optional<PDBFolderEntity> srcFldrOpt=pdbFolderRepo.findById(Integer.parseInt(folderReq.getMsgBdy().getSrcFldrIndx()));
			
			if(!srcFldrOpt.isPresent())
				throw new UserException("Source folder not found","addFolder");	
			
			if(srcFldrOpt.get().getParentFldrInd()!=parentFldrOpt.get().getFolderIndex())
				throw new UserException("Parent folder index and source folder index doesnt not match","addFolder");
			
			
			//New folder location as combination of Parent_Source_CustomerID_DocumentType		
	
			String folderName= srcFldrOpt.get().getName()+"_"+folderReq.getMsgBdy().getCustId()+"_"+folderReq.getMsgBdy().getDocType();
			String folderLoc= srcFldrOpt.get().getLocation()+"/"+folderName;
			
			//have to search if folder already exists in db
			PDBFolderEntity ent=pdbFolderRepo.findByName(folderName);
			if(ent!=null)
				throw new UserException("Folder already exists","addFolder");
			
			
			PDBFolderEntity pdbFolderEntity=PDBFolderEntity.builder().parentFldrInd(srcFldrOpt.get().getFolderIndex()).name(folderName).owner("11026").
					createdDate(new Date().toString()).revisedDate(new Date().toString()).accessedDate(new Date().toString()).
					dataDefIndx(null).accessType("S").imageVolIndx(1).folderType("G").
					folderLock("N").lockByUser("").location(folderLoc).deletedDate("").enableVersion("N").expiryDate(new Date().toString()).
					commit("New folder created").usefulData("").acl("").finalizedFlag("N").finalizedDate(new Date().toString()).finalizedBy("0").aclMoreFlag("N").
					mainGroupId("0").enableEfts("N").lockMessage("").folderLevel("4").ownerInherit("N").enableSecure("N").revisedBy("11026").
					ownerType("U").estimestamp("N").esindexTime("").esFlag("N").folderIndex((int) pdbFolderRepo.count()+1) .build();
			
			File directory=new File(folderLoc);
			
			if(!directory.exists())
				directory.mkdir();
	
			else
				throw new UserException("Folder already exists","addFolder");
			
			pdbFolderRepo.save(pdbFolderEntity);
			
			return AddFolderResp.builder().msgBdy(commonService.setMessageBody( ADD_FOLDER_SUCCESS, "0",String.valueOf(pdbFolderEntity.getFolderIndex()),folderLoc)).
					msgHdr(commonService.setMessageHeader(OK)).build();
	}
	
	
	@Transactional
	public AddFolderResp addFolderLiabilities(AddFolderReq folderReq) throws UserException {
		
			log.info("Add folder method started");

			String folderLoc= fileLocation+folderReq.getMsgBdy().getCustId();
				
			File directory=new File(folderLoc);
			
			if(!directory.exists())
				directory.mkdirs();
			log.info("New folder created with location : {}",folderLoc);
	
//			else
//				throw new UserException("Folder already exists","addFolder");
			
			return AddFolderResp.builder().msgBdy(commonService.setMessageBody( ADD_FOLDER_SUCCESS, "0","0",folderLoc)).
					msgHdr(commonService.setMessageHeader(OK)).build();
	}
	
}