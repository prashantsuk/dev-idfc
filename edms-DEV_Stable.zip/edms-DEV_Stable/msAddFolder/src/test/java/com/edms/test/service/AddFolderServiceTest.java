package com.edms.test.service;

import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import com.edms.repository.PDBFolderRepo;
import com.edms.service.liabilities.CommonService;

@RunWith(MockitoJUnitRunner.class)
public class AddFolderServiceTest {

	@Mock
	CommonService commonService;
	
	@Mock
	PDBFolderRepo pdbFolderRepo;
	
	
	
}
