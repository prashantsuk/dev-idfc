package com.edms.service;

import com.edms.entity.EdpDocRoleMapping;
import com.edms.repository.EdpDocRoleMappingRepository;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@MicronautTest
public class EdpDocRoleMappingServiceTest {

    @Inject
    EdpDocRoleMappingRepository edpDocRoleMappingRepository;

    @Inject
    EdpDocRoleMappingServiceImpl edpDocRoleMappingServiceImpl;


    EdpDocRoleMapping edpDocRoleMapping = null;

    List<EdpDocRoleMapping> edpDocRoleMappingList = new ArrayList<>();

    Set<String> roleAndDocSet = new HashSet<>();

    @MockBean(EdpDocRoleMappingRepository.class)
    public EdpDocRoleMappingRepository edpDocRoleMappingRepository(){return mock(EdpDocRoleMappingRepository.class);}

    @BeforeEach
    public void setUp() {
        roleAndDocSet.add("data");
        edpDocRoleMapping = new EdpDocRoleMapping();
        edpDocRoleMapping.setDocRoleName("Operator");
        edpDocRoleMapping.setPk(01);
        edpDocRoleMapping.setDocTypeName("Loan App");
        edpDocRoleMapping.setIsView("Y");
        edpDocRoleMapping.setCreatedBy("USER");
        edpDocRoleMapping.setCreatedDate("2023-03-15");
        edpDocRoleMapping.setIsWrite("N");
        edpDocRoleMapping.setProductName("product");
        edpDocRoleMapping.setProductId(123l);
        edpDocRoleMappingList.add(edpDocRoleMapping);
    }

    @Test
    void getEdpDocRoleMappingsByFilterTestWithoutParams(){
        when(edpDocRoleMappingRepository.findAll()).thenReturn(edpDocRoleMappingList);
        assertEquals(edpDocRoleMappingList.size(), edpDocRoleMappingServiceImpl.getEdpDocRoleMappingsByFilter(null, null).size());
    }

    @Test
    void getEdpDocRoleMappingsByFilterTestWithParams(){
        when(edpDocRoleMappingRepository.getEdpDocRoleMappingsByFilter(anyString(), anyString())).thenReturn(edpDocRoleMappingList);
        assertEquals(edpDocRoleMappingList.size(), edpDocRoleMappingServiceImpl.getEdpDocRoleMappingsByFilter("test", "test").size());
    }

    @Test
    void getEdpDocRoleMappingsByFilterTestWithDocRoleParams(){
        when(edpDocRoleMappingRepository.getEdpDocRoleMappingsByFilter(anyString(), anyString())).thenReturn(edpDocRoleMappingList);
        assertEquals(0, edpDocRoleMappingServiceImpl.getEdpDocRoleMappingsByFilter(null, "test").size());
    }

    @Test
    void getEdpDocRoleMappingsByFilterTestWithProductParams(){
        when(edpDocRoleMappingRepository.getEdpDocRoleMappingsByFilter(anyString(), anyString())).thenReturn(edpDocRoleMappingList);
        assertEquals(0, edpDocRoleMappingServiceImpl.getEdpDocRoleMappingsByFilter("Test", null).size());
    }

    @Test
    void getEdpProductNamesTest(){
        when(edpDocRoleMappingRepository.findAll()).thenReturn(edpDocRoleMappingList);
        assertEquals(roleAndDocSet.size(), edpDocRoleMappingServiceImpl.getEdpProductNames().size());
    }

    @Test
    void getEdpDocRoleNamesTest(){
        when(edpDocRoleMappingRepository.findAll()).thenReturn(edpDocRoleMappingList);
        assertEquals(roleAndDocSet.size(), edpDocRoleMappingServiceImpl.getEdpDocRoleNames().size());
    }

}
