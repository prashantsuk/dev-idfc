package com.edms.controller;

import com.edms.entity.EdpDocRoleMapping;
import com.edms.service.EdpDocRoleMappingService;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.client.HttpClient;
import io.micronaut.runtime.server.EmbeddedServer;
import io.micronaut.test.annotation.MockBean;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import jakarta.inject.Inject;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.*;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

@MicronautTest(rebuildContext = true)
public class EdpDocRoleMappingCotrollerTest {

    @Inject
    EdpDocRoleMappingService edpDocRoleMappingService;

    @Inject
    EmbeddedServer server;
    EdpDocRoleMapping edpDocRoleMapping = null;

    List<EdpDocRoleMapping> edpDocRoleMappingList = new ArrayList<>();

    HttpClient client = null;

    @BeforeEach
    public void setUp() throws MalformedURLException {
        client = HttpClient.create(new URL("http://" + server.getHost()+":"+ server.getPort()));
        edpDocRoleMapping = new EdpDocRoleMapping();
        edpDocRoleMapping.setDocRoleName("Operator");
        edpDocRoleMapping.setPk(01);
        edpDocRoleMapping.setDocTypeName("Loan App");
        edpDocRoleMapping.setIsView("Y");
        edpDocRoleMapping.setCreatedBy("USER");
        edpDocRoleMapping.setCreatedDate("2023-03-15");
        edpDocRoleMapping.setIsWrite("N");
        edpDocRoleMapping.setProductName("product");
        edpDocRoleMapping.setProductId(123l);
        edpDocRoleMappingList.add(edpDocRoleMapping);
    }

    @MockBean(EdpDocRoleMappingService.class)
    public EdpDocRoleMappingService edpDocRoleMappingService() {
        return mock(EdpDocRoleMappingService.class);
    }


    @Test
    void getEdpDocRoleMappingsByFilterTest() throws MalformedURLException {
        when(edpDocRoleMappingService.getEdpDocRoleMappingsByFilter(anyString(), anyString())).thenReturn(edpDocRoleMappingList);
        HttpResponse<List<EdpDocRoleMapping>> response = client.toBlocking()
                .exchange(HttpRequest.GET("/viewDocRoleMapping?productName="+"product"+"&docRoleName="+"Operator"));
        assertEquals(null, response.body());

    }

    @Test
    void getEdpDocRoleNamesTest() throws MalformedURLException {
        Set<String> docRoleSet = new HashSet<>();
        docRoleSet.add("Operator");
        when(edpDocRoleMappingService.getEdpDocRoleNames()).thenReturn(docRoleSet);
        HttpResponse<Set<String>> response = client.toBlocking()
                .exchange(HttpRequest.GET("/getEdpDocRoleNames"));
        assertEquals(null, response.body());
    }

    @Test
    void getEdpProductNames() throws MalformedURLException {
        Set<String> productNameSet = new HashSet<>();
        productNameSet.add("Operator");
        when(edpDocRoleMappingService.getEdpProductNames()).thenReturn(productNameSet);
        HttpResponse<Set<String>> response = client.toBlocking()
                .exchange(HttpRequest.GET("/getEdpProductNames"));
        server.stop();
        assertEquals(null, response.body());
    }


}
