package com.edms.repository;

import com.edms.entity.EdpDocRoleMapping;

import java.util.List;

public interface EdpDocRoleMappingRepository {
    public List<EdpDocRoleMapping> getEdpDocRoleMappingsByFilter(String productName, String docRoleName);

    public List<EdpDocRoleMapping> findAll();
}
