package com.edms.service;

import com.edms.entity.EdpDocRoleMapping;

import java.util.List;
import java.util.Set;

public interface EdpDocRoleMappingService {
    public List<EdpDocRoleMapping> getEdpDocRoleMappingsByFilter(String productName, String docRoleName);
    public Set<String> getEdpProductNames();
    public Set<String> getEdpDocRoleNames();
}
