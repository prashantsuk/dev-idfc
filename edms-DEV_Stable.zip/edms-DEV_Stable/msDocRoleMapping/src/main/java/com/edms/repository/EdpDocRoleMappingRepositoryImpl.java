package com.edms.repository;


import com.aerospike.mapper.tools.AeroMapper;
import com.edms.entity.EdpDocRoleMapping;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Singleton
public class EdpDocRoleMappingRepositoryImpl implements EdpDocRoleMappingRepository{

    @Inject
    AeroMapper aeroMapper;

    @Override
    public List<EdpDocRoleMapping> getEdpDocRoleMappingsByFilter(String productName, String docRoleName) {

        List<EdpDocRoleMapping> edpDocRoleMappingList = new ArrayList<>();
        if(StringUtils.isNotBlank(productName) && StringUtils.isNotBlank(docRoleName)) {
            edpDocRoleMappingList = aeroMapper.scan(EdpDocRoleMapping.class).stream().filter(combineFilters(e -> e.getProductName().equals(productName), e -> e.getDocRoleName().equals(docRoleName))).collect(Collectors.toList());
        }else if(StringUtils.isNotBlank(productName) && StringUtils.isBlank(docRoleName)){
            edpDocRoleMappingList = aeroMapper.scan(EdpDocRoleMapping.class).stream().filter(e -> e.getProductName().equals(productName)).collect(Collectors.toList());
        }else{
            edpDocRoleMappingList = aeroMapper.scan(EdpDocRoleMapping.class).stream().filter(e -> e.getDocRoleName().equals(docRoleName)).collect(Collectors.toList());
        }
        return edpDocRoleMappingList;
    }

    @Override
    public List<EdpDocRoleMapping> findAll() {
        return aeroMapper.scan(EdpDocRoleMapping.class);
    }

    public static <T> Predicate<T> combineFilters(Predicate<T>... predicates) {
        Predicate<T> p = Stream.of(predicates).reduce(x -> true, Predicate::and);
        return p;
    }

}
