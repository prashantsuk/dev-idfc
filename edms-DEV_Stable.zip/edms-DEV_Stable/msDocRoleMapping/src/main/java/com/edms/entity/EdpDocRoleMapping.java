package com.edms.entity;

import com.aerospike.mapper.annotations.AerospikeBin;
import com.aerospike.mapper.annotations.AerospikeKey;
import com.aerospike.mapper.annotations.AerospikeRecord;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AerospikeRecord(namespace = "test",set = "edp_docrole_mapping")
public class EdpDocRoleMapping {

    @AerospikeKey
    @AerospikeBin(name = "PK")
    private long pk;
    @AerospikeBin(name = "CREATEDBY")
    private String createdBy;
    @AerospikeBin(name = "CREATEDDATE")
    private String createdDate;
    @AerospikeBin(name = "DOC_ROLE_NAME")
    private String docRoleName;
    @AerospikeBin(name = "DOC_TYPE_NAME")
    private String docTypeName;
    @AerospikeBin(name = "IS_VIEW")
    private String isView;
    @AerospikeBin(name = "IS_WRITE")
    private String isWrite;
    @AerospikeBin(name = "PRODUCTID")
    private Long productId;
    @AerospikeBin(name = "PRODUCTNAME")
    private String productName;
    @AerospikeBin(name = "UPDATEDBY")
    private String updatedBy;
    @AerospikeBin(name = "UPDATEDDATE")
    private String updatedDate;

}
