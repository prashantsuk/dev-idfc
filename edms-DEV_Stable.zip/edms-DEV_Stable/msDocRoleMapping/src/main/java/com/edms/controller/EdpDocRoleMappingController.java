package com.edms.controller;

import java.util.List;
import java.util.Set;

import com.edms.entity.EdpDocRoleMapping;
import com.edms.service.EdpDocRoleMappingService;

import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.rules.SecurityRule;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
@Secured(SecurityRule.IS_AUTHENTICATED)
public class EdpDocRoleMappingController {

@Inject
    EdpDocRoleMappingService edpDocRoleMappingService;

    @Get("/viewDocRoleMapping")
    public HttpResponse<List<EdpDocRoleMapping>> getEdpDocRoleMappingsByFilter(@QueryValue String productName, @QueryValue String docRoleName, HttpHeaders headers)
    {
        log.info(headers.get("user")+" started view document role mapping for product : {} and doc role : {} ",productName,docRoleName);

        return HttpResponse.ok(edpDocRoleMappingService.getEdpDocRoleMappingsByFilter(productName,docRoleName));
    }

    @Get("/getEdpDocRoleNames")
    public HttpResponse<Set<String>> getEdpDocRoleNames()
    {
        return HttpResponse.ok(edpDocRoleMappingService.getEdpDocRoleNames());
    }

    @Get("/getEdpProductNames")
    public HttpResponse<Set<String>> getEdpProductNames()
    {
        return HttpResponse.ok(edpDocRoleMappingService.getEdpProductNames());
    }

}
