package com.edms.service;

import com.edms.entity.EdpDocRoleMapping;
import com.edms.repository.EdpDocRoleMappingRepository;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Singleton
public class EdpDocRoleMappingServiceImpl implements EdpDocRoleMappingService{

    @Inject
    EdpDocRoleMappingRepository edpDocRoleMappingRepository;
    @Override
    public List<EdpDocRoleMapping> getEdpDocRoleMappingsByFilter(String productName, String docRoleName) {

        List<EdpDocRoleMapping> edpDocRoleMappingList = new ArrayList<>();
        if((StringUtils.isNotBlank(productName)&&StringUtils.isNotBlank(docRoleName)) || (StringUtils.isNotBlank(productName) || StringUtils.isNotBlank(docRoleName))) {
            edpDocRoleMappingList = edpDocRoleMappingRepository.getEdpDocRoleMappingsByFilter(productName, docRoleName);
        }else{
            edpDocRoleMappingList = edpDocRoleMappingRepository.findAll();
        }
        return edpDocRoleMappingList;
    }
    @Override
    public Set<String> getEdpProductNames(){

        Set<String> productSet = new HashSet<>();

         edpDocRoleMappingRepository.findAll().stream().distinct().map(e-> {
            productSet.add(e.getProductName());
            return productSet;
        }).collect(Collectors.toSet());
        return productSet;
    }

    @Override
    public Set<String> getEdpDocRoleNames() {
        Set<String> productSet = new HashSet<>();

        edpDocRoleMappingRepository.findAll().stream().distinct().map(e-> {
            productSet.add(e.getDocRoleName());
            return productSet;
        }).collect(Collectors.toSet());
        return productSet;
    }

}
