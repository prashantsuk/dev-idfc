package com.edms;

import java.util.List;
import org.junit.gen5.api.Assertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.edms.model.AssetEntity;
import com.edms.repository.DocumentRepository;

import io.micronaut.test.extensions.junit5.annotation.MicronautTest;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@MicronautTest
@Slf4j
@Data
public class DocumentRepositoryTest {

	@BeforeAll
	static void initAll() {
	}

	@BeforeEach
	void init() {
	}

	@Test
	@DisplayName("save")
	public void save() {
		try {
			log.info("Starting execution of save");
			AssetEntity docMs = null;

			DocumentRepository documentrepository = new DocumentRepository();
			documentrepository.save(docMs);
			Assertions.assertTrue(true);
		} catch (Exception exception) {
			log.error("Exception in execution ofsave-" + exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}


	@Test
	@DisplayName("find By Customer Id And Doc Name And Doc Type")
	public void findByCustomerIdAndDocNameAndDocType() {
		try {
			log.info("Starting execution of findByCustomerIdAndDocNameAndDocType");
			List<AssetEntity> expectedValue = null;
			String customerId = "";
			String source = "";
			String documentName = "";
			String docTypeName = "";

			DocumentRepository documentrepository = new DocumentRepository();
			List<AssetEntity> actualValue = documentrepository.findByCustomerIdAndDocNameAndDocType(source,customerId,
					documentName, docTypeName);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}


	@AfterEach
	void tearDown() {
	}

	@AfterAll
	static void tearDownAll() {
	}
}
