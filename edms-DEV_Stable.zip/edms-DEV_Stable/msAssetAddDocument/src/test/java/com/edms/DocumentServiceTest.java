package com.edms;


import org.junit.gen5.api.Assertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.edms.model.AddAssetResponse;
import com.edms.model.AssetEntity;
import com.edms.model.AddAssetRequest;

import com.edms.service.DocumentServiceImpl;
import com.edms.service.DocumentServiceImpl;

import java.io.File;
import java.util.List;
import io.micronaut.http.HttpRequest;
import io.micronaut.test.extensions.junit5.annotation.MicronautTest;

@MicronautTest
public class DocumentServiceTest {

//	private Logger log = Logger.getLogger(this.getClass());
	@BeforeAll
	static void initAll() {
	}

	@BeforeEach
	void init() {
		
	}

	@Test
	@DisplayName("doc Upload")
	public void uploadDocument() {
		try {
//			log.info("Starting execution of uploadDocument");
			AddAssetResponse expectedValue = null;
			AddAssetRequest document = null;
			HttpRequest request = null;
			DocumentServiceImpl documentservice = new DocumentServiceImpl();
			AddAssetResponse actualValue = null;
					//documentservice.uploadDocument(document, null);
			// log.info("Expected Value="+ expectedValue +" . Actual Value="+actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			System.out.println("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("get Current Date")
	public void getCurrentDate() {
		try {
			System.out.println("Starting execution of getCurrentDate");
			String expectedValue = "";

			DocumentServiceImpl documentservice = new DocumentServiceImpl();
			String actualValue = documentservice.getCurrentDate();
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			System.out.println("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("encode File To Base64")
	public void encodeFileToBase64() {
		try {
			System.out.println("Starting execution of encodeFileToBase64");
			String expectedValue = "";
			File file = null;

			DocumentServiceImpl documentservice = new DocumentServiceImpl();
			String actualValue = documentservice.encodeFileToBase64(file);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			System.out.println("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@AfterEach
	void tearDown() {
	}

	@AfterAll
	static void tearDownAll() {
	}
}
