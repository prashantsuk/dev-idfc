package com.edms;

import java.io.File;
import java.util.List;

import org.junit.Test;
import org.junit.gen5.api.Assertions;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import com.edms.model.AddAssetRequest;
import com.edms.model.AddAssetResponse;
import com.edms.model.AssetEntity;
import com.edms.model.UploadDocuments;
import com.edms.service.DocumentServiceImpl;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocumentServiceImplTest {

	@BeforeAll
	static void initAll() {
	}

	@BeforeEach
	void init() {
	}

	@Test
	@DisplayName("doc Upload")
	public void uploadDocument() {
		try {
			log.info("Starting execution of uploadDocument");
			AddAssetResponse expectedValue = null;
			AddAssetRequest document = null;

			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();
			AddAssetResponse actualValue = null;
					//documentserviceimpl.uploadDocument(document, null);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("page Count")
	public void pageCount() {
		try {
			log.info("Starting execution of pageCount");
			int expectedValue = 0;
			String path = "";
			AssetEntity msgBdy = null;

			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();
			int actualValue = documentserviceimpl.pageCount(path, msgBdy);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("get Current Date")
	public void getCurrentDate() {
		try {
			log.info("Starting execution of getCurrentDate");
			String expectedValue = "";

			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();
			String actualValue = documentserviceimpl.getCurrentDate();
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("encode File To Base64")
	public void encodeFileToBase64() {
		try {
			log.info("Starting execution of encodeFileToBase64");
			String expectedValue = "";
			File file = null;

			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();
			String actualValue = documentserviceimpl.encodeFileToBase64(file);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("convert To File")
	public void convertToFile() {
		try {
			log.info("Starting execution of convertToFile");
			String expectedValue = "";
			AddAssetRequest msgBdy = null;
			String folderLoc = "";

			UploadDocuments doc = null;
			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();
			String actualValue = documentserviceimpl.convertToFile(msgBdy, folderLoc, doc);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("convert Base64 String To File")
	public void convertBase64StringToFile() {
		try {
			log.info("Starting execution of convertBase64StringToFile");
			String expectedValue = "";
			AddAssetRequest msgBdy = null;
			String location = "";

			UploadDocuments doc = null;
			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();
			String actualValue = documentserviceimpl.convertBase64StringToFile(msgBdy, location, doc);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("update Document Version")
	public void updateDocumentVersion() {
		try {
			log.info("Starting execution of updateDocumentVersion");
			String expectedValue = "";
			AddAssetRequest uploadReq = null;
			String docName = "";
			UploadDocuments doc = null;
			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();

			String actualValue = documentserviceimpl.updateDocumentVersion(uploadReq, docName,doc);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@Test
	@DisplayName("get By Customer")
	public void getByCustomer() {
		try {
			log.info("Starting execution of getByCustomer");
			List<AssetEntity> expectedValue = null;
			AddAssetRequest document = null;
			UploadDocuments doc = null;
			DocumentServiceImpl documentserviceimpl = new DocumentServiceImpl();
			List<AssetEntity> actualValue = documentserviceimpl.getByCustomer(document,doc);
			log.info("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			System.out.println("Expected Value=" + expectedValue + " . Actual Value=" + actualValue);
			Assertions.assertEquals(expectedValue, actualValue);
		} catch (Exception exception) {
			log.error("Exception in execution of execute1GetAllLogFromFirstMovF-" + exception, exception);
			exception.printStackTrace();
			Assertions.assertFalse(false);
		}
	}

	@AfterEach
	void tearDown() {
	}

	@AfterAll
	static void tearDownAll() {
	}
}
