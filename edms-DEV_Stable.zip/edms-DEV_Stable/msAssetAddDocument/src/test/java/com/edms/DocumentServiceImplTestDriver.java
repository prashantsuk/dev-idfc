package com.edms;

import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocumentServiceImplTestDriver {


	   public static void main(String[] args) {
	      Result result = JUnitCore.runClasses(DocumentServiceImplTest.class);
			
	      for (Failure failure : result.getFailures()) {
	    	  log.error("Failed : "+failure.toString());
	      }
			
	      log.info("Success : "+result.wasSuccessful()+"");
	   }
	}  
