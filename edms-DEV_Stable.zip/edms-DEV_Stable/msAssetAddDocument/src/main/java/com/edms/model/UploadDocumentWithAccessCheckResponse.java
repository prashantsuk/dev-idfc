package com.edms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UploadDocumentWithAccessCheckResponse {

	private String uploadPermission;
    private String isSuccess;
    private String exception;
	private String filenetResponse;
	private UploadDocumentsResponse uploadDocumentsResponse;
	private String errorMessage;
	private String error;
}
