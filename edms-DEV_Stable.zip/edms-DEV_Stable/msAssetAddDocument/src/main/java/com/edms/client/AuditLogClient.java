package com.edms.client;

import com.edms.model.AuditLog;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;

@Client(id="ms-audit-log")
public interface AuditLogClient {
	
	@Post("/auditLog")
	void addAuditLog(@Body AuditLog auditLog);

}
