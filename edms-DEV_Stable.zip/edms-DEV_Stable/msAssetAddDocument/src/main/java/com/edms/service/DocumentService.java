package com.edms.service;

import java.io.IOException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

import com.edms.exception.FileSizeExceedsException;
import com.edms.exception.UploadDocumentFailureException;
import com.edms.model.*;
import jakarta.inject.Singleton;

@Singleton
public interface DocumentService {

	public List<AddAssetResponse> uploadDocument(AddAssetRequest document, String user) 
			throws UploadDocumentFailureException,FileSizeExceedsException, IOException, NoSuchAlgorithmException, Exception;
}
