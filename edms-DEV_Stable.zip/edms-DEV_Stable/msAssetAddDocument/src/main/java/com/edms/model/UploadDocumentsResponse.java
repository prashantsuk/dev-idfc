package com.edms.model;

import java.util.HashMap;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class UploadDocumentsResponse {
	
	private HashMap<String, String> status;
	private HashMap<String, String> docId;
	private String isSuccess;
	private String exception;
	private String error;
	private String isValid;
}
