package com.edms.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class HdrFlds {

	@NotNull(message = "cnvId is mandatory")
	private String cnvId;
	
	@NotNull(message = "msgId is mandatory")
	private String msgId;
	
	@NotNull(message = "timestamp is mandatory")
	private String timestamp;
}
