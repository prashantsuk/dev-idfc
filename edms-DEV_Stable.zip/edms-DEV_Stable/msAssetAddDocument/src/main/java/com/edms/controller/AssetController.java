package com.edms.controller;

import java.util.List;

import com.aerospike.client.AerospikeException;
import com.edms.model.AddAssetRequest;
import com.edms.model.AddAssetResponse;
import com.edms.service.DocumentService;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Error;
import io.micronaut.http.annotation.Post;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.authentication.Authentication;
import io.micronaut.security.rules.SecurityRule;
//import io.micronaut.security.annotation.Secured;
//import io.micronaut.security.authentication.Authentication;
//import io.micronaut.security.rules.SecurityRule;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller("/assets")
@Secured(SecurityRule.IS_AUTHENTICATED)
public class AssetController {

	@Inject
	private DocumentService documentService;

	@Post("/addDocument")
	@Error(exception = AerospikeException.class)
	public MutableHttpResponse<List<AddAssetResponse>> save(@Body AddAssetRequest documents, Authentication authentication)
			throws Exception {
		log.info(
				authentication.getName()
						+ " started upload document for Assets for customer id : {} with request as : {}",
				documents.getCustomerId(),
				new ObjectMapper().enable(SerializationFeature.INDENT_OUTPUT).writeValueAsString(documents));

		return HttpResponse.ok(documentService.uploadDocument(documents, authentication.getName()));

	}

}