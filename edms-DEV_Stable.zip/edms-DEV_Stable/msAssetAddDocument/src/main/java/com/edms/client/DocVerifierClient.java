package com.edms.client;

import com.edms.model.DocumentResponse;
import com.edms.model.DocumentVerifier;

import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;

@Client(id="ms-document-verifier")
public interface DocVerifierClient {
	
	@Post("/docVerify")
	DocumentResponse checkfiles(@Body DocumentVerifier documentVerifier);
	
}
