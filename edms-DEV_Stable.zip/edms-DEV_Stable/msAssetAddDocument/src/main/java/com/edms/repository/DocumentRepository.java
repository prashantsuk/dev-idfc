package com.edms.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import com.aerospike.client.AerospikeClient;
import com.aerospike.client.AerospikeException;
import com.aerospike.client.exp.Exp;
import com.aerospike.client.policy.Policy;
import com.aerospike.client.policy.QueryPolicy;
import com.aerospike.client.query.Filter;
import com.aerospike.client.query.RecordSet;
import com.aerospike.client.query.Statement;
import com.aerospike.mapper.tools.AeroMapper;
import com.edms.model.AssetEntity;
import com.edms.model.AssetStgEntity;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;

import static com.edms.util.Constants.*;

@Singleton
public class DocumentRepository {

	@Inject
	AeroMapper aeroMapper;

	@Inject
	private AerospikeClient readClient;

	@Inject
	private AerospikeClient writeClient;

	public List<AssetEntity> findAll() {
		return aeroMapper.scan(AssetEntity.class);
	}

	public void save(AssetEntity docMs) {
		aeroMapper.save(docMs);
	}

	public List<AssetEntity> findByCustomerIdAndDocNameAndDocType(String source, String documentName, String customerId,
			String docTypeName) {
		List<AssetEntity> allData = aeroMapper.scan(AssetEntity.class);
		allData =  allData.stream()
				.filter(doc -> (doc.getCustomerId()!= null&&!doc.getCustomerId().isEmpty() && doc.getCustomerId().equalsIgnoreCase(customerId))
						&& (doc.getDocumentTypeName()!= null&&!doc.getDocumentTypeName().isEmpty() && doc.getDocumentTypeName().equals(docTypeName))
						&& (doc.getDocumentName()!= null&&!doc.getDocumentName().isEmpty() && doc.getDocumentName().equals(documentName))
						&& (doc.getSourceName()!= null&&!doc.getSourceName().isEmpty() && doc.getSourceName().equals(source)))
				.collect(Collectors.toList());
		
		return allData;

	}
	
//	public List<AssetEntity> findByCustomerIdAndDocNameAndDocType(String source, String documentName, String customerId,
//			String docTypeName) {
//		List<AssetEntity> result = new ArrayList<>();
//		try{
//		
//		Statement stmt = new Statement();
//		stmt.setNamespace(ASSETS_NAMESPACE);
//		stmt.setSetName(ASSETS_SET);
//		
//		QueryPolicy policy = new QueryPolicy(readClient.queryPolicyDefault);		
//
//			policy.filterExp = Exp.build(Exp.and(Exp.stringBin("SOURCENAME"), Exp.val(source),
//					Exp.stringBin("DOCUMENTNAME"), Exp.val(documentName),
//					Exp.stringBin("DOCTYPENAME"), Exp.val(docTypeName),
//					Exp.stringBin("CUSTOMERID"), Exp.val(customerId))
//					);
//
//			RecordSet rs = readClient.query(policy, stmt);
//			if(rs.next()) {
//			while (rs.next()) {
//				AssetEntity roleObject = aeroMapper.getMappingConverter().convertToObject(AssetEntity.class, rs.getRecord());
//				result.add(roleObject);
//			}
//			}
//		}catch(AerospikeException e) {
//			return new ArrayList<>();
//		}
//			return result;
//	}


	public List<AssetStgEntity> findAllStaging() {
		return aeroMapper.scan(AssetStgEntity.class);
	}

	public List<AssetEntity> findByDocId(String value){
		return aeroMapper.query(AssetEntity.class, Filter.equal("DOCID", value));
	}

}
