package com.edms.controller;


import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.edms.exception.UserException;
import com.edms.model.Response;
import com.edms.service.ViewDocServiceImpl;

import io.micronaut.core.annotation.Nullable;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.authentication.Authentication;
import io.micronaut.security.rules.SecurityRule;
import jakarta.inject.Inject;

@Controller("/viewDoc")
@Secured(SecurityRule.IS_AUTHENTICATED)
public class AssetsViewDocumentController {
	
	@Inject
	ViewDocServiceImpl viewDocServiceImpl;

	
	@Get
	public HttpResponse<Response> AssetsViewDoc(@QueryValue String docIndx, @QueryValue String tableType,@Nullable Authentication authentication) throws UserException, IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidParameterSpecException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException
	{
		return HttpResponse.ok(viewDocServiceImpl.viewDoc(docIndx,tableType,authentication.getName()));
	}
	
}
