package com.edms.exception;

import com.edms.model.UploadDocumentResponse;
import com.edms.model.UploadDocumentWithAccessCheckResponse;
import com.edms.util.Constants;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

@Produces
@Singleton
@Requires(classes = { FileSizeExceedsException.class, ExceptionHandler.class })
@Slf4j
public class FileSizeExceedsExceptionhandler implements ExceptionHandler<FileSizeExceedsException, HttpResponse> {

	@Override
	public HttpResponse handle(HttpRequest request, FileSizeExceedsException exception) {

		log.error(Constants.EXCEPTION_OCCURED, exception);
		UploadDocumentWithAccessCheckResponse uploadDocumentWithAccessCheckResponse = UploadDocumentWithAccessCheckResponse
				.builder().error(exception.getMessage()).errorMessage(exception.getMessage()).build();
		UploadDocumentResponse responseMsg = UploadDocumentResponse.builder()
				.uploadDocumentWithAccessCheckResponse(uploadDocumentWithAccessCheckResponse).build();
		return HttpResponse.badRequest(responseMsg);
	}

}
