package com.edms.exception;

import static com.edms.util.Constants.*;

import com.edms.model.UploadDocumentsResponse;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

@Produces
@Singleton
@Requires(classes = { UploadDocumentFailureException.class, ExceptionHandler.class })
@Slf4j
public class UploadDocumentFailureExceptionHandler
		implements ExceptionHandler<UploadDocumentFailureException, HttpResponse> {

	@Override
	public HttpResponse handle(HttpRequest request, UploadDocumentFailureException exception) {

		log.error(EXCEPTION_OCCURED, exception.getMessage());
		UploadDocumentsResponse responseMsg = UploadDocumentsResponse.builder().isSuccess(NO)
				.error(exception.getMessage()).build();
		return HttpResponse.badRequest(responseMsg);
	}

}
