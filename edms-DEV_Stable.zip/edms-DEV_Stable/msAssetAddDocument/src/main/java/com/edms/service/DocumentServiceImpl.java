package com.edms.service;

import static com.edms.util.Constants.*;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.commons.io.FilenameUtils;
import org.apache.pdfbox.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;

import com.edms.client.AuditLogClient;
import com.edms.client.DocVerifierClient;
import com.edms.exception.FileSizeExceedsException;
import com.edms.exception.GlobalException;
import com.edms.exception.UploadDocumentFailureException;
import com.edms.model.AddAssetRequest;
import com.edms.model.AddAssetResponse;
import com.edms.model.AssetEntity;
import com.edms.model.AssetStgEntity;
import com.edms.model.AuditLog;
import com.edms.model.DocumentResponse;
import com.edms.model.DocumentVerifier;
import com.edms.model.Property;
import com.edms.model.UploadDocumentResponse;
import com.edms.model.UploadDocumentWithAccessCheckResponse;
import com.edms.model.UploadDocuments;
import com.edms.model.UploadDocumentsResponse;
import com.edms.repository.AssetStagingRepoImpl;
import com.edms.repository.DocumentRepository;
import com.edms.util.Utilities;

import io.micronaut.context.annotation.Value;

import io.micronaut.http.client.HttpClient;
import io.micronaut.scheduling.annotation.Async;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class DocumentServiceImpl implements DocumentService {

	@Inject
	private DocumentRepository documentRepository;

	@Inject
	private AssetStagingRepoImpl assetStagingRepoImpl;

	@Inject
	public DocVerifierClient docVerifierClient;

	@Value("${file.locationPath}")
	private String fileDestLocation;

	@Inject
	HttpClient httpClient;

	@Inject
	AuditLogClient auditLogClient;

	private String docKey = "";
	private String passwordkey = "";

	private static final SecureRandom RANDOM = new SecureRandom();
	
	public AssetStgEntity stagingFileOperations(AssetStgEntity assetStgEntity,AddAssetRequest request,UploadDocuments document) throws Exception {
		
		DocumentResponse documentResponse = new DocumentResponse();
		String content = document.getObjectBean().getContent();
		String tempCustId = assetStgEntity.getCustomerId();
		
		DocumentVerifier documentVerifier = DocumentVerifier.builder().password(request.getPassword())
				.base64(document.getObjectBean().getContent()).fileName(assetStgEntity.getDocumentTitle())
				.build();
		
		documentResponse = docVerifierClient.checkfiles(documentVerifier);
		if (!documentResponse.isValidDocument()) {
			throw new UploadDocumentFailureException(documentResponse.getErrMessage());
		}

		File file = new File(fileDestLocation + SLASH + assetStgEntity.getDocumentTitle() + SLASH
				+ document.getObjectBean().getFileLocation());

		String format = !content.equals("")
				? content.substring(content.indexOf(":"), content.indexOf(";")).replace(':', ' ').trim()
				:CORRUPT;

		if (file.length() > 10 * 1024 * 1024) {
			throw new FileSizeExceedsException(FILE_SIZE_EXCEEDS);

		} else if (format == null || !FILE_TYPE.contains(format)) {

			throw new UploadDocumentFailureException(assetStgEntity.getMimeType() + INVALID_MIMETYPE
					+ assetStgEntity.getDocumentName() + " " + format);
		}

		assetStgEntity.setDocumentTitle(assetStgEntity.getDocumentTitle());
		String fileName = updateDocumentVersionStaging(request, assetStgEntity.getDocumentTitle(),document);
		assetStgEntity.setFileName(fileName);

		try (FileOutputStream fos = new FileOutputStream(
				fileDestLocation + SLASH + tempCustId + SLASH + fileName);) {

			if (document.getObjectBean().getContent().contains(BASE64))
				document.getObjectBean()
						.setContent(document.getObjectBean().getContent().substring(
								document.getObjectBean().getContent().indexOf(',')
										+ 1));
			fos.write(Base64.getDecoder()
					.decode(document.getObjectBean().getContent()));
			encrypt(fileDestLocation + SLASH + tempCustId + SLASH + fileName);
			assetStgEntity.setDocEncryptKey(docKey);
		}
		int count = pageCountStaging(fileDestLocation + SLASH + tempCustId + SLASH + fileName,
				assetStgEntity);
		if (count == 0)
			throw new UploadDocumentFailureException(FILE_NOT_EXISTS);
		assetStgEntity.setNoOfPages(count);

		assetStgEntity.setDocumentVersion((getByCustomerStaging(request,document).size() + 1));
		assetStgEntity.setActualFileSize("" + Math.round(Utilities.calcBase64SizeInKb(document.getObjectBean().getContent())) + KB);
		
		return assetStgEntity;
	}
	
	public AssetEntity mainFileOperations(AssetEntity doc,AddAssetRequest request,UploadDocuments document) throws Exception {
		
		DocumentResponse documentResponse = new DocumentResponse();		
		String content = document.getObjectBean().getContent();
		List<Property> property = document.getObjectBean().getProperty();
		String filePath = updateDocumentVersion(request, doc.getDocumentTitle(),document);
		
		DocumentVerifier documentVerifier = DocumentVerifier.builder().password(request.getPassword())
				.base64(document.getObjectBean().getContent()).fileName(doc.getDocumentTitle())
				.build();

		documentResponse = docVerifierClient.checkfiles(documentVerifier);
		if (!documentResponse.isValidDocument()) {
			throw new UploadDocumentFailureException(documentResponse.getErrMessage());
		}

		File file = new File(fileDestLocation + SLASH + doc.getCustomerId() + SLASH
				+ document.getObjectBean().getFileLocation());

		String format = !content.equals("")
				? content.substring(content.indexOf(":"), content.indexOf(";")).replace(':', ' ').trim()
				: CORRUPT;
		doc.setFileType(FilenameUtils.getExtension(file.getAbsolutePath()));
		if (file.length() > 10 * 1024 * 1024) {
			throw new FileSizeExceedsException(FILE_SIZE_EXCEEDS);

		} else if (format == null || !FILE_TYPE.contains(format)) {

			throw new UploadDocumentFailureException(
					doc.getMimeType() + INVALID_MIMETYPE + doc.getDocumentName() + " " + format);
		}

		try (FileOutputStream fos = new FileOutputStream(
				fileDestLocation + SLASH + Utilities.toValue(property, 8) + SLASH + filePath);) {

			if (document.getObjectBean().getContent().contains(BASE64))
				document.getObjectBean()
						.setContent(document.getObjectBean().getContent().substring(
								document.getObjectBean().getContent().indexOf(',')
										+ 1));
			fos.write(Base64.getDecoder()
					.decode(document.getObjectBean().getContent()));
			encrypt(fileDestLocation + SLASH + doc.getCustomerId() + SLASH + filePath);
			doc.setDocEncryptKey(docKey);
		}
		int count = pageCount(fileDestLocation + SLASH + doc.getCustomerId() + SLASH + filePath,
				doc);
		if (count == 0)
			throw new UploadDocumentFailureException(FILE_NOT_EXISTS);
		doc.setNoOfPages(count);

		doc.setDocumentVersion((getByCustomer(request,document).size() + 1));
		doc.setActualFileSize("" + Math.round(Utilities.calcBase64SizeInKb(document.getObjectBean().getContent())) + KB);
		return doc;
	}

	public List<AddAssetResponse> uploadDocument(AddAssetRequest request, String user) throws Exception {	

		List<AddAssetResponse> responses = new ArrayList<>();
		for(UploadDocuments document : request.getUploadDocuments()) {
			AssetEntity doc = new AssetEntity();
			AssetStgEntity assetStgEntity = new AssetStgEntity();
	
			AddAssetResponse response = new AddAssetResponse();
			UploadDocumentResponse uploadDocResponse = new UploadDocumentResponse();
			UploadDocumentWithAccessCheckResponse uploadAcsChckResponse = new UploadDocumentWithAccessCheckResponse();
			UploadDocumentsResponse uploadDocsResponse = new UploadDocumentsResponse();
			HashMap<String, String> docId = new HashMap<>();
			HashMap<String, String> status = new HashMap<>();
			String docTitle = "";
			String content = document.getObjectBean().getContent();
			String filePath = null;
			List<Property> property = document.getObjectBean().getProperty();
	
			String customerId = "";
			File file = null;
			File directory = null;
			try {
				if (null != content) {
					if (!request.isStagingCheck()) {
	
						String encryptPassword = (request.getPassword() == null || request.getPassword().length() == 0)
								? null
								: encryptPassword(request.getPassword());
						String dataClass =  IDFCEDP + Utilities.toValue(property, 7) + SLASH + ASSETS + SLASH
								+ request.getProdName() + SLASH + request.getSourceName() + SLASH
								+ request.getDocumentType() + SLASH + Utilities.toValue(property, 0) + SLASH
								+ Utilities.toValue(property, 1);
							
			doc = AssetEntity.builder().pk(documentRepository.findAll().size() + 1L).acceptedBy("").acceptedDate("").accountNumber((1000000000000000L + (long) (RANDOM.nextDouble() * 9000000000000000L)) + "")
					.applicantType("").applicationId("").applicationName("").apiStatus(EXP_200).barcodeNo("").bpmLoanNumber("").branchId("").caseId("").category(ASSETS).checkedInDate("").classificaState("")
					.cmsearchScver("").comments("").compBindLabel("").compDocState(0).compTypes("").compTypes2("").connectorId("").connectorId("").consideration("").content("")
					.contentInfo2("").contentlaDate("").contentrefBlob("").contentretnDate("").createdBy(user).createdDate(getCurrentDate())
					.crmId(Utilities.toValue(property, 8)).crnNo(Utilities.toValue(property, 9)).crnnoNew("").customerId(Utilities.toValue(property, 7)).customerName(CUSTOMER).customerRelNo("")
					.customerType("").dealerOnboardId(Utilities.toValue(property, 6)).deferedDate("").description("").docEncryptKey(docKey).docExpirydate("").documentNo(0).documentRemark("")
					.dataClass(dataClass).docId(String.format(SIXTEEN_DIGIT_FORMAT, documentRepository.findAll().size() + 1)).docLifecyPolicy("").docPasswd(encryptPassword).docState("").docTypeId(request.getDocTypeId() + "")
					.documentName(Utilities.toValue(property, 0)).documentTitle(Utilities.toValue(property, 1)).documentStatus("").documentTypeName(request.getDocumentType())
					.documentVersion((getByCustomer(request,document).size() + 1)).docUploaded("").docUploadId("").edmsResponse("").edpId(EDP + String.format(SIXTEEN_DIGIT_FORMAT, documentRepository.findAll().size() + 1)).emailId(EMAIL_ID).emailSubject("")
					.encryptPassword(passwordkey).entryTemplate("").entryTemplateId("").entryTemplDesc("").entryTobjstore("").epochId(0).exception("").expiryDate("")
					.fileName(updateDocumentVersion(request, Utilities.toValue(property, 1),document)).filePath(dataClass)
					.finnOneLoanNo(Utilities.toValue(property, 7)).formDescription("").formPlcStepdesc("").formPolicy("").formPolicyDesc("").formPolicylWfl("").formPolicyWfId("").formPwfObject("")
					.formPwfObject("").formTemplate("").formType("").from("").geoLocation("").homeId("").icnAutoRun(0).icnClassName("").icnSearchRepo("").icnShowInTree("").icnWorkflowName("")
					.Id(0L).ignorereDirect("").indexationId("").indexFailCode(0).ingestionSource("").is_current(0).is_frozen(0).is_in_exstate(0).is_reserved(0).isSuccess(YES)
					.itxFormTemplate("").latitude("").layoutId("").layoutVersrId("").lockOwner("").lockSid("").lockTimeout(0).lockToken("").longitude("").majorVerNo(0).mandatory("").migrationId(0)
					.mimeType(request.getMimeType()).minorVerNo(0).mobileNo(9010203355L).modifyDate(getCurrentDate()).modifyUser(request.getUserName())
					.multipageDoc(pageCount(updateDocumentVersion(request, Utilities.toValue(property, 1),document),doc) > 0 ? YES : NO).nextContentUid(0)
					.noOfPages(pageCount(updateDocumentVersion(request, Utilities.toValue(property, 1),document),doc)).objectClassId("").objectId("").origPhotoCopy("").owner("").ownerDocument("")
					.ownerDocument("").pageNo(0).preferenceType("").processedId(documentRepository.findAll().size() + 1L + "").productId("").productName(request.getProdName()).project(request.getProject()).publicationInfo(null)
					.publishRnabled("").publSubsIdFold("").rcuComments("").rcuDecision("").rcuHold("").receivedDate("").receivedOn("").recoveryItemId("").reimbAccNo("").remarks("")
					.replicatGrpId("").reservationType("").reservOwnersId("").retrievalNames("").retrievalNames2("").roleName(request.getRole()).rootfolder("").scenaridefDocid("")
					.scenarIoDescr("").schemeId("").searchObjstores("").searchObjtype("").searchType(0).secufolderId("").secupolicyId("").securityId("").senton("").sfdcLoanno("")
					.simulationDesc("").simulationGuid("").simulatnStatus("").simulnSpinhour("").sourceDocument("").sourceId(request.getSourceId()).sourceName(request.getSourceName())
					.storageAreaid("").storageClass("").styleTemplate(encryptPassword).targetOcid("").targeToType("").targetSiteId("").toStorename("").totalCount(0).tset_first("")
					.ucic("").uploadDate(getCurrentDate()).uploadedBy(user).uploadPerm("").userName(request.getUserName()).version_status("").versionEnabled("").versionSeriesId("").viewPerm("").vw_version("").xmlDocType("").xmlTargetClass("").build();

						// call Doc verifier to validate document password
	
						directory = new File(doc.getFilePath());
						if (!directory.exists())
							directory.mkdirs();
						doc = mainFileOperations(doc,request,document);
	
						documentRepository.save(doc);
	
						docId.put(DOLLAR, doc.getDocId());
						status.put(DOLLAR, doc.getApiStatus());
	
						uploadDocsResponse= UploadDocumentsResponse.builder().docId(docId).status(status).build();	
						uploadAcsChckResponse.setException(doc.getException());
						uploadAcsChckResponse.setFilenetResponse(doc.getEdmsResponse());
						uploadAcsChckResponse.setIsSuccess(doc.getIsSuccess());
						uploadAcsChckResponse.setUploadDocumentsResponse(uploadDocsResponse);
						uploadAcsChckResponse.setUploadPermission(doc.getUploadPerm());
	
						uploadDocResponse.setUploadDocumentWithAccessCheckResponse(uploadAcsChckResponse);
						response.setProcessedId(doc.getProcessedId());
						response.setUploadDocumentResponse(uploadDocResponse);
						response.setNoOfPages(doc.getNoOfPages());
						response.setFilePath(doc.getFilePath());
						response.setValidDocument(true);
	
						AuditLog auditLog = AuditLog.builder().action(ACTION_UPLD).category(ASSETS).createdBy(user)
								.createdDate(doc.getUploadDate()).currentValue("").customerId(customerId)
								.lastUpdateDate(doc.getModifyDate()).modifiedBy(user).oldValue("").roleName("")
								.productName(request.getProdName()).sourceName(request.getSourceName()).status(SUCCESS)
								.message(user + " uploaded document sucessfully for Assets main table from "
										+ request.getSourceName()).build();
	
						auditLog(auditLog);	
					}
	
					// inserting into staging table
					else {
	
						List<AssetStgEntity> stagingList = assetStagingRepoImpl.findAllStaging();
						long size = stagingList.stream().map(AssetStgEntity::getPk).max(Comparator.naturalOrder())
								.orElse(0L);
						// generating temporary customer id for staging table
						String tempCustId = generateTemporaryCustomerId(stagingList, customerId);
						filePath = fileDestLocation + SLASH + tempCustId;
						String encryptPassword = (request.getPassword() == null || request.getPassword().length() == 0)
								? null
								: encryptPassword(request.getPassword());
						String dataClass = IDFCEDP + tempCustId + SLASH + ASSETS + SLASH + request.getProdName() + SLASH
								+ request.getSourceName() + SLASH + request.getDocumentType() + SLASH
								+ assetStgEntity.getDocumentName() + SLASH + docTitle;
	
						directory = new File(filePath);
						if (!directory.exists())
							directory.mkdirs();
	
				assetStgEntity = AssetStgEntity.builder().pk(size + 1L).acceptedBy("").acceptedDate("").accountNumber((1000000000000000L + (long) (RANDOM.nextDouble() * 9000000000000000L)) + "").applicantType("")
						.applicationId(Utilities.toValue(property, 9)).applicationName("").barcodeNo("").bpmLoanNumber("").branchId("").caseId("").category(ASSETS).checkedInDate("")
						.classificaState("").cmsearchScver("").comments("").compBindLabel("").compDocState(0).compTypes("").compTypes2("").connectorId("").connectorId("").consideration("").content("")
						.contentInfo2("").contentlaDate("").contentrefBlob("").contentretnDate("").createdBy(user).createdDate(getCurrentDate())
						.crmId(Utilities.toValue(property, 8)).crnNo(Utilities.toValue(property, 9)).crnnoNew("").customerId(tempCustId).customerName(CUSTOMER).customerRelNo("").customerType("")
						.dealerOnboardId(Utilities.toValue(property, 6)).deferedDate("").description("").docEncryptKey(docKey).docExpirydate("").documentNo(0).documentRemark("")
						.dataClass(dataClass).docId(String.format(SIXTEEN_DIGIT_FORMAT, documentRepository.findAll().size() + 1))
						.docLifecyPolicy("").docPasswd(encryptPassword).docState("").docTypeId(request.getDocTypeId() + "").documentName(Utilities.toValue(property, 0))
						.documentTitle(Utilities.toValue(property, 1)).documentStatus("").documentType(request.getDocumentType())
						.documentVersion((getByCustomerStaging(request,document).size() + 1)).docUploaded("").docUploadId("").edmsResponse("").edpId(EDP + String.format(SIXTEEN_DIGIT_FORMAT, documentRepository.findAll().size() + 1)).emailId(EMAIL_ID).emailSubject("")
						.encryptPassword(passwordkey).entryTemplate("").entryTemplateId("").entryTemplDesc("").entryTobjstore("").epochId(0).exception("").expiryDate("")
						.fileName(updateDocumentVersion(request, Utilities.toValue(property, 1),document)).filePath(dataClass)
						.fileType(file != null ? FilenameUtils.getExtension(file.getAbsolutePath()) : CORRUPT).finnOneLoanNo(Utilities.toValue(property, 8)).formDescription("").formPlcStepdesc("")
						.formPolicy("").formPolicyDesc("").formPolicylWfl("").formPolicyWfId("").formPwfObject("").formPwfObject("").formTemplate("").formType("").from("").geoLocation("").homeId("")
						.icnAutoRun(0).icnClassName("").icnSearchRepo("").icnShowInTree("").icnWorkflowName("").Id(0L).ignorereDirect("").indexationId("").indexFailCode(0).ingestionSource("")
						.is_current(0).is_frozen(0).is_in_exstate(0).is_reserved(0).isSuccess(YES).itxFormTemplate("").latitude("").layoutId("").layoutVersrId("").lockOwner("").lockSid("")
						.lockTimeout(0).lockToken("").longitude("").majorVerNo(0).mandatory("").migrationId(0).mimeType(request.getMimeType()).minorVerNo(0).mobileNo(9096484848L)
						.modifyDate(getCurrentDate()).modifyUser(request.getUserName())
						.multipageDoc(pageCount(updateDocumentVersionStaging(request, Utilities.toValue(property, 1),document),
										doc) > 0 ? YES : NO).nextContentUid(0).noOfPages(pageCount(updateDocumentVersionStaging(request, Utilities.toValue(property, 1),document),
								doc)).objectClassId("").objectId("").origPhotoCopy("").owner("").ownerDocument("").ownerDocument("").pageNo(0).preferenceType("").passKeyPath("")
						.processedId(documentRepository.findAll().size() + 1L + "").productId("").productName(request.getProdName()).project(request.getProject()).publicationInfo(null)
						.publishRnabled("").publSubsIdFold("").rcuComments("").rcuDecision("").rcuHold("").receivedDate("").receivedOn("").recoveryItemId("").reimbAccNo("").remarks("")
						.replicatGrpId("").reservationType("").reservOwnersId("").retrievalNames("").retrievalNames2("").roleName(request.getRole()).rootfolder("").scenaridefDocid("")
						.scenarIoDescr("").schemeId("").searchObjstores("").searchObjtype("").searchType(0).secufolderId("").secupolicyId("").securityId("").senton("").sfdcLoanno("")
						.simulationDesc("").simulationGuid("").simulatnStatus("").simulnSpinhour("").sourceDocument("").sourceId(request.getSourceId()).sourceName(request.getSourceName())
						.storageAreaid("").storageClass("").styleTemplate(encryptPassword).targetOcid("").targeToType("").targetSiteId("").toStorename("").totalCount(0).tset_first("")
						.ucic(request.getUcic()!=null ? request.getUcic() : "").uploadDate(getCurrentDate()).uploadedBy(user).uploadPerm("").userName(request.getUserName()).version_status("").versionEnabled("").versionSeriesId("")
						.viewPerm("").vw_version("").xmlDocType("").xmlTargetClass("").agreementId(request.getAgreementId()!=null ? request.getAgreementId() : "").build();

						
						assetStgEntity = stagingFileOperations(assetStgEntity,request,document);
	
						assetStagingRepoImpl.save(assetStgEntity);
	
						docId.put(DOLLAR, assetStgEntity.getDocId());
						status.put(DOLLAR, assetStgEntity.getApiStatus());
	
						uploadDocsResponse.setDocId(docId);
						uploadDocsResponse.setStatus(status);
	
						uploadAcsChckResponse.setException(assetStgEntity.getException());
						uploadAcsChckResponse.setFilenetResponse(assetStgEntity.getEdmsResponse());
						uploadAcsChckResponse.setIsSuccess(assetStgEntity.getIsSuccess());
						uploadAcsChckResponse.setUploadDocumentsResponse(uploadDocsResponse);
						uploadAcsChckResponse.setUploadPermission(assetStgEntity.getUploadPerm());
	
						uploadDocResponse.setUploadDocumentWithAccessCheckResponse(uploadAcsChckResponse);
						response.setProcessedId(assetStgEntity.getProcessedId());
						response.setUploadDocumentResponse(uploadDocResponse);
						response.setNoOfPages(assetStgEntity.getNoOfPages());
						response.setFilePath(assetStgEntity.getFilePath());
						response.setValidDocument(true);
	
						AuditLog auditLog = AuditLog.builder().action(ACTION_UPLD).category(ASSETS).createdBy(user)
								.createdDate(doc.getUploadDate()).currentValue("").customerId(customerId)
								.lastUpdateDate(doc.getModifyDate()).modifiedBy(user).oldValue("").roleName("")
								.productName(request.getProdName()).sourceName(request.getSourceName()).status(SUCCESS)
								.message(user + " uploaded document sucessfully for Assets staging table from "
										+ request.getSourceName())
								.build();
	
						auditLog(auditLog);
					}
				}
				
			} catch (Exception e) {
	
				if (!request.isStagingCheck()) {
					doc.setPk(documentRepository.findAll().size() + 1L);
					doc.setException(EXP_400);
					doc.setApiStatus(REASON_400 + e.getMessage());
					doc.setIsSuccess(NO);
					documentRepository.save(doc);
	
					AuditLog auditLog = AuditLog.builder().action(ACTION_UPLD).category(ASSETS).createdBy(user)
							.createdDate(doc.getUploadDate()).currentValue("").customerId(customerId)
							.lastUpdateDate(doc.getModifyDate()).modifiedBy(user).oldValue("").roleName("")
							.productName(request.getProdName()).sourceName(request.getSourceName()).status(FAILED)
							.message(user + " upload document failed for Assets main table from " + request.getSourceName()
									+ "due to " + e.getMessage())
							.build();
	
					auditLog(auditLog);
	
					throw e;
				}
	
				assetStgEntity.setPk(assetStagingRepoImpl.findAllStaging().size() + 1L);
				assetStgEntity.setException(EXP_400);
				assetStgEntity.setApiStatus(REASON_400 + e.getMessage());
				assetStgEntity.setIsSuccess(NO);
				assetStagingRepoImpl.save(assetStgEntity);
	
				String date = getCurrentDate();
	
				AuditLog auditLog = AuditLog.builder().action(ACTION_UPLD).category(ASSETS).createdBy(user)
						.createdDate(date).currentValue("").agreementId(customerId).lastUpdateDate(date).modifiedBy(user)
						.oldValue("").roleName("").sourceName(request.getSourceName()).status(FAILED)
						.message(user + " tried uploading document for Assets staging table from " + request.getSourceName()
								+ " and it got failed due to " + e.getMessage())
						.build();
	
				auditLog(auditLog);
	
				throw e;
			}
			responses.add(response);
		}
		return responses;
	}

	public int pageCount(String path, AssetEntity msgBdy) {
		File file = new File(path);
		int count = 0;

		String type = null;

		if (file.exists()) {
			log.info("File exists");
			type = file.getName().substring(file.getName().lastIndexOf(".") + 1);

			if (type.equals(".pdf")) {
				PDDocument doc = null;
				try {
					doc = PDDocument.load(file, msgBdy.getEncryptPassword());
				} catch (IOException e) {
					log.error(UPLD_ERR);
					File file1 = new File(path);
					if (file1.exists()) {
						file1.delete();
						}
					throw new GlobalException(e.getMessage());
				}
				if (doc != null)
					count = doc.getNumberOfPages();

			} else {
				count = 1;
			}

		}
		return count;
	}

	public int pageCountStaging(String path, AssetStgEntity msgBdy) {
		File file = new File(path);
		int count = 0;

		String type = null;

		if (file.exists()) {
			log.info("File exists");
			type = file.getName().substring(file.getName().lastIndexOf(".") + 1);

			if (type.equals(".pdf")) {
				PDDocument doc = null;
				try {
					doc = PDDocument.load(file, msgBdy.getEncryptPassword());
				} catch (IOException e) {
					log.error(UPLD_ERR);
					File file1 = new File(path);
					if (file1.exists())
						file1.delete();

					throw new GlobalException(e.getMessage());
				}
				if (doc != null)
					count = doc.getNumberOfPages();

			} else {
				count = 1;
			}

		}
		return count;
	}

	public String getCurrentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MMM/yyyy hh:mm a");
		LocalDateTime now = LocalDateTime.now();

		return (dtf.format(now));

	}

	public String encodeFileToBase64(File file) {
		try {

			log.info("Converting file to base64 string");

			byte[] fileContent = Files.readAllBytes(file.toPath());
			return Base64.getEncoder().encode(fileContent).toString();
		} catch (IOException e) {
			throw new IllegalStateException("could not read file " + file, e);
		}
	}

	@SuppressWarnings("unused")
	public String convertToFile(AddAssetRequest msgBdy, String folderLoc,UploadDocuments document) {
		String path = null;
		try {
			path = convertBase64StringToFile(msgBdy, folderLoc,document);
		} catch (IOException e) {
			log.error(UPLD_ERR);

			// deleting file if it got created
			if (path != null && path.length() > 0) {
				File file = new File(path);
				if (file.exists())
					file.delete();
			}
			throw new GlobalException(e.getMessage());
		}
		return path;
	}

	@SuppressWarnings("resource")
	public String convertBase64StringToFile(AddAssetRequest msgBdy, String location,UploadDocuments document) throws IOException {
		FileOutputStream fos = null;
		try {
			log.info("Converting base64 string to file");
			String documentTitle = Utilities.toValue(document.getObjectBean().getProperty(), 1);
	
			fos = new FileOutputStream(location + SLASH + documentTitle);
	
			byte[] byt = Base64.getDecoder().decode(document.getObjectBean().getContent()
					.substring(document.getObjectBean().getContent().indexOf(',') + 1));
			fos.write(byt);
	
			encrypt(location + SLASH + Utilities.toValue(document.getObjectBean().getProperty(), 1));
	
			return location + SLASH + Utilities.toValue(document.getObjectBean().getProperty(), 1);
		} catch (Exception e) {
			throw new GlobalException(e.getMessage());
		}
	
	}

	public String updateDocumentVersion(AddAssetRequest uploadReq, String docName,UploadDocuments document) {

		try {
			List<AssetEntity> docList = getByCustomer(uploadReq,document);

			log.info("name of the file   : " + docName.substring(0, docName.lastIndexOf(".")));

			return (docName.substring(0, docName.lastIndexOf(".")) + "_Assets_" + uploadReq.getSourceName() + "_V"
					+ (docList.size() + 1) + docName.substring(docName.lastIndexOf(".")));
		} catch (Exception e) {
			throw new GlobalException(e.getMessage());
		}

	}

	public String updateDocumentVersionStaging(AddAssetRequest uploadReq, String docName,UploadDocuments document) {

		try {
			List<AssetStgEntity> docList = getByCustomerStaging(uploadReq,document);

			log.info("name of the file   : " + docName.substring(0, docName.lastIndexOf(".")));

			return (docName.substring(0, docName.lastIndexOf(".")) + "_Assets_" + uploadReq.getSourceName() + "_V"
					+ (docList.size() + 1) + docName.substring(docName.lastIndexOf(".")));
		} catch (Exception e) {
			throw new GlobalException(e.getMessage());
		}

	}

	public List<AssetEntity> getByCustomer(AddAssetRequest request,UploadDocuments document) {

		try {
			List<Property> properties = document.getObjectBean().getProperty();
			String sourceName = request.getSourceName();
			String docName = Utilities.toValue(properties, 0);
			String custId = Utilities.toValue(properties, 7);
			String documentTypeName = request.getDocumentType();
			return documentRepository
					.findByCustomerIdAndDocNameAndDocType(sourceName, docName, custId, documentTypeName);
		} catch (Exception e) {
			e.printStackTrace();
			throw new GlobalException(e.getMessage());
		}
	}

	public List<AssetStgEntity> getByCustomerStaging(AddAssetRequest request,UploadDocuments document) {

		try {
			List<Property> properties = document.getObjectBean().getProperty();

			String docName = Utilities.toValue(properties, 0);
			String custId = Utilities.toValue(properties, 7);
			String documentTypeName = request.getDocumentType();
			return assetStagingRepoImpl
					.findByCustomerIdAndDocNameAndDocType(request.getSourceName(), docName, custId, documentTypeName);
		} catch (Exception e) {
			throw new GlobalException(e.getMessage());
		}
	}

	private String generateRandomSecretKey() {
		StringBuilder sb = new StringBuilder(16);
		for (int i = 0; i < 16; i++) {
			sb.append(CHARACTERS.charAt(RANDOM.nextInt(CHARACTERS.length())));
		}
		return sb.toString();
	}

	public String encryptPassword(String password) throws Exception {
		String result = "";
		try {
			byte[] iv = new byte[12];
			new SecureRandom().nextBytes(iv);
			passwordkey = generateRandomSecretKey();
			SecretKey secretKey = generateSecretKey(passwordkey, iv);

			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);

			// Encryption mode on!
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);

			byte[] ciphertext = cipher.doFinal(password.getBytes(StandardCharsets.UTF_8));
			byte[] encrypted = new byte[iv.length + ciphertext.length];
			System.arraycopy(iv, 0, encrypted, 0, iv.length);
			System.arraycopy(ciphertext, 0, encrypted, iv.length, ciphertext.length);

			result = Base64.getEncoder().encodeToString(encrypted);
			// Return encrypted string

		} catch (Exception e) {
			log.error("Error occured while encrypting password");
			throw e;
		}
		return result;
	}

	private void encrypt(String path)
			throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {

		ByteBuffer byteBuffer = null;
		try (FileInputStream inFile = new FileInputStream(path)) {
			SecureRandom secureRandom = new SecureRandom();

			// Noonce should be 12 bytes
			byte[] iv = new byte[12];
			secureRandom.nextBytes(iv);

			docKey = generateRandomSecretKey();
			// Prepare your key/password
			SecretKey secretKey = generateSecretKey(docKey, iv);

			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);

			// Encryption mode on!
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);

			// Encrypt the data
			byte[] encryptedData = cipher.doFinal(IOUtils.toByteArray(inFile));

			// Concatenate everything and return the final data
			byteBuffer = ByteBuffer.allocate(4 + iv.length + encryptedData.length);
			byteBuffer.putInt(iv.length);
			byteBuffer.put(iv);
			byteBuffer.put(encryptedData);
		}
		try (FileOutputStream fos = new FileOutputStream(path)) {
			fos.write(byteBuffer.array());
		}
	}

	private SecretKey generateSecretKey(String password, byte[] iv)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeySpec spec = new PBEKeySpec(password.toCharArray(), iv, 65536, 128); // AES-128
		SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
		byte[] key = secretKeyFactory.generateSecret(spec).getEncoded();
		return new SecretKeySpec(key, "AES");
	}

	private String generateTemporaryCustomerId(List<AssetStgEntity> stagingDocList, String agreementId) {
		String stagingCustId = stagingDocList.stream()
				.filter(f -> f.getIsSuccess() != null && f.getIsSuccess().equals(YES))
				.filter(f -> f.getAgreementId().equals(agreementId)).map(AssetStgEntity::getCustomerId).findFirst()
				.orElse(null);

		if (stagingCustId == null) {
			String tempCustId = stagingDocList.stream().map(AssetStgEntity::getCustomerId).filter(Objects::nonNull)
					.max(Comparator.naturalOrder()).orElse(null);

			stagingCustId = "Temp"
					+ String.format("%012d", (tempCustId != null) ? Long.valueOf(tempCustId.substring(4)) + 1 : 1);

			return stagingCustId;
		}

		return stagingCustId;
	}

	@Async
	public void auditLog(AuditLog auditLog) {
		auditLogClient.addAuditLog(auditLog);
	}
	

}
