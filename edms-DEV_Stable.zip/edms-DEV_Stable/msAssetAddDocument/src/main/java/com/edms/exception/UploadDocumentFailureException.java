package com.edms.exception;

public class UploadDocumentFailureException extends Exception {

	private static final long serialVersionUID = 1L;

	public UploadDocumentFailureException(String errorMessage) {
		super(errorMessage);
	}
}
