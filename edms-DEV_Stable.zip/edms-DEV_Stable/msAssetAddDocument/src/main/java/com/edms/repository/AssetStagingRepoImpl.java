package com.edms.repository;

import java.util.List;
import java.util.stream.Collectors;

import com.aerospike.client.query.Filter;
import com.aerospike.mapper.tools.AeroMapper;
import com.edms.model.AssetEntity;
import com.edms.model.AssetStgEntity;

import jakarta.inject.Inject;
import jakarta.inject.Singleton;

@Singleton
public class AssetStagingRepoImpl {

	@Inject
	AeroMapper aeroMapper;
	
	public List<AssetStgEntity> findAllStaging() {
		return aeroMapper.scan(AssetStgEntity.class);
	}

	public void save(AssetStgEntity assetStgEntity) {
		
		aeroMapper.save(assetStgEntity);
		
	}
	
	
	public List<AssetStgEntity> findByCustomerIdAndDocNameAndDocType(String source, String documentName, String customerId,
			String docTypeName) {
		List<AssetStgEntity> allData = aeroMapper.scan(AssetStgEntity.class);

		return allData.stream()
				.filter(doc -> (!doc.getCustomerId().isEmpty() && doc.getCustomerId().equalsIgnoreCase(customerId))
						&& (!doc.getDocumentType().isEmpty() && doc.getDocumentType().equals(docTypeName))
						&& (!doc.getDocumentName().isEmpty() && doc.getDocumentName().equals(documentName))
						&& (!doc.getSourceName().isEmpty() && doc.getSourceName().equals(source)))
				.collect(Collectors.toList());

	}

	public List<AssetStgEntity> findByDocId(String value){

		return aeroMapper.query(AssetStgEntity.class, Filter.equal("DOCID", value));
	}
}
