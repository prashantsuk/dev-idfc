package com.edms.service;


import com.edms.client.AuditLogClient;
import com.edms.exception.UserException;
import com.edms.model.*;
import com.edms.repository.AssetStagingRepoImpl;
import com.edms.repository.DocumentRepository;
import io.micronaut.context.annotation.Value;
import io.micronaut.scheduling.annotation.Async;
import jakarta.inject.Inject;
import jakarta.inject.Singleton;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.*;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.pdfbox.io.IOUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.InvalidParameterSpecException;
import java.security.spec.KeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;
import java.util.List;

import static com.edms.util.Constants.*;

@Singleton
@Slf4j
public class ViewDocServiceImpl implements ViewDocService {
	
	@Value("${file.locationPath}")
	private String fileLocation;
	
	@Inject
	DocumentRepository edpAssetsRepo;
	
	@Inject
	AssetStagingRepoImpl assetsStagingRepo;
	
	@Inject
	AuditLogClient auditLogClient;
	
	
	public Response viewDoc(String docIndx, String tableType, String user) throws UserException, IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidParameterSpecException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException
	{
		log.info("Get document meta data started");
		
		String date=getCurrentDate();
		
		if(tableType.equals("Main"))
		{
			log.info("Checking in main table");
			
			List<AssetEntity> assetEntityList =edpAssetsRepo.findAll();
			
			if(assetEntityList.isEmpty())
				throw new UserException("Document details not found");
			
			AssetEntity assetEntity=assetEntityList.stream().filter(f->f.getDocId().equals(docIndx)).findFirst().orElse(null);
			
			if(assetEntity==null)
				throw new UserException("Document details not found");
			
			File file=new File(fileLocation+"/"+assetEntity.getCustomerId()+"/"+assetEntity.getFileName());
			
			if(!file.exists())
				throw new UserException("File not found");
				
			String base64String=encodeFileToBase64(fileLocation+"/"+assetEntity.getCustomerId()+"/"+assetEntity.getFileName(),assetEntity.getDocEncryptKey());
			
			AuditLog auditLog=AuditLog.builder().action(ACTION_VIEW).createdBy(user).createdDate(date).currentValue("").lastUpdateDate(date).modifiedBy(user).oldValue("").roleName("").sourceName(assetEntity.getSourceName())
					.productName(assetEntity.getProductName()).status(SUCCESS).category(ASSETS).customerId(assetEntity.getCustomerId()).message(user+" viewed document for customer id : "+assetEntity.getCustomerId()+" successfully").build();
			
			auditLog(auditLog);
			
			return buildMetaDataAssets(assetEntity,base64String,null);
		}
		
		log.info("Checking in staging table");
		
		List<AssetStgEntity>assetStagingEntityList=assetsStagingRepo.findAllStaging();
		
		if(assetStagingEntityList.isEmpty())
			throw new UserException("Document details not found");
		
		AssetStgEntity assetStagingEntity=assetStagingEntityList.stream().filter(f->f.getDocId().equals(docIndx)).findFirst().orElse(null);
		
		if(assetStagingEntity==null)
			throw new UserException("Document details not found");
		
		File file=new File(fileLocation+"/"+assetStagingEntity.getAgreementId()+"/"+assetStagingEntity.getFileName());
		
		if(!file.exists())
			throw new UserException("File not found");
			
		String base64String=encodeFileToBase64(fileLocation+"/"+assetStagingEntity.getAgreementId()+"/"+assetStagingEntity.getFileName(),assetStagingEntity.getDocEncryptKey());
		
		AuditLog auditLog=AuditLog.builder().action(ACTION_VIEW).createdBy(user).createdDate(date).currentValue("").lastUpdateDate(date).modifiedBy(user).oldValue("").roleName("").sourceName(assetStagingEntity.getSourceName())
				.productName(assetStagingEntity.getProductName()).status(SUCCESS).category(ASSETS).customerId(assetStagingEntity.getCustomerId()).message(user+" view document for customer id : "+assetStagingEntity.getCustomerId()).build();
		
		auditLog(auditLog);
		
		return buildMetaDataAssets(null,base64String,assetStagingEntity);
		
	}
	
	
	private String encodeFileToBase64(String path, String key) throws IOException, InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidParameterSpecException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {
	    
	    log.info("Converting file to base64 string");
	    	
	    byte[] fileContent = decrypt(path,key);
	    return Base64.getEncoder().encodeToString(fileContent);
	   
	}
	
	private Response buildMetaDataAssets(AssetEntity entity,String base64String, AssetStgEntity assetsStaging)
	{
		if(assetsStaging==null)
		{
			return Response.builder().msgHdr(MsgHdr.builder().rslt(OK).build()).msgBdy(MsgBdy.builder().sts("0").msg(SUCCESS)
					.bs64Doc(base64String).fileName(entity.getDocumentTitle()).fileType(entity.getFileType()).build()).build();
		}
		
		return Response.builder().msgHdr(MsgHdr.builder().rslt(OK).build()).msgBdy(MsgBdy.builder().sts("0").msg(SUCCESS)
				.bs64Doc(base64String).fileName(assetsStaging.getDocumentTitle()).fileType(assetsStaging.getFileType()).build()).build();
	}
	
	
	private SecretKey generateSecretKey(String password, byte [] iv) throws NoSuchAlgorithmException, InvalidKeySpecException {
        KeySpec spec = new PBEKeySpec(password.toCharArray(), iv, 65536, 128); // AES-128
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        byte[] key = secretKeyFactory.generateSecret(spec).getEncoded();
        return new SecretKeySpec(key, "AES");
    }
    
    
    private byte[] decrypt(String path, String key) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException
    {
    	try (FileInputStream fis = new FileInputStream(path)) {
			ByteBuffer byteBuffer = ByteBuffer.wrap(IOUtils.toByteArray(fis));

			  int noonceSize = byteBuffer.getInt();

			  //Make sure that the file was encrypted properly
			  if(noonceSize < 12 || noonceSize >= 16) {
			      throw new IllegalArgumentException("Nonce size is incorrect. Make sure that the incoming data is an AES encrypted file.");
			  }
			  byte[] iv = new byte[noonceSize];
			  byteBuffer.get(iv);

			  //Prepare your key/password
			  SecretKey secretKey = generateSecretKey(key, iv);

			  //get the rest of encrypted data
			  byte[] cipherBytes = new byte[byteBuffer.remaining()];
			  byteBuffer.get(cipherBytes);

			  Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			  GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);

			  //Encryption mode on!
			  cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);

			  //Encrypt the data
			  return cipher.doFinal(cipherBytes);
			  
		}
    }
    
    private String getCurrentDate() {
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FORMAT);
		LocalDateTime now = LocalDateTime.now();

		return (dtf.format(now));
	}
    
    
    @Async
	public void auditLog(AuditLog auditLog) {
		auditLogClient.addAuditLog(auditLog);
	}
}