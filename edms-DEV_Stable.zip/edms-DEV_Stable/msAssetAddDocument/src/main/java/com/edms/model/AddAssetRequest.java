package com.edms.model;
import java.util.List;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AddAssetRequest {

	private List<UploadDocuments> uploadDocuments;
	private String project;
	private String role;
	private String customerId;
	private String documentType;
	private String documentName;
	private Integer docTypeId;
	private String password;
	private String mimeType;
	private String sourceName;
	private Integer sourceId;
	private String prodName;
	private String userName;
	private String isSuccess;
	private String apiStatus;
	private String exception;
	private String ucic;
	private String agreementId;
	private boolean stagingCheck;

}
