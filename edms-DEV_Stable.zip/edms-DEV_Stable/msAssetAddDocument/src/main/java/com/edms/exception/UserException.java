package com.edms.exception;

public class UserException extends Exception{
	
	private static final long serialVersionUID = 5307691644958182739L;
	
	public UserException(String msg) {
		
		super(msg);
	}

}
