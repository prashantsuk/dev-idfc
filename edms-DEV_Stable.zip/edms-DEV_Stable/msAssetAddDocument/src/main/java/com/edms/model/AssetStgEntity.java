package com.edms.model;

import java.sql.Blob;

import com.aerospike.mapper.annotations.AerospikeBin;
import com.aerospike.mapper.annotations.AerospikeKey;
import com.aerospike.mapper.annotations.AerospikeRecord;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@AerospikeRecord(namespace = "test", set = "stg_edp_assets")
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AssetStgEntity {
	
	@AerospikeKey
	@AerospikeBin(name = "PK")
	private Long pk;
	@AerospikeBin(name ="ACCEPTEDBY")
	private String acceptedBy;
	@AerospikeBin(name ="ACCEPTEDDATE")
	private String acceptedDate;
	@AerospikeBin(name ="ACTUALFILESIZE")
	private String actualFileSize;
	@AerospikeBin(name ="ACCOUNTNUMBER")
	private String accountNumber;
	@AerospikeBin(name ="AGREEMENTID")
	private String agreementId;
	@AerospikeBin(name ="APISTATUS")
	private String apiStatus;
	@AerospikeBin(name ="APPLICANTTYPE")
	private String applicantType;
	@AerospikeBin(name ="APPLICATIONID")
	private String applicationId;
	@AerospikeBin(name ="APPLICATIONNAME")
	private String applicationName;
	@AerospikeBin(name ="BARCODENO")
	private String barcodeNo;
	@AerospikeBin(name ="BPMLOANNUMBER")
	private String bpmLoanNumber;
	@AerospikeBin(name ="BRANCHID")
	private String branchId;
	@AerospikeBin(name ="CASEID")
	private String caseId;
	@AerospikeBin(name ="CATEGORY")
	private String category;
	@AerospikeBin(name ="CHECKEDINDATE")
	private String checkedInDate;
	@AerospikeBin(name ="CLASSIFICASTATE")
	private String classificaState;
	@AerospikeBin(name ="CMSEARCHSCVER")
	private String cmsearchScver;
	@AerospikeBin(name ="COMMENTS")
	private String comments;
	@AerospikeBin(name ="COMPBINDLABEL")
	private String compBindLabel;
	@AerospikeBin(name ="COMPDOCSTATE")
	private Integer compDocState;
	@AerospikeBin(name ="COMPRESFILESIZE")
	private String compresFileSize;
	@AerospikeBin(name ="COMPTYPES")
	private String compTypes;
	@AerospikeBin(name ="COMPTYPES2")
	private String compTypes2;
	@AerospikeBin(name ="CONNECTORID")
	private String connectorId;
	@AerospikeBin(name ="CONSIDERATION")
	private String consideration;
	@AerospikeBin(name ="CONTENT")
	private String content;
	@AerospikeBin(name ="CONTENTINFO2")
	private String contentInfo2;
	@AerospikeBin(name ="CONTENTLADATE")
	private String contentlaDate;
	@AerospikeBin(name ="CONTENTREFBLOB")
	private String contentrefBlob;
	@AerospikeBin(name ="CONTENTRETNDATE")
	private String contentretnDate;
	@AerospikeBin(name ="CREATEDDATE")
	private String createdDate;
	@AerospikeBin(name ="CREATEDBY")
	private String createdBy;
	@AerospikeBin(name ="CRMID")
	private String crmId;
	@AerospikeBin(name ="CRNNO")
	private String crnNo;
	@AerospikeBin(name ="CRNNONEW")
	private String crnnoNew;
	@AerospikeBin(name ="CUSTOMERID")
	private String customerId;
	@AerospikeBin(name ="CUSTOMERNAME")
	private String customerName;
	@AerospikeBin(name ="CUSTOMERRELNO")
	private String customerRelNo;
	@AerospikeBin(name ="CUSTOMERTYPE")
	private String customerType;
	@AerospikeBin(name ="DEALERONBOARDID")
	private String dealerOnboardId;
	@AerospikeBin(name ="DEFEREDDATE")
	private String deferedDate;
	@AerospikeBin(name ="DESCRIPTION")
	private String description;
	@AerospikeBin(name ="DATACLASS")
	private String dataClass;
	@AerospikeBin(name ="DOCENCRYPTKEY")
	private String docEncryptKey;
	@AerospikeBin(name ="DOCEXPIRYDATE")
	private String docExpirydate;
	@AerospikeBin(name ="DOCID")
	private String docId;
	@AerospikeBin(name ="DOCLIFECYPOLICY")
	private String docLifecyPolicy;
	@AerospikeBin(name ="DOCPASSWORD")
	private String docPasswd;
	@AerospikeBin(name ="DOCSTATUS")
	private String docState;
	@AerospikeBin(name ="DOCTYPEID")
	private String docTypeId;
	@AerospikeBin(name ="DOCUMENTNAME")
	private String documentName;
	@AerospikeBin(name ="DOCUMENTNO")
	private Integer documentNo;
	@AerospikeBin(name ="DOCUMENTREMARK")
	private String documentRemark;
	@AerospikeBin(name ="DOCUMENTSTATUS")
	private String documentStatus;
	@AerospikeBin(name ="DOCUMENTTITLE")
	private String documentTitle;
	@AerospikeBin(name ="DOCTYPENAME")
	private String documentType;
	@AerospikeBin(name ="DOCUMENTTYPE")
	private String documentTypeId;
	@AerospikeBin(name ="DOCUMENTVERSION")
	private Integer documentVersion;
	@AerospikeBin(name ="DOCUPLOADED")
	private String docUploaded;
	@AerospikeBin(name ="DOCUPLOADID")
	private String docUploadId;
	@AerospikeBin(name ="DYUPDATESTATUS")
	private String dyUpdateStatus;
	@AerospikeBin(name ="EDPRESPONSE")
	private String edmsResponse;
	@AerospikeBin(name ="EDPID")
	private String edpId;
	@AerospikeBin(name ="EMAILID")
	private String emailId;
	@AerospikeBin(name ="EMAILSUBJECT")
	private String emailSubject;
	@AerospikeBin(name ="ENCRYPTPASSWORD")
	private String encryptPassword;
	@AerospikeBin(name ="ENTRYTEMPLATE")
	private String entryTemplate;
	@AerospikeBin(name ="ENTRYTEMPLATEID")
	private String entryTemplateId;
	@AerospikeBin(name ="ENTRYTEMPLDESC")
	private String entryTemplDesc;
	@AerospikeBin(name ="ENTRYTOBJSTORE")
	private String entryTobjstore;
	@AerospikeBin(name ="EPOCHID")
	private Integer epochId;
	@AerospikeBin(name ="EXCPTN_CUSTOM")
	private String exception;
	@AerospikeBin(name ="EXPIRYDATE")
	private String expiryDate;
	@AerospikeBin(name ="FILETYPE")
	private String fileType;
	@AerospikeBin(name ="FILENAME")
	private String fileName;
	@AerospikeBin(name ="FINNONELOANNO")
	private String finnOneLoanNo;
	@AerospikeBin(name ="FORMDESCRIPTION")
	private String formDescription;
	@AerospikeBin(name ="FORMPLCSTEPDESC")
	private String formPlcStepdesc;
	@AerospikeBin(name ="FORMPOLICY")
	private String formPolicy;
	@AerospikeBin(name ="FORMPOLICYDESC")
	private String formPolicyDesc;
	@AerospikeBin(name ="FORMPOLICYLWFL")
	private String formPolicylWfl;
	@AerospikeBin(name ="FORMPOLICYWFID")
	private String formPolicyWfId;
	@AerospikeBin(name ="FORMPWFOBJECT")
	private String formPwfObject;
	@AerospikeBin(name ="FORMTEMPLATE")
	private String formTemplate;
	@AerospikeBin(name ="FORMTYPE")
	private String formType;
	@AerospikeBin(name ="FROM")
	private String from;
	@AerospikeBin(name ="GEOLOCATION")
	private String geoLocation;
	@AerospikeBin(name ="HOMEID")
	private String homeId;
	@AerospikeBin(name ="ICNAUTORUN")
	private Integer icnAutoRun;
	@AerospikeBin(name ="ICNCLASSNAME")
	private String icnClassName;
	@AerospikeBin(name ="ICNSEARCHREPO")
	private String icnSearchRepo;
	@AerospikeBin(name ="ICNSHOWINTREE")
	private String icnShowInTree;
	@AerospikeBin(name ="ICNWORKFLOWNAME")
	private String icnWorkflowName;
	@AerospikeBin(name ="ID")
	private Long Id;
	@AerospikeBin(name ="IGNOREREDIRECT")
	private String ignorereDirect;
	@AerospikeBin(name ="INDEXATIONID")
	private String indexationId;
	@AerospikeBin(name ="INDEXFAILCODE")
	private Integer indexFailCode;
	@AerospikeBin(name ="INGESTIONSOURCE")
	private String ingestionSource;
	@AerospikeBin(name ="IS_CURRENT")
	private Integer is_current;
	@AerospikeBin(name ="IS_FROZEN")
	private Integer is_frozen;
	@AerospikeBin(name ="IS_IN_EXSTATE")
	private Integer is_in_exstate;
	@AerospikeBin(name ="IS_RESERVED")
	private Integer is_reserved;
	@AerospikeBin(name ="ISSUCCESS")
	private String isSuccess;
	@AerospikeBin(name ="ITXFORMTEMPLATE")
	private String itxFormTemplate;
	@AerospikeBin(name ="LATITUDE")
	private String latitude;
	@AerospikeBin(name ="LAYOUTID")
	private String layoutId;
	@AerospikeBin(name ="LAYOUTVERSRID")
	private String layoutVersrId;
	@AerospikeBin(name ="LOCKOWNER")
	private String lockOwner;
	@AerospikeBin(name ="LOCKSID")
	private String lockSid;
	@AerospikeBin(name ="LOCKTIMEOUT")
	private Integer lockTimeout;
	@AerospikeBin(name ="LOCKTOKEN")
	private String lockToken;
	@AerospikeBin(name ="LONGITUDE")
	private String longitude;
	@AerospikeBin(name ="MAJORVERNO")
	private Integer majorVerNo;
	@AerospikeBin(name ="MANDATORY")
	private String mandatory;
	@AerospikeBin(name ="MIGRATIONID")
	private Integer migrationId;
	@AerospikeBin(name ="MIMETYPE")
	private String mimeType;
	@AerospikeBin(name ="MINORVERNO")
	private Integer minorVerNo;
	@AerospikeBin(name ="MOBILENUMBER")
	private Long mobileNo;
	@AerospikeBin(name ="MODIFIEDDATE")
	private String modifyDate;
	@AerospikeBin(name ="MODIFYUSER")
	private String modifyUser;
	@AerospikeBin(name ="MULTIPAGEDOC")
	private String multipageDoc;
	@AerospikeBin(name ="NEXTCONTENTUID")
	private Integer nextContentUid;
	@AerospikeBin(name ="NOOFPAGES")
	private Integer noOfPages;
	@AerospikeBin(name ="OBJECTCLASSID")
	private String objectClassId;
	@AerospikeBin(name ="OBJECTID")
	private String objectId;
	@AerospikeBin(name ="ORIGPHOTOCOPY")
	private String origPhotoCopy;
	@AerospikeBin(name ="OWNER")
	private String owner;
	@AerospikeBin(name ="OWNERDOCUMENT")
	private String ownerDocument;
	@AerospikeBin(name ="OWNERTYPE")
	private String ownerType;
	@AerospikeBin(name ="PAGENO")
	private Integer pageNo;
	@AerospikeBin(name ="PASSKEYPATH")
	private String passKeyPath;
	@AerospikeBin(name ="PREFERENCETYPE")
	private String preferenceType;
	@AerospikeBin(name ="PROCESSEDID")
	private String processedId;
	@AerospikeBin(name ="PRODUCTID")
	private String productId;
	@AerospikeBin(name ="PRODUCTNAME")
	private String productName;
	@AerospikeBin(name ="PROJECT")
	private String project;
	@AerospikeBin(name ="PUBLICATIONINFO")
	private Blob publicationInfo;
	@AerospikeBin(name ="PUBLISHENABLED")
	private String publishRnabled;
	@AerospikeBin(name ="PUBLSUBSIDFOLD")
	private String publSubsIdFold;
	@AerospikeBin(name ="RCUCOMMENTS")
	private String rcuComments;
	@AerospikeBin(name ="RCUDECISION")
	private String rcuDecision;
	@AerospikeBin(name ="RCUHOLD")
	private String rcuHold;
	@AerospikeBin(name ="RECEIVEDDATE")
	private String receivedDate;
	@AerospikeBin(name ="RECEIVEDON")
	private String receivedOn;
	@AerospikeBin(name ="RECOVERYITEMID")
	private String recoveryItemId;
	@AerospikeBin(name ="REIMBACCNO")
	private String reimbAccNo;
	@AerospikeBin(name ="REMARKS")
	private String remarks;
	@AerospikeBin(name ="REPLICATGRPID")
	private String replicatGrpId;
	@AerospikeBin(name ="RESERVATIONTYPE")
	private String reservationType;
	@AerospikeBin(name ="RESERVOWNERSID")
	private String reservOwnersId;
	@AerospikeBin(name ="RETRIEVALNAMES")
	private String retrievalNames;
	@AerospikeBin(name ="RETRIEVALNAMES2")
	private String retrievalNames2;
	@AerospikeBin(name ="ROLENAME")
	private String roleName;
	@AerospikeBin(name ="ROOTFOLDER")
	private String rootfolder;
	@AerospikeBin(name ="SCENARIDEFDOCID")
	private String scenaridefDocid;
	@AerospikeBin(name ="SCENARIODESCR")
	private String scenarIoDescr;
	@AerospikeBin(name ="SCHEMEID")
	private String schemeId;
	@AerospikeBin(name ="SEARCHOBJSTORES")
	private String searchObjstores;
	@AerospikeBin(name ="SEARCHOBJTYPE")
	private String searchObjtype;
	@AerospikeBin(name ="SEARCHTYPE")
	private Integer searchType;
	@AerospikeBin(name ="SECUFOLDERID")
	private String secufolderId;
	@AerospikeBin(name ="SECUPOLICYID")
	private String secupolicyId;
	@AerospikeBin(name ="SECURITYID")
	private String securityId;
	@AerospikeBin(name ="SENTON")
	private String senton;
	@AerospikeBin(name ="SFDCLOANNO")
	private String sfdcLoanno;
	@AerospikeBin(name ="SIMULATIONDESC")
	private String simulationDesc;
	@AerospikeBin(name ="SIMULATIONGUID")
	private String simulationGuid;
	@AerospikeBin(name ="SIMULATNSTATUS")
	private String simulatnStatus;
	@AerospikeBin(name ="SIMULNSPINHOUR")
	private String simulnSpinhour;
	@AerospikeBin(name ="SOURCEID")
	private Integer sourceId;
	@AerospikeBin(name ="SOURCENAME")
	private String sourceName;
	@AerospikeBin(name ="SOURCEDOCUMENT")
	private String sourceDocument;
	@AerospikeBin(name ="SOURCELOANNO")
	private String sourceLoanno;
	@AerospikeBin(name ="STORAGEAREAID")
	private String storageAreaid;
	@AerospikeBin(name ="STORAGECLASS")
	private String storageClass;
	@AerospikeBin(name ="FILEPATH")
	private String filePath;
	@AerospikeBin(name ="STYLETEMPLATE")
	private String styleTemplate;
	@AerospikeBin(name ="TARGETOCID")
	private String targetOcid;
	@AerospikeBin(name ="TARGETOTYPE")
	private String targeToType;
	@AerospikeBin(name ="TARGETSITEID")
	private String targetSiteId;
	@AerospikeBin(name ="TOSTORENAME")
	private String toStorename;
	@AerospikeBin(name ="totalcount")
	private Integer totalCount;
	@AerospikeBin(name ="TSET_FIRST")
	private String tset_first;
	@AerospikeBin(name = "UCIC")
	private String ucic;
	@AerospikeBin(name ="USERNAME")
	private String userName;
	@AerospikeBin(name ="UPLOADEDDATE")
	private String uploadDate;
	@AerospikeBin(name ="UPLOADEDBY")
	private String uploadedBy;
	@AerospikeBin(name ="UPLOADPERM")
	private String uploadPerm;
	@AerospikeBin(name ="VERSION_STATUS")
	private String version_status;
	@AerospikeBin(name ="VERSIONENABLED")
	private String versionEnabled;
	@AerospikeBin(name ="VERSIONSERIESID")
	private String versionSeriesId;
	@AerospikeBin(name ="VIEWPERM")
	private String viewPerm;
	@AerospikeBin(name ="VW_VERSION")
	private String vw_version;
	@AerospikeBin(name ="XMLDOCTYPE")
	private String xmlDocType;
	@AerospikeBin(name ="XMLTARGETCLASS")
	private String xmlTargetClass;
	
}
