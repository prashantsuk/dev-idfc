package com.edms.controller;

import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

import com.edms.service.DownloadDocServiceImpl;

import io.micronaut.core.annotation.Nullable;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.QueryValue;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.authentication.Authentication;
import io.micronaut.security.rules.SecurityRule;
import jakarta.inject.Inject;
import lombok.extern.slf4j.Slf4j;

@Controller("/download")
@Slf4j
@Secured(SecurityRule.IS_AUTHENTICATED)
public class AssetDownloadDocumentController {


	@Inject
	private DownloadDocServiceImpl downloadDocServiceImpl;
	
	@Get
	public HttpResponse<byte[]> downloadFile(@QueryValue String docId, @QueryValue String tableType, @Nullable Authentication authentication) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException, IOException {
	   
		log.info(authentication.getName()+" started view document for doc Id : {} from : {} table",docId,tableType);
		
		return downloadDocServiceImpl.downloadFile(docId,tableType,authentication.getName());
	}
}
