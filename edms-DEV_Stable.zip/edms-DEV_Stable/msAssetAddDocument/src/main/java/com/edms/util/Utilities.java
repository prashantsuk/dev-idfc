package com.edms.util;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.math.BigInteger;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import org.apache.pdfbox.io.IOUtils;

import com.edms.exception.GlobalException;
import com.edms.model.Property;

import lombok.extern.slf4j.Slf4j;

import static com.edms.util.Constants.*;

@Slf4j
public class Utilities {

	

	private static final SecureRandom RANDOM = new SecureRandom();
	
	private static String generateRandomSecretKey() {
		StringBuilder sb = new StringBuilder(16);
		for (int i = 0; i < 16; i++) {
			sb.append(CHARACTERS.charAt(RANDOM.nextInt(CHARACTERS.length())));
		}
		return sb.toString();
	}

	public static String encryptPassword(String password) throws Exception {
		
		String result = "";
		try {
			byte[] iv = new byte[12];
			new SecureRandom().nextBytes(iv);
			String passwordkey = null;
			passwordkey = generateRandomSecretKey();
			SecretKey secretKey = generateSecretKey(passwordkey, iv);

			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);

			// Encryption mode on!
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);

			byte[] ciphertext = cipher.doFinal(password.getBytes(StandardCharsets.UTF_8));
			byte[] encrypted = new byte[iv.length + ciphertext.length];
			System.arraycopy(iv, 0, encrypted, 0, iv.length);
			System.arraycopy(ciphertext, 0, encrypted, iv.length, ciphertext.length);

			result = Base64.getEncoder().encodeToString(encrypted);
			// Return encrypted string

		} catch (Exception e) {
			log.error("Error occured while encrypting password");
			throw new Exception("Error occured while encrypting password");
		}
		return result;
	}

	public static void encrypt(String path)
			throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException {

		ByteBuffer byteBuffer = null;
		String docKey = null;
		try (FileInputStream inFile = new FileInputStream(path)) {
			SecureRandom secureRandom = new SecureRandom();

			// Noonce should be 12 bytes
			byte[] iv = new byte[12];
			secureRandom.nextBytes(iv);

			docKey = generateRandomSecretKey();
			// Prepare your key/password
			SecretKey secretKey = generateSecretKey(docKey, iv);

			Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);

			// Encryption mode on!
			cipher.init(Cipher.ENCRYPT_MODE, secretKey, parameterSpec);

			// Encrypt the data
			byte[] encryptedData = cipher.doFinal(IOUtils.toByteArray(inFile));

			// Concatenate everything and return the final data
			byteBuffer = ByteBuffer.allocate(4 + iv.length + encryptedData.length);
			byteBuffer.putInt(iv.length);
			byteBuffer.put(iv);
			byteBuffer.put(encryptedData);
		}
		try (FileOutputStream fos = new FileOutputStream(path)) {
			fos.write(byteBuffer.array());
		}
	}
	
	public static Double calcBase64SizeInKb(String base64String) {
		   
		log.info("Calculating size of base64 string");
	        Integer padding = 0;
	        if(base64String.endsWith("==")) {
	            padding = 2;
	        }
	        else {
	            if (base64String.endsWith("=")) padding = 1;
	        }
	        Double result =  (((double)base64String.length() / 4) * 3  - padding);
	    
	    return result / (1024);
	}

	private static SecretKey generateSecretKey(String password, byte[] iv)
			throws NoSuchAlgorithmException, InvalidKeySpecException {
		KeySpec spec = new PBEKeySpec(password.toCharArray(), iv, 65536, 128); // AES-128
		SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
		byte[] key = secretKeyFactory.generateSecret(spec).getEncoded();
		return new SecretKeySpec(key, "AES");
	}
	
	public static String toValue(List<Property> property,Integer index){
		return property.stream().filter(p -> p.getPropertyName().equals(ASSET_PROPERTIES[index]))
		.map(Property::getPropertyValue).findFirst().orElse("");
	}
}
