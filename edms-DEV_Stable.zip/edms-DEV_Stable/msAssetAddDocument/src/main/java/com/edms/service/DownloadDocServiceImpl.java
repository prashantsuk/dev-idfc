package com.edms.service;

import java.io.FileInputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import com.edms.model.AssetEntity;
import com.edms.model.AssetStgEntity;
import com.edms.repository.AssetStagingRepoImpl;
import com.edms.repository.DocumentRepository;
import org.apache.pdfbox.io.IOUtils;

import com.edms.client.AuditLogClient;
import com.edms.model.AuditLog;

import io.micronaut.context.annotation.Value;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpResponse;
import io.micronaut.scheduling.annotation.Async;
import jakarta.inject.Inject;
import static com.edms.util.Constants.*;

public class DownloadDocServiceImpl implements DownloadDocService {

	@Value("${file.locationPath}")
	private String fileLocation;
	
	@Inject
	DocumentRepository assetsRepoImpl;
	
	@Inject
	AssetStagingRepoImpl assetStagingRepoImpl;
	
	@Inject
	AuditLogClient auditLogClient;
	
	public HttpResponse<byte[]> downloadFile(String docId, String tableType, String user) throws InvalidKeyException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException, IOException
	{
		byte[] content=null;
		String date=getCurrentDate();
		
		if(tableType.equals("Main"))
		{
			List<AssetEntity> edpAsset=assetsRepoImpl.findByDocId(docId);
			
			if(!edpAsset.isEmpty())
			{
				content =decrypt(fileLocation+"/"+edpAsset.get(0).getCustomerId()+SLASH+edpAsset.get(0).getFileName(),edpAsset.get(0).getDocEncryptKey());
				
				AuditLog auditLog=AuditLog.builder().action(ACTION_DWNLD).createdBy(user).createdDate(date).currentValue("").lastUpdateDate(date).modifiedBy(user).oldValue("").roleName("")	
						.status(SUCCESS).category(ASSETS).customerId(edpAsset.get(0).getCustomerId()).message(user+" downloaded document for customer id : "+edpAsset.get(0).getCustomerId()+ " successfully").build() ;
				
				auditLog(auditLog);
		    // Return the response with the file as an InputStream
			    return HttpResponse.ok().contentLength(0)
			    		.header(HttpHeaders.CONTENT_TYPE, edpAsset.get(0).getFileType())
		                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+edpAsset.get(0).getDocumentTitle())
		                .body(content);
			}
			return null;
		}
		
		List<AssetStgEntity> assetStaging=assetStagingRepoImpl.findByDocId(docId);
		
		if(!assetStaging.isEmpty())
		{
			content =decrypt(fileLocation+"/"+assetStaging.get(0).getAgreementId()+SLASH+assetStaging.get(0).getFileName(),assetStaging.get(0).getDocEncryptKey());
			
			AuditLog auditLog=AuditLog.builder().action(ACTION_DWNLD).createdBy(user).createdDate(date).currentValue("").lastUpdateDate(date).modifiedBy(user).oldValue("").roleName("").sourceName(assetStaging.get(0).getSourceName())
					.productName(assetStaging.get(0).getProductName()).status(SUCCESS).category(ASSETS).customerId(assetStaging.get(0).getCustomerId()).message(user+" downloaded document for customer id : "+assetStaging.get(0).getCustomerId()+ " successfully").build();
			
			auditLog(auditLog);
		    // Return the response with the file as an InputStream
		    return HttpResponse.ok().contentLength(0)
		    		.header(HttpHeaders.CONTENT_TYPE, assetStaging.get(0).getFileType())
	                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename="+assetStaging.get(0).getDocumentTitle())
	                .body(content);
		}
		return null;
	}
	
	
    private SecretKey generateSecretKey(String password, byte [] iv) throws NoSuchAlgorithmException, InvalidKeySpecException {
        KeySpec spec = new PBEKeySpec(password.toCharArray(), iv, 65536, 128); // AES-128
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        byte[] key = secretKeyFactory.generateSecret(spec).getEncoded();
        return new SecretKeySpec(key, "AES");
    }
	
	private byte[] decrypt(String path, String key) throws IOException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeySpecException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidAlgorithmParameterException
    {
    	try (FileInputStream fis = new FileInputStream(path)) {
			ByteBuffer byteBuffer = ByteBuffer.wrap(IOUtils.toByteArray(fis));

			  int noonceSize = byteBuffer.getInt();

			  //Make sure that the file was encrypted properly
			  if(noonceSize < 12 || noonceSize >= 16) {
			      throw new IllegalArgumentException("Nonce size is incorrect. Make sure that the incoming data is an AES encrypted file.");
			  }
			  byte[] iv = new byte[noonceSize];
			  byteBuffer.get(iv);

			  //Prepare your key/password
			  SecretKey secretKey = generateSecretKey(key, iv);

			  //get the rest of encrypted data
			  byte[] cipherBytes = new byte[byteBuffer.remaining()];
			  byteBuffer.get(cipherBytes);

			  Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
			  GCMParameterSpec parameterSpec = new GCMParameterSpec(128, iv);

			  //Encryption mode on!
			  cipher.init(Cipher.DECRYPT_MODE, secretKey, parameterSpec);

			  //Encrypt the data
			  return cipher.doFinal(cipherBytes);
			  
		}
    }
	
	 private String getCurrentDate() {
			DateTimeFormatter dtf = DateTimeFormatter.ofPattern(DATE_FORMAT);
			LocalDateTime now = LocalDateTime.now();

			return (dtf.format(now));
	}
	 
	@Async
	public void auditLog(AuditLog auditLog) {
		auditLogClient.addAuditLog(auditLog);
	}
}
