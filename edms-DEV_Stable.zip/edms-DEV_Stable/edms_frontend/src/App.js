  
import React from "react";


import Sidebar from './Components/Sidebar/Sidebar';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Dashboard from './Pages/Dashboard';
import Assets from './Pages/Assets';
import Liabilities from './Pages/Liabilities';
import AuditLog from './Pages/AuditLog';
import RoleMapping from './Pages/RoleMapping';
import Reports from './Pages/Reports';
import Users from './Pages/Users';
import Header from './Components/Header/Header';

function App() {
  return (
    <BrowserRouter>
    <Header/>
     <Sidebar>
      <Routes>
        <Route path ="/" element ={<Dashboard/>}/>
        <Route path ="/assets/SFDC" element ={<Assets/>}/>
        <Route path ="/liabilities/SFDC" element ={<Liabilities/>}/>
        <Route path ="/auditLog" element ={<AuditLog/>}/>
        <Route path ="/roleMapping" element ={<RoleMapping/>}/>
        <Route path ="/reports" element ={<Reports/>}/>
        <Route path ="/users" element ={<Users/>}/>
      </Routes>
      </Sidebar>
    </BrowserRouter>

  );
}

export default App;
