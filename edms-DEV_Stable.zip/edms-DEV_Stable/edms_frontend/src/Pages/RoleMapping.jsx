import React from 'react'

export default function RoleMapping() {
  return (
    <div>RoleMapping</div>
  )
}
