import React from 'react'

export default function AuditLog() {
  return (
    <div>AuditLog</div>
  )
}
