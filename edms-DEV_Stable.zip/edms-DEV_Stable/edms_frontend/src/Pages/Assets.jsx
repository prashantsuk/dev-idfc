import React,{useState} from 'react';
import '../Pages/Assets.css';
import AddDocument from '../Components/AssetSFDC/AddDocument/UploadFile/AddDocument';
import SearchDocument from '../Components/AssetSFDC/ViewDocument/SearchDocument/SearchDocument';
import AddFolder from '../Components/AssetSFDC/AddFolder/AddFolder';
import ViewFolder from '../Components/AssetSFDC/ViewFolder/ViewFolder'


export default function Assets() {
  const[showone, setShowOne]= useState(true);
    const[showtwo, setShowTwo] = useState(false);
    const[showthree, setShowThree] = useState(false);
    const[showfour, setShowFour] = useState(false);
    const[activeAddDoc, setActiveAddDoc] = useState(false);
    const[activeViewDoc, setActiveViewDoc] = useState(false);
    const[activeViewFold, setActiveViewFold] = useState(false);
    const[activeAddFold, setActiveAddFold] = useState(false);

    const viewDocument = ()=>{
      setShowOne(true);
      setShowTwo(false);
    setShowFour(false);
    setShowThree(false);
    setActiveViewDoc(true);
    setActiveAddDoc(false); 
    setActiveViewFold(false);
    setActiveAddFold(false);
  
   
   }
   const addDocument = () =>{
     
    setShowOne(false);
    setShowTwo(true);
    setShowFour(false);
    setShowThree(false);
    setActiveAddDoc(true);
    setActiveViewDoc(false);
    setActiveViewFold(false);
    setActiveAddFold(false);
  
   


  }
  const viewFolder = () =>{
    setShowThree(true);
    setShowOne(false);
    setShowTwo(false);
    setShowFour(false);
    setActiveViewFold(true);
    setActiveAddDoc(false);
    setActiveViewDoc(false);
    setActiveAddFold(false);
 
  
  }
  const addFolder = () =>{
    setShowFour(true)
    setShowTwo(false);
    setShowOne(false);
    setShowThree(false);
    setActiveAddFold(true);
    setActiveViewFold(false);
    setActiveAddDoc(false);
    setActiveViewDoc(false);

  }
  return (
    <>
      {/* <TopNav/> */}
      <nav className="navbar navbar-dark ">
         <form className='container-fluid justify-content-start'>
         <button style ={{backgroundColor: activeViewDoc? ' #6c0d16':"", color:activeViewDoc?"blue":""}} onClick= {viewDocument} type="button" className="btn btn-lg text-white">View Document</button>
         <button style ={{backgroundColor: activeAddDoc? ' #6c0d16':"", color:activeAddDoc?"blue":""}} onClick= {addDocument} type="button" className="btn btn-lg text-white">Add Document</button>
         <button style ={{backgroundColor: activeViewFold? '#6c0d16':"", color:activeViewFold?"blue":""}} onClick= {viewFolder} type="button" className="btn  btn-lg text-white" >View Folder</button>
         <button style ={{backgroundColor: activeAddFold? '#6c0d16':"", color:activeAddFold?"blue":""}} onClick= {addFolder} type="button" className="btn  btn-lg text-white">Add Folder</button>
         </form>
       
        </nav>
      <div className ='asset_container'>
     
      { 
          (showone === true)?<SearchDocument/>:(showtwo === true)?<AddDocument/>:
          (showthree === true)?<ViewFolder/>:<AddFolder/>

      }
     

    </div>
    </>
  )
}



