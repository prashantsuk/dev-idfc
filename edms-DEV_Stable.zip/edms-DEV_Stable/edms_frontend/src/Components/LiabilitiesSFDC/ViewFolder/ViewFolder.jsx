import React , {useState} from "react";
// import SearchData from '../SearchData/SearchData';
import './ViewFolder.css'

function ViewFolder() {

  const docType =["None","Address proof", "ID Proof", "Communication Address Proof","Annexure", "AOF"]

  const[CustId, setCustId] = useState("");
  const[selectType, setSelectType] = useState(docType[0]);
  // const[show, setShow] = useState(false);

  
  // const SearchFolder = async () =>{
  //     setShow(true);
  //       }

    const handleAdd = (e) =>{
      e.preventDefault();
    
    }
  //  const handleReset = (e) =>{
  //     e.target.reset();
  //  }
  return (
    <div className="container ml-2">
    <form onSubmit={handleAdd}>
    
      <div className="mb-2 mt-4 row">
        <label htmlFor="custId" className="col-sm-2 col-form-label">
         Customer ID
        </label>

        <div className="col-sm-3">
          <input
            type="number"
            className="form-control"
            id="custId"
            value={CustId}
            onChange = {(e) => setCustId(e.target.value)}
          />
        </div>
      </div>
      <div className="mb-2 mt-4 row">
        <label htmlFor="typeSelect" className="col-sm-2 col-form-label">
          Document Type
        </label>
        <div className="col-sm-3">
          <select className="form-select" value ={selectType} id="typeSelect" onChange = {(e) => setSelectType(e.target.value)}>
            {
              docType.map((type, id) =>{
                 return(
                  <option key = {id} value = {type}>{type}</option>
                 )
              })
            }
          </select>
        </div>
      </div>
    
      <div className="mt-4 row">
       
        <div className="col-5 offset-2">
          <button
            type="submit"
            className="btn btn-danger col-md-3">
            Search
          </button>
         
       
          <button
            type="reset"
            className="btn btn-danger col-md-3 offset-sm-1"> Clear
          </button>
       </div>
      </div>
    </form>
    {/* {
      show === true && 
      <SearchFolder/>
    } */}

    
    </div>
  );
}

export default ViewFolder;
