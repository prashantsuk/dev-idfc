import React, {useState, useEffect, atob } from 'react';
import axios from 'axios';
// import {SearchDataTable} from '../../LiabilitiesAPI/Api';
import './SearchData.css';



export default function UploadData({setDcIndx}) {
  const searchDataUrl = "http://52.140.58.184:9414/msGetMetaData/getDocumentData/liabilities"
    const[SearchData, setSearchData] = useState([]);
    const[base64File, setBase64File] = useState("");
    const[mimType, setMimType] = useState("");

    const getSearchDataList = async () =>{
        try {
          const {data} = await axios.get(searchDataUrl,{params:{docIndx:setDcIndx}});
          setSearchData(data);
          setBase64File(data.base64img);
          console.log(data.base64img);
          setMimType(data.fileType);
          console.log(data.fileType);
        } catch (error) {
            throw error
        }
       
    }
    useEffect(() =>{
        getSearchDataList();
    },[]);

    const handleClick = () => {
      const binary = window.atob(base64File);
      const array = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        array[i] = binary.charCodeAt(i);
      }
      const blob = new Blob([array], { type: mimType });
      const url = URL.createObjectURL(blob);
      window.open(url);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = SearchData.docTitle;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
    };

  return (
    <div className="container">
       
    <div className="container upload-data mt-4">
      <table className='table table-bordered '>
        <thead>
          <tr>
           <th scope="col">EDMS ID</th>
           <th scope="col">Customer ID</th>
            <th scope="col">Document Title</th>
            <th scope="col">Document Class</th>
            <th scope="col">Document Type</th>
            <th scope="col">Document Name</th>
            <th scope="col">Customer Name</th>
            <th scope="col">UCIC</th>
            <th scope="col">Account Number</th>
            <th scope="col">Barcode Number</th>
            <th scope="col">File Size</th>
            <th scope="col">File Type</th>
            <th scope="col">No Of Pages</th>
            <th scope="col">Owner</th>
            <th scope="col">Mobile Number</th>
            <th scope="col">Remarks</th>
            <th scope="col">Document Number</th>
            <th scope="col">Comments</th>
            <th scope="col">Multipage Document</th>
            <th scope="col">Source</th>
            <th scope="col">Upload Date</th>
            <th scope="col">Modified Date</th>
            <th scope="col">Expiry Date</th>
            <th scope="col">Accepted Date</th>
            <th scope="col">Created Date</th>
            <th scope="col">Created By</th>
            <th scope="col">Accepted By</th>
            <th scope="col">Document Encryption</th>

          </tr>
        </thead>
        <tbody>
            {/* {
              SearchData.map((item, index) =>{
                return(
                    <tr key = {index}>
                        <td>{item.edmsId}</td>
                        <td>{item.docTitle}</td>
                        <td>{item.phone}</td>
                        <td>{item.docType}</td>
                        <td>{item.docName}</td>
                        <td>{item.custName}</td>
                        <td>{item.ucic}</td>
                        <td>{item.acctNum}</td>
                        <td>{item.barCodeNum}</td>
                        <td>{item.fileSize}</td>
                        <td>{item.fileType}</td>
                        <td>{item.noOfPages}</td>
                        <td>{item.owner}</td>
                        <td>{item.mobNo}</td>
                        <td>{item.remarks}</td>
                        <td>{item.docNum}</td>
                        <td>{item.comments}</td>
                        <td>{item.multipageDoc}</td>
                        <td>{item.source}</td>
                        <td>{item.uploadDate}</td>
                        <td>{item.modifiedDate}</td>
                        <td>{item.expiryDate}</td>
                        <td>{item.acceptedDate}</td>
                        <td>{item.createdDate}</td>
                        <td>{item.createdBy}</td>
                        <td>{item.acceptedBy}</td>
                        <td>{item.docEncrypt}</td>
                        
                    </tr>
                )
               }) 
            } */}
            <tr>
                        <td>{SearchData.edmsId}</td>
                        <td>{SearchData.custId}</td>
                        <td>
                         <a href="#" target="_blank" onClick={handleClick}>
                         {SearchData.docTitle}
                         </a>
                        </td>
                        <td>{SearchData.phone}</td>
                        <td>{SearchData.docType}</td>
                        <td>{SearchData.docName}</td>
                        <td>{SearchData.custName}</td>
                        <td>{SearchData.ucic}</td>
                        <td>{SearchData.acctNum}</td>
                        <td>{SearchData.barCodeNum}</td>
                        <td>{SearchData.fileSize}</td>
                        <td>{SearchData.fileType}</td>
                        <td>{SearchData.noOfPages}</td>
                        <td>{SearchData.owner}</td>
                        <td>{SearchData.mobNo}</td>
                        <td>{SearchData.remarks}</td>
                        <td>{SearchData.docNum}</td>
                        <td>{SearchData.comments}</td>
                        <td>{SearchData.multipageDoc}</td>
                        <td>{SearchData.source}</td>
                        <td>{SearchData.uploadDate}</td>
                        <td>{SearchData.modifiedDate}</td>
                        <td>{SearchData.expiryDate}</td>
                        <td>{SearchData.acceptedDate}</td>
                        <td>{SearchData.createdDate}</td>
                        <td>{SearchData.createdBy}</td>
                        <td>{SearchData.acceptedBy}</td>
                        <td>{SearchData.docEncrypt}</td>
                        
                    </tr>
        </tbody>
      </table>
    </div>
    </div>
  );
}
