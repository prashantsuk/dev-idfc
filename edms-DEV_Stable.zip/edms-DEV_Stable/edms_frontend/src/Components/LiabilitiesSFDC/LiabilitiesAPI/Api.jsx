// import axios from "axios";

// // const uploadUrl ="https://v2.convertapi.com/upload";
// const uploadDataUrl = "http://localhost:9414/liabilities/getDocumentData";
// const searchDataUrl = "http://localhost:9414/liabilities/getDocumentData"

// // export const fileUpload = async(data) =>{
// //     try {
// //         await axios.post(uploadUrl, data)
        
// //     } catch (error) {
// //         throw error;
        
// //     }

// // }

// export const UploadDataTable = async () =>{
//     try {
//         const {data} = await axios.get(uploadDataUrl,{params:{docIndx:'1'}});
//         return data;

        
//     } catch (error) {
//          throw error;
//     }
// }
// export const SearchDataTable = async () =>{
//     try {
//         const {data} = await axios.get(searchDataUrl,{params:{docIndx:'1'}});
//         return data;

        
//     } catch (error) {
//          throw error;
//     }
// }