import React from 'react';
import Logo from '../Images/IDFC-logo-website.svg';
import './Header.css'

export default function Header() {
  return (
    <div className='main_page'>
        <header>
           <img src={Logo} alt ="logo"/>
           <h4 className='text-white align-item-end'> Enterprise Document Management System</h4>
        </header>
    </div>
  )
}
