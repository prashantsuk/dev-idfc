import React, {useState, useEffect, atob} from 'react';
import axios from 'axios';
// import {UploadDataTable} from '../../AssetsAPI/Api';
import './UploadData.css';



export default function UploadData({setDcIndx}) {
  const uploadDataUrl = "http://52.140.58.184:9414/msUploadAsset/api/v1/doc-upload";
  const[AddData, setAddData] = useState([]);
  const[base64File, setBase64File] = useState("");
  const[mimeType, setMimeType] = useState("");


  const getDataList = async () =>{
      try {
        const {data} = await axios.get(uploadDataUrl,{params:{processedId:setDcIndx}});
        setAddData(data);
        setBase64File(data.content.replace(/^data:.+;base64,/, ''));
        console.log(data.content.replace(/^data:.+;base64,/, ''));
        setMimeType(data.mimeType);
        console.log(data.mimeType);
      } catch (error) {
          throw error
      }
     
  }
  useEffect(() =>{
      getDataList();
  },[]);

  const handleClick = () => {
    const binary = window.atob(base64File);
    const array = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      array[i] = binary.charCodeAt(i);
    }
    const blob = new Blob([array], { type: mimeType });
    const url = URL.createObjectURL(blob);
    window.open(url);
    const a = document.createElement('a');
    a.style.display = 'none';
    a.href = url;
    a.download = AddData.documentTitle;
    document.body.appendChild(a);
    a.click();
    // URL.revokeObjectURL(url);
    // window.open(URL.createObjectURL(blob));
  };

  return (
    <div className="container">
       
    <div className="container upload-data mt-4">
      <table className='table table-bordered '>
        <thead>
          <tr>
          <th scope="col">Name</th>
            <th scope="col">Document Title</th>
            <th scope="col">Document Class</th>
            <th scope="col ">Modified Date</th>
            <th scope="col">Customer ID</th>
            <th scope="col">Content</th>
            <th scope="col">File Name</th>
            <th scope="col">Size</th>
            <th scope="col">Document Type</th>
            <th scope="col">Pages</th>
            <th scope="col">Owner</th>          
            <th scope="col">Document Name</th>
            <th scope="col">Customer Name</th>
            <th scope="col">Scheme Id</th>
            <th scope="col">Remarks</th>
            <th scope="col">Document_Number</th>
            <th scope="col">Reimbursement_Account_No</th>
            <th scope="col">Expiry_Dt</th>
            <th scope="col">Accessed Date</th>
            <th scope="col">Owner Type</th>
            <th scope="col">Document Password</th>
            <th scope="col">Upload Date</th>
            <th scope="col">Uploaded By</th>
            <th scope="col">Multipage Document</th>
            <th scope="col">Role</th>
            <th scope="col">Product</th>
            <th scope="col">CRM Id</th>
            <th scope="col">FinnOne Loan Number</th>
            <th scope="col">SFDC Loan Number</th>
            <th scope="col">Ingestion Source</th>
            <th scope="col">EDMS Response</th>
          </tr>
        </thead>
        <tbody>
            <tr>
            <td>{AddData.customerName}</td>
            <td> 
              <a href="#" target="_blank" onClick={handleClick}>
               File
              </a>
            </td>
            <td>{AddData.docClass}</td>
            <td>{AddData.modifyDate}</td>
            <td>{AddData.customerId}</td>
            <td>{AddData.basecontent}</td>
            <td>{AddData.documentName}</td>
            <td>{(AddData.actualFileSize/1000)+"KB"}</td>
            <td>{AddData.documentType}</td>
            <td>NA</td>
            <td>{AddData.creator}</td>
            <td>{AddData.documentName }</td>
            <td>{AddData.customerName}</td>
            <td>{AddData.schemeId}</td>
            <td>{AddData.documentRemark }</td>
            <td>{AddData.documentVersion }</td>
            <td>NA</td>
            <td>NA</td>
            <td>{AddData.uploadDate}</td>
            <td>{AddData.customerType}</td>
            <td>{AddData.encryptPassword}</td>
            <td>{AddData.uploadDate}</td>
            <td>{AddData.creator }</td>
            <td>NA</td>
            <td>{AddData.role}</td>
            <td>{AddData.productId}</td>
            <td>{AddData.crmId}</td>
            <td>{AddData.finnOneLoanNo}</td>
            <td>{AddData.sfdcLoanno}</td>
            <td>{AddData.ingestionSource}</td>
            <td>{AddData.edmsResponse}</td>
              
            </tr>
        </tbody>
      </table>
    </div>
    </div>
  );
}
