import axios from "axios";
import React , {useState, useEffect} from "react";
// import {fileUpload} from '../../AssetsAPI/Api';
import UploadData from "../UploadData/UploadData";

function AddDocument() {
  const url ="http://52.140.58.184:9414/msUploadAsset/api/v1/doc-upload";

  const[custId, setCustId] = useState("");
  const[password, setPassword] = useState("");
  const[selectType, setSelectType] = useState([]);
  const[selectName, setSelectName] = useState([]);
  const[docType, setDocType] = useState("");
  const[docName, setDocName] = useState("");
  const[fileName, setFileName] = useState("")
  const[bs64Img, setBs64Img] = useState("");
  const[show, setShow] = useState(false);
  const[data, setData] = useState("");
  const[dcIndx, setDcIndx] = useState("");
  const[mimeType, setMimeType] = useState("");


  useEffect(() => {
    const fetchDocType = async () => {
        const response = await axios.get("http://52.140.58.184:9414/msGetDocumentTypes/edms/docType");
        setSelectType(response.data);
        console.log(response.data);
    }
    fetchDocType()
}, [])


  useEffect(() =>{
    try {
      const fetchDocName = async () =>{
        const response = await axios.get("http://52.140.58.184:9414/msGetDocumentNames/edms/docName");
        const selectedDocTypeId = selectType.find(doctype => doctype.doctypename === docType).doctypeid;
        console.log(selectedDocTypeId);
        const filteredDocs = response.data.filter(doc => doc.doctypeid === selectedDocTypeId);
        setSelectName(filteredDocs);
        console.log(filteredDocs);
      }
     if(docType){
      fetchDocName();
    } 
      
    } catch (error) {
      console.log(error);
      
    }
  },[docType])

  const handleCustId = (e) =>{
    const numberRegExp = new RegExp(/^\d{0,14}$/);
    const Id = e.target.value;
    if(numberRegExp.test(Id) && Id >= 0){
      setCustId(Id);
    }
  }

   const onChange = (e) =>{
          const file = e.target.files[0];
          console.log(file);
          console.log(file.name, file.type, file.size);
          const allowedFileTypes=["pdf","txt","doc","docx","tif","tiff","jpg","jpeg","xls","xlsx","xlsb","eml","html","htm","png","msg","ppt","pptx","csv","zip"];

          if(!file.name.match(/\.(jpg|pdf|txt|doc|docx|tif|tiff|jpg|jpe|jpeg|xls|xlsx|xlsb|eml|html|htm|png|msg|ppt|pptx|csv|zip|7z|PDF|TXT|DOC|DOCX|TIF|TIFF|JPG|JPE|JPEG|XLS|XLSX|XLSB|EML|HTML|HTM|PNG|MSG|PPT|PPTX|CSV|ZIP|7Z|Pdf|Txt|Doc|Docx|Tif|Tiff|Jpg|Jpe|Jpeg|Xls|Xlsx|Xlsb|Eml|Html|Htm|Png|Msg|Ppt|Ppptx|Csv|Zip|JFIF|jfif|Jfif)$/)){
            alert(`File type does not support. File type must be ${allowedFileTypes.join(", ")}`);
            return false;
          }

          if(file.size > 10e6){
            alert("File size should be less than 10 MB");
          }
          setFileName(file.name);
          convertBase64(file);
          setMimeType(file.type);
 
        
        }
      const onLoad = (fileString) =>{
        setBs64Img(fileString);
      }
            const convertBase64 =(file)=>{

                 const fileReader = new FileReader();
                 fileReader.readAsDataURL(file);
                 fileReader.onload = () =>{
                    onLoad(fileReader.result);
                 }
               }

        const handleSubmit = async (e) =>{
        e.preventDefault();
        if(custId === "" ||  bs64Img === "" || fileName === "" || docType === "" || docName === ""){
          alert("Please fill out all mandatory fields");
        }
        else if(docType === 'None' || docName === 'None') {
          alert("option selected is None, Please select valid option");
          
        }
        else{
          const data = {uploadDocuments:{objectBean:{content:bs64Img,fileLocation:fileName,
          property:[{propertyName:"CF_DocumentName",propertyValue:docName},{propertyName:"DocumentTitle",propertyValue:fileName},
          {propertyName:"CF_DocumentTypeName",propertyValue:docName},{propertyName:"CF_UploadedBy",propertyValue:docName},
          {propertyName:"CF_OriginalPhotocopy",propertyValue:docName},{propertyName:"CF_Mandatory",propertyValue:custId},
          {propertyName:"CF_DealerOnboardingID",propertyValue:custId},{propertyName:"CF_FinnOneLoanNumber",propertyValue:custId},
          {propertyName:"CF_CRMId",propertyValue:custId},{propertyName:"CF_ApplicationId",propertyValue:custId}] }},password,prntFldrIndx:"100",srcFldrIndx:"101",mimeType, documentType:docType};
          setData(data);
          console.log(data);
          const res = await axios.post(url, data,{headers:{"Access-Control-Allow-Origin": "*"}});
          alert("Document added successfully with doc index : "+ res.data.processedId);
          console.log(res.data.processedId);
          setDcIndx(res.data.processedId);
          setShow(true);
          setCustId("");
          setPassword("");
          setDocType("");
          setDocName("");
          setFileName("");
          setMimeType("");
          document.getElementById("fileInput").value = "";
          setBs64Img("");

        }
      }
      const handleReset = () =>{
        // e.target.reset();
        setCustId("");
        setPassword("");
        setDocType("");
        setDocName("");
        setFileName("");
        setBs64Img("");
        setShow(false);
      }

  return (
    <div className="container">
    <form onSubmit={handleSubmit}>
      <div className="mb-2 mt-4 row">
        <label htmlFor="custId" className="col-sm-2 col-form-label">
         Customer ID
        </label>

        <div className="col-sm-3">
          <input
            type="text"
            className="form-control "
            id="custId"
            value={custId}
            onChange = {handleCustId}
          />
        </div>
      </div>
      <div className="mb-2 mt-4 row">
        <label htmlFor="typeSelect" className="col-sm-2 col-form-label">
          Document Type
        </label>
        <div className="col-sm-3">
        <select className="form-select" id="typeSelect" value = {docType} onChange = {(e) => setDocType(e.target.value)}>
          <option selected>None</option>
            {
              selectType.map((type, id) =>{
                 return(
                  <option key = {id} value = {type.doctypename}>{type.doctypename}</option>
                 )
              })
            }
          </select>
        </div>
      </div>
      <div className="mb-2 mt-4 row">
        <label htmlFor="nameSelect" className="col-sm-2 col-form-label">
          Document Name
        </label>
        <div className="col-sm-3">
         <select className="form-select" id="nameSelect" value ={docName} onChange = {(e) => setDocName(e.target.value)}>
          <option selected>None</option>
            {
              selectName.map((name, id) =>{
                return(
                     <option key ={id} value={name.docname}>{name.docname}</option>
                )
              })
            }
          
          </select>
        </div>
      </div>
      <div className="mb-2 mt-4 row">
        <label htmlFor="docUpload" className="col-sm-2 col-form-label">
          Upload Document 
        </label>
        <div className="col-sm-3">
          <input
            type="file"
            className="form-control "
            id="fileInput"
            name ="doc"
            onChange = {onChange}
          />
        </div>
      </div>
      <div className="mb-2 mt-4 row">
        <label htmlFor="docPassword" className="col-sm-2 col-form-label">
         Document Password
        </label>

        <div className="col-sm-3">
          <input
            type="text"
            className="form-control"
            id="docPassword"
            value={password}
            onChange = {(e) => setPassword(e.target.value)}
          />
        </div>
      </div>
  
      <div className="mt-4 row">
       
        <div className="col-5 offset-2">
          <button
            type="submit"
            className="btn btn-danger col-md-3">
            Upload
          </button>
        
       
          <button
            type="reset"
            className="btn btn-danger col-md-3 offset-md-1"
            onClick = {handleReset}>
            Clear
          </button>
       </div>
      </div>
    </form>
    {
      show === true && 
      <UploadData setDcIndx = {dcIndx}/>
    }
 
    </div>
  );
}

export default AddDocument;
