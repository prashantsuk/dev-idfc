// import axios from "axios";

// // const uploadUrl ="https://v2.convertapi.com/upload";
// const uploadDataUrl = "https://jsonplaceholder.typicode.com/todos";
// const searchDataUrl = "https://jsonplaceholder.typicode.com/users"

// // export const fileUpload = async(data) =>{
// //     try {
// //         await axios.post(uploadUrl, data)
        
// //     } catch (error) {
// //         throw error;
        
// //     }

// // }

// export const UploadDataTable = async () =>{
//     try {
//         const {data} = await axios.get(uploadDataUrl);
//         return data;

        
//     } catch (error) {
//          throw error;
//     }
// }
// export const SearchDataTable = async () =>{
//     try {
//         const {data} = await axios.get(searchDataUrl);
//         return data;

        
//     } catch (error) {
//          throw error;
//     }
// }