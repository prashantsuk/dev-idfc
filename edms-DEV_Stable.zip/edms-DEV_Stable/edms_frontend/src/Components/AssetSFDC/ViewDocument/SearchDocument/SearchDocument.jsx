import React , {useState, useEffect} from "react";
import axios from "axios";
import SearchData from '../SearchData/SearchData';

function SearchDocument() {
  const url= "http://52.140.58.184:9414/msUploadAsset/api/v1/view-document";

  const[custId, setCustId] = useState("");
  const[selectType, setSelectType] = useState([]);
  const[selectName, setSelectName] = useState([]);
  const[docType, setDocType] = useState("");
  const[docName, setDocName] = useState("");
  const[show, setShow] = useState(false);
  const[data, setData] = useState("");
  const[dcIndx, setDcIndx] = useState("");
  
 

  useEffect(() => {
    const fetchDocType = async () => {
        const response = await axios.get("http://52.140.58.184:9414/msGetDocumentTypes/edms/docType");
        setSelectType(response.data);
        console.log(response.data);
    }
    fetchDocType()
}, [])


  useEffect(() =>{
    try {
      const fetchDocName = async () =>{
        const response = await axios.get("http://52.140.58.184:9414/msGetDocumentNames/edms/docName");
        const selectedDocTypeId = selectType.find(doctype => doctype.doctypename === docType).doctypeid;
        console.log(selectedDocTypeId);
        const filteredDocs = response.data.filter(doc => doc.doctypeid === selectedDocTypeId);
        setSelectName(filteredDocs);
        console.log(filteredDocs);
      }
     if(docType){
      fetchDocName();
    } 
      
    } catch (error) {
      console.log(error);
      
    }
  },[docType])

  const handleCustId = (e) =>{
    const numberRegExp = new RegExp(/^\d{0,14}$/);
    const Id = e.target.value;
    if(numberRegExp.test(Id) && Id >= 0){
      setCustId(Id);
    }
  }

  const handleSubmit = async (e) =>{
    e.preventDefault();
    if(custId === ""|| docType === "" || docName === ""){
      alert("Please fill out the mandatory fields for Search");
   }
   else if(docType === 'None' || docName === 'None') {
    alert("option selected is None, Please select valid option");
    
  }
   else{
      const data = {customerId:custId, documentType:docType, documentName:docName};
      setData(data);
      console.log(data);
    (axios.post(url, data, {headers:{"Access-Control-Allow-Origin": "*"}})).then((response) => {
        console.log(response);
        console.log(response.status);
        console.log("First data"+response.data[0].id);
        if(!response.data[0]){
          alert("No Records Found with current customer ID")
        }
        setDcIndx(response.data[0].id);
        setShow(true);
        setCustId("");
        setDocType("");
        setDocName("");  
    })
    .catch((err) => {
        console.log(err);
        alert(err.message);
    });
      
  }
}
 const handleReset = () =>{
    // e.target.reset();
    setCustId("");
    setDocType("");
    setDocName("");
    setShow(false);
 }
  return (
    <div className="container">
    <form onSubmit={handleSubmit}>
     
      <div className="mb-2 mt-4 row">
        <label htmlFor="custId" className="col-sm-2 col-form-label">
         Customer ID
        </label>

        <div className="col-sm-3">
          <input
            type="text"
            className="form-control"
            id="custId"
            value={custId}
            onChange = {handleCustId}
          />
        </div>
      </div>
      <div className="mb-2 mt-4 row">
        <label htmlFor="typeSelect" className="col-sm-2 col-form-label">
          Document Type
        </label>
        <div className="col-sm-3">
        <select className="form-select" value ={docType} id="typeSelect" onChange = {(e) => setDocType(e.target.value)}>
           <option selected>None</option>
            {
              selectType.map((type, id) =>{
                 return(
                  <option key = {id} value = {type.doctypename}>{type.doctypename}</option>
                 )
              })
            }
          </select>
        </div>
      </div>
      <div className="mb-2 mt-4 row">
        <label htmlFor="nameSelect" className="col-sm-2 col-form-label">
          Document Name
        </label>
        <div className="col-sm-3">
        <select className="form-select" id="nameSelect" value={docName} onChange = {(e) => setDocName(e.target.value)}>
          <option selected>None</option>
            {
              selectName.map((name, id) =>{
                return(
                     <option key ={id} value={name.docname}>{name.docname}</option>
                )
              })
            }
          </select>
        </div>
      </div>
     
      <div className="mt-4 row">
       
        <div className="col-5 offset-2">
          <button
            type="submit"
            className="btn btn-danger col-md-3">
            Search
          </button>
        
       
          <button
            type="reset"
            className="btn btn-danger col-md-3 offset-sm-1"
            onClick = {handleReset}> Clear
          </button>
       </div>
      </div>
    </form>
    {
      show === true && 
      <SearchData setDcIndx = {dcIndx}/>
    }

    </div>
  );
}

export default SearchDocument;
