import React, {useState, useEffect, atob } from 'react';
import axios from 'axios';
// import {SearchDataTable} from '../../AssetsAPI/Api';
import './SearchData.css';



export default function UploadData({setDcIndx}) {
  const searchDataUrl = "http://52.140.58.184:9414/msUploadAsset/api/v1/doc-upload"
    const[SearchData, setSearchData] = useState([]);
    const[base64File, setBase64File] = useState("");
    const[mimeType, setMimeType] = useState("");

    const getSearchDataList = async () =>{
        try {
          const {data} = await axios.get(searchDataUrl,{params:{processedId:setDcIndx}});
          setSearchData(data);
          setBase64File(data.content.replace(/^data:.+;base64,/, ''));
          console.log(data.content.replace(/^data:.+;base64,/, ''));
          setMimeType(data.mimeType);
          console.log(data.mimeType);
        } catch (error) {
            throw error
        }
       
    }
    useEffect(() =>{
        getSearchDataList();
    },[]);

    const handleClick = () => {
      const binary = window.atob(base64File);
      const array = new Uint8Array(binary.length);
      for (let i = 0; i < binary.length; i++) {
        array[i] = binary.charCodeAt(i);
      }
      const blob = new Blob([array], { type: mimeType });
      const url = URL.createObjectURL(blob);
      window.open(url);
      const a = document.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = SearchData.docTyp;
      document.body.appendChild(a);
      a.click();
      URL.revokeObjectURL(url);
    };

  return (
    <div className="container">
       
    <div className="container upload-data mt-4">
      <table className='table table-bordered '>
        <thead>
          <tr>
            <th scope="col">EDMS ID</th>
            <th scope="col">Document Title</th>
            <th scope="col">Customer ID</th>
            <th scope="col">Document Type</th>
            <th scope="col">Document Name</th>
            <th scope="col">Customer Name</th>
            <th scope="col">File Size</th>
            <th scope="col">File Type</th>
            <th scope="col">FinnOne Loan Number</th>
            <th scope="col">SFDC Loan Number</th>
            <th scope="col">Doc Expiry Date</th>
            <th scope="col">Doc Upload Date</th>
            <th scope="col">Doc IDr</th>
            <th scope="col">Remarks</th>
            <th scope="col">Document Number</th>
            <th scope="col">Reimbursement Account No</th>
            <th scope="col">Owner Type</th>
            <th scope="col">Document Password</th>
            <th scope="col">RCU Decision</th>
            <th scope="col">RCU Hold</th>
            <th scope="col">RCU Comment</th>
            <th scope="col">Comments</th>
            <th scope="col">Multipage Document</th>
            <th scope="col">Source Loan No</th>
            <th scope="col">Agreement Id</th>
            <th scope="col">Role</th>
            <th scope="col">Source</th>
            <th scope="col">Product</th>
            <th scope="col">Loan No</th>
            <th scope="col">Document Password</th>

          </tr>
        </thead>
        <tbody>
            {/* {
              SearchData.map((item, index) =>{
                return(
                    <tr key = {index}>
                        <td>{item.userId}</td>
                        <td>{item.title}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                        <td>{}</td>
                    </tr>
                )
               }) 
            } */}
            <tr>
              <td>{SearchData.crmId}</td>
              <td>
                <a href="#" target="_blank" onClick={handleClick}>
                {SearchData.docType}
                </a>
              </td>
              <td>{SearchData.customerId}</td>
              <td>{SearchData.docType}</td>
              <td>{SearchData.docName}</td>
              <td>{SearchData.customerName}</td>
              <td>{SearchData.fileSize}</td>
              <td>{SearchData.fileType}</td>
              <td>{SearchData.finnoneloanno}</td>
              <td>{SearchData.sfdcloanno}</td>
              <td>{SearchData.docexpiryDate}</td>
              <td>{SearchData.uploadDate}</td>
              <td>{SearchData.docId}</td>
              <td>{SearchData.remarks}</td>
              <td>{SearchData.docNumber}</td>
              <td>{SearchData.reimbAccNo}</td>
              <td>{SearchData.ownerType}</td>s
              <td>{SearchData.docPassword}</td>
              <td>{SearchData.rcuDecision}</td>
              <td>{SearchData.rcuHold}</td>
              <td>{SearchData.rcuComments}</td>
              <td>{SearchData.comments}</td>
              <td>{SearchData.multipageDoc}</td>
              <td>{SearchData.sourceLoanNo}</td>
              <td>{SearchData.agreementID}</td>
              <td>{SearchData.role}</td>
              <td>{SearchData.source}</td>
              <td>{SearchData.product}</td>
              <td>{SearchData.loanNumber}</td>
              <td>{SearchData.docPassword}</td>
         
            </tr>
        </tbody>
      </table>
    </div>
    </div>
  );
}
