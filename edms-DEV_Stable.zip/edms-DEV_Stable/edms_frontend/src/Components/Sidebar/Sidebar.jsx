import React, {useState} from 'react';
import './Sidebar.css';
import {
  FaTh
} from 'react-icons/fa';
import { NavLink } from 'react-router-dom';


export default function Sidebar({children}) {
    // const[isOpen, setIsOpen] = useState(false);
    const[show, setShow] = useState(false);
    // const toggle = () =>{
    //     setIsOpen(!isOpen);
    // }

  const isShow = () =>{
     setShow(true);
  }
    const SideMenuList =[
            // {
            //     path:"/",
            //     name:"Dashboard",
            //     icon:<FaTh/>
            // },
            // {
            //     path:"/assets",
            //     name:"Assets",
            //     icon:<FaTh/>
            // },
            // {
            //     path:"/liabilities",
            //     name:"Liabilities",
            //     icon:<FaTh/>
            // },
            {
                path:"/auditLog",
                name:"AuditLog",
                icon:<FaTh/>
            },
            {
                path:"roleMapping/",
                name:"RoleMapping",
                icon:<FaTh/>
            },
            {
                path:"/reports",
                name:"Reports",
                icon:<FaTh/>
            },
            {
                path:"/users",
                name:"Users",
                icon:<FaTh/>
            }
    ]
  return (
    <div className='contain'>
       
        
         <div className="sidebar">
           
            <NavLink to ="/" className="link" activeclassname ="active">
                            <div className="icon"><FaTh /></div>
                            <div className="link_text" >Dashboard</div>
                        </NavLink>
                        <NavLink to ="/assets/SFDC" className="link" >
                            <div className="icon"><FaTh onClick ={isShow}/></div>
                            <div className="link_text">Assets</div>
                        </NavLink>
                        <NavLink to ="liabilities/SFDC" className="link" >
                            <div className="icon"><FaTh onClick ={isShow}/></div>
                            <div className="link_text" onClick ={isShow}>Liabilities</div>
                        </NavLink>
            {
                SideMenuList.map((item, index) =>{
                    return(

                        <NavLink to ={item.path} key = {index} className="link" activeclassname ="active">
                            <div className="icon">{item.icon}</div>
                            <div className="link_text">{item.name}</div>
                        </NavLink>
                    )
                })
            }
         </div>
         <div className="main_area">
     
        
         <main>{children}</main>
         </div>
       
    </div>
  )
}
